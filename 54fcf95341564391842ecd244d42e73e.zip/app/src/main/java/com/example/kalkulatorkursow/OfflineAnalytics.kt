package com.example.kalkulatorkursow

import android.content.Context
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStream
import java.math.BigDecimal
import java.math.RoundingMode
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TreeSet
import java.util.UUID
import kotlin.math.abs

data class BoltDaySummary(
    val dateKey: String,   // YYYY-MM-DD
    val total: Double,     // Twoje zarobki (Bolt)
    val tips: Double,      // Napiwki
    val cash: Double,      // Płatności gotówką
    val camp: Double = 0.0 // Kampanie
)

data class BoltWeekSummary(
    val weekStartKey: String, // Poniedziałek tygodnia YYYY-MM-DD
    val total: Double,        // Zarobki z screena tygodniowego (Bolt)
    val tips: Double,         // Napiwki tygodniowe
    val cash: Double          // Gotówka tygodniowa
)

data class PayBreakdown(
    val totalBolt: Double,
    val tips: Double,
    val cash: Double,
    val basis: Double,       // totalBolt - tips
    val driverShare: Double, // basis * (sharePct / 100.0)
    val earned: Double,      // driverShare + tips
    val payout: Double       // earned - cash (dodatnie = do wypłaty od partnera, ujemne = do oddania)
)

data class PeriodStatsSummary(
    val label: String,
    val fromKey: String,
    val toKey: String,
    val tripsCount: Int,
    val activeDriveDays: Int,
    val turnoverGross: Double,
    val netDriverPart: Double,
    val estimatedMinutes: Long,
    val shiftsCount: Int,
    val avgShiftMinutes: Long,
    val avgHourlyCsv: Double,
    val avgHourlyScreens: Double,
    val pay: PayBreakdown,
    val weekDiscrepancyNote: String?
)

data class DayStat(
    val dateKey: String,
    val labelShort: String,
    val dayOfMonth: Int,
    val tripsCount: Int,
    val acceptedCount: Int,
    val grossSum: Double,
    val cashSum: Double,
    val cardSum: Double,
    val estimatedDriverEarned: Double,
    val sourceTag: String
)

data class HourStat(
    val hour: Int,
    val label: String,
    val tripsCount: Int,
    val grossSum: Double,
    val estimatedDriverEarned: Double
)

object OfflineAnalytics {
    private const val PREFS = "KursRadarOfflineAnalyticsV1"
    private fun p(ctx: Context) = ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun dayKeyFromMillis(ms: Long): String {
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        return sdf.format(Date(ms))
    }

    fun formatShortDate(key: String): String {
        val ms = parseDateKeyToMillis(key, false)
        if (ms <= 0L) return key
        return SimpleDateFormat("dd.MM.yyyy", Locale("pl", "PL")).format(Date(ms))
    }

    fun parseDateKeyToMillis(key: String, endOfDay: Boolean = false): Long {
        return try {
            val parts = key.split("-")
            if (parts.size != 3) return 0L
            val y = parts[0].toInt()
            val m = parts[1].toInt() - 1
            val d = parts[2].toInt()
            val c = Calendar.getInstance().apply {
                set(Calendar.YEAR, y)
                set(Calendar.MONTH, m)
                set(Calendar.DAY_OF_MONTH, d)
                if (endOfDay) {
                    set(Calendar.HOUR_OF_DAY, 23)
                    set(Calendar.MINUTE, 59)
                    set(Calendar.SECOND, 59)
                    set(Calendar.MILLISECOND, 999)
                } else {
                    set(Calendar.HOUR_OF_DAY, 0)
                    set(Calendar.MINUTE, 0)
                    set(Calendar.SECOND, 0)
                    set(Calendar.MILLISECOND, 0)
                }
            }
            c.timeInMillis
        } catch (_: Exception) {
            0L
        }
    }

    fun mondayKeyForMillis(ms: Long): String {
        val c = Calendar.getInstance().apply {
            timeInMillis = ms
            firstDayOfWeek = Calendar.MONDAY
            set(Calendar.DAY_OF_WEEK, Calendar.MONDAY)
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        return dayKeyFromMillis(c.timeInMillis)
    }

    fun addDaysToKey(key: String, deltaDays: Int): String {
        val start = parseDateKeyToMillis(key, false)
        if (start <= 0L) return key
        val c = Calendar.getInstance().apply {
            timeInMillis = start
            add(Calendar.DAY_OF_MONTH, deltaDays)
        }
        return dayKeyFromMillis(c.timeInMillis)
    }

    fun formatWeekRange(mondayKey: String): String {
        val endKey = addDaysToKey(mondayKey, 6)
        val sdf = SimpleDateFormat("d MMM", Locale("pl", "PL"))
        val s = sdf.format(Date(parseDateKeyToMillis(mondayKey, false)))
        val e = sdf.format(Date(parseDateKeyToMillis(endKey, false)))
        return "$s – $e"
    }

    fun round2(v: Double): Double {
        if (!v.isFinite()) return 0.0
        return BigDecimal.valueOf(v).setScale(2, RoundingMode.HALF_UP).toDouble()
    }

    fun calculatePay(totalBolt: Double, tips: Double, cash: Double, sharePercent: Float): PayBreakdown {
        val share = (sharePercent.toDouble() / 100.0).coerceIn(0.45, 0.55)
        val t = if (totalBolt.isFinite()) totalBolt else 0.0
        val tp = if (tips.isFinite()) tips else 0.0
        val cs = if (cash.isFinite()) cash else 0.0
        val basis = round2(t - tp)
        val driverShare = round2(basis * share)
        val earned = round2(driverShare + tp)
        val payout = round2(earned - cs)
        return PayBreakdown(
            totalBolt = round2(t),
            tips = round2(tp),
            cash = round2(cs),
            basis = basis,
            driverShare = driverShare,
            earned = earned,
            payout = payout
        )
    }

    fun partnerCycleAnchorMonday(ctx: Context): String {
        val saved = p(ctx).getString("partner_anchor_monday", "") ?: ""
        if (Regex("""\d{4}-\d{2}-\d{2}""").matches(saved)) return saved
        return mondayKeyForMillis(System.currentTimeMillis())
    }

    fun setPartnerCycleAnchorMonday(ctx: Context, mondayKey: String) {
        p(ctx).edit().putString("partner_anchor_monday", mondayKey).apply()
    }

    fun get14DayPeriods(anchorMonday: String, countBack: Int = 8): List<Pair<String, String>> {
        val anchorMs = parseDateKeyToMillis(anchorMonday, false)
        if (anchorMs <= 0L) return emptyList()
        val nowMs = System.currentTimeMillis()
        val cAnchor = Calendar.getInstance().apply { timeInMillis = anchorMs }
        val cNow = Calendar.getInstance().apply { timeInMillis = nowMs }
        val diffDays = ((cNow.timeInMillis - cAnchor.timeInMillis) / (86_400_000L * 14L)).toInt()
        val startIndex = maxOf(0, diffDays - countBack + 1)
        val out = ArrayList<Pair<String, String>>()
        for (idx in startIndex..(diffDays + 1)) {
            val fromK = addDaysToKey(anchorMonday, idx * 14)
            val toK = addDaysToKey(fromK, 13)
            out.add(Pair(fromK, toK))
        }
        return out.reversed()
    }

    @Synchronized
    fun getBoltDays(ctx: Context): MutableMap<String, BoltDaySummary> {
        val raw = p(ctx).getString("bolt_days_json", "{}") ?: "{}"
        val map = LinkedHashMap<String, BoltDaySummary>()
        try {
            val obj = JSONObject(raw)
            val keys = obj.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                val item = obj.getJSONObject(k)
                map[k] = BoltDaySummary(
                    dateKey = k,
                    total = item.optDouble("total", 0.0),
                    tips = item.optDouble("tips", 0.0),
                    cash = item.optDouble("cash", 0.0),
                    camp = item.optDouble("camp", 0.0)
                )
            }
        } catch (_: Exception) {}
        return map
    }

    @Synchronized
    fun saveBoltDays(ctx: Context, map: Map<String, BoltDaySummary>) {
        val obj = JSONObject()
        map.keys.sorted().forEach { k ->
            val s = map[k] ?: return@forEach
            val o = JSONObject()
            o.put("total", s.total)
            o.put("tips", s.tips)
            o.put("cash", s.cash)
            o.put("camp", s.camp)
            obj.put(k, o)
        }
        p(ctx).edit().putString("bolt_days_json", obj.toString()).commit()
    }

    @Synchronized
    fun upsertBoltDay(ctx: Context, summary: BoltDaySummary) {
        val map = getBoltDays(ctx)
        map[summary.dateKey] = summary.copy(
            total = round2(summary.total),
            tips = round2(summary.tips),
            cash = round2(summary.cash),
            camp = round2(summary.camp)
        )
        saveBoltDays(ctx, map)
    }

    @Synchronized
    fun getBoltWeeks(ctx: Context): MutableMap<String, BoltWeekSummary> {
        val raw = p(ctx).getString("bolt_weeks_json", "{}") ?: "{}"
        val map = LinkedHashMap<String, BoltWeekSummary>()
        try {
            val obj = JSONObject(raw)
            val keys = obj.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                val item = obj.getJSONObject(k)
                map[k] = BoltWeekSummary(
                    weekStartKey = k,
                    total = item.optDouble("total", 0.0),
                    tips = item.optDouble("tips", 0.0),
                    cash = item.optDouble("cash", 0.0)
                )
            }
        } catch (_: Exception) {}
        return map
    }

    @Synchronized
    fun saveBoltWeeks(ctx: Context, map: Map<String, BoltWeekSummary>) {
        val obj = JSONObject()
        map.keys.sorted().forEach { k ->
            val w = map[k] ?: return@forEach
            val o = JSONObject()
            o.put("total", w.total)
            o.put("tips", w.tips)
            o.put("cash", w.cash)
            obj.put(k, o)
        }
        p(ctx).edit().putString("bolt_weeks_json", obj.toString()).commit()
    }

    @Synchronized
    fun deleteBoltDay(ctx: Context, dateKey: String) {
        val map = getBoltDays(ctx)
        map.remove(dateKey)
        saveBoltDays(ctx, map)
    }

    @Synchronized
    fun deleteBoltWeek(ctx: Context, weekStartKey: String) {
        val mon = mondayKeyForMillis(parseDateKeyToMillis(weekStartKey, false))
        val map = getBoltWeeks(ctx)
        map.remove(mon)
        saveBoltWeeks(ctx, map)
    }

    @Synchronized
    fun upsertBoltWeek(ctx: Context, summary: BoltWeekSummary) {
        val monday = mondayKeyForMillis(parseDateKeyToMillis(summary.weekStartKey, false))
        val map = getBoltWeeks(ctx)
        map[monday] = BoltWeekSummary(
            weekStartKey = monday,
            total = round2(summary.total),
            tips = round2(summary.tips),
            cash = round2(summary.cash)
        )
        saveBoltWeeks(ctx, map)
    }

    fun isBundledDismissed(ctx: Context): Boolean = p(ctx).getBoolean("bundled_dismissed", false)
    fun setBundledDismissed(ctx: Context, dismissed: Boolean) = p(ctx).edit().putBoolean("bundled_dismissed", dismissed).commit()

    fun loadBundledTripsFromAssets(ctx: Context): List<RideEntry> {
        val out = ArrayList<RideEntry>()
        try {
            val raw = ctx.assets.open("bundled_trips.json").bufferedReader(Charsets.UTF_8).use { it.readText() }
            val arr = JSONArray(raw)
            val sdfIso = SimpleDateFormat("yyyy-MM-dd'T'HH:mm", Locale.US)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val id = o.optString("id", "BUNDLED-$i")
                val iso = o.optString("iso", "")
                val ts = try { sdfIso.parse(iso)?.time ?: 0L } catch (_: Exception) { 0L }
                val cash = o.optBoolean("cash", false)
                val net = o.optDouble("net", 0.0)
                val gross = o.optDouble("gross", 0.0)
                if (ts > 0L && gross > 0.0) {
                    val effectiveAmt = if (net > 0.0) net else gross
                    out.add(
                        RideEntry(
                            id = id,
                            timestamp = ts,
                            acceptedTimestamp = ts,
                            priceGrosze = plnToGrosze(effectiveAmt),
                            tripKm = 0.0,
                            pickupKm = 0.0,
                            offerMin = 0,
                            status = OfferStatus.ACCEPTED,
                            destination = if (cash) "Gotówka (paczka)" else "Karta/Aplikacja (paczka)",
                            source = if (cash) "CASH_BUNDLE" else "CSV_BUNDLE"
                        )
                    )
                }
            }
        } catch (_: Exception) {}
        return out
    }

    @Synchronized
    fun restoreBundledTrips(ctx: Context): Int {
        setBundledDismissed(ctx, false)
        val bundled = loadBundledTripsFromAssets(ctx)
        val existing = RadarStorage.getHistory(ctx)
        val existingIds = existing.map { it.id }.toHashSet()
        var added = 0
        for (item in bundled) {
            if (!existingIds.contains(item.id)) {
                existing.add(item)
                existingIds.add(item.id)
                added++
            }
        }
        if (added > 0) {
            RadarStorage.saveHistory(ctx, existing)
        }
        return added
    }

    fun importCsvFilesOffline(ctx: Context, uris: List<Uri>): Int {
        val parsedList = ArrayList<RideEntry>()
        val formats = listOf(
            SimpleDateFormat("dd.MM.yyyy HH:mm:ss", Locale.US),
            SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.US),
            SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US),
            SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US)
        )

        for (uri in uris) {
            try {
                ctx.contentResolver.openInputStream(uri)?.use { stream ->
                    val lines = BufferedReader(InputStreamReader(stream, Charsets.UTF_8)).readLines()
                    if (lines.isEmpty()) return@use
                    val header = lines[0].replace("\uFEFF", "")
                    val sep = if (header.count { it == ';' } > header.count { it == ',' }) ';' else ','

                    for (line in lines.drop(1)) {
                        if (line.isBlank()) continue
                        val cols = splitCsvLine(line, sep)
                        if (cols.size < 3) continue
                        val rawId = cols[0].trim()
                        var ts = 0L
                        for (idx in cols.indices) {
                            val candidate = cols[idx].trim().replace("T", " ")
                            for (fmt in formats) {
                                ts = try { fmt.parse(candidate)?.time ?: 0L } catch (_: Exception) { 0L }
                                if (ts > 0L) break
                            }
                            if (ts > 0L) break
                        }
                        if (ts <= 0L) continue

                        val nums = ArrayList<Double>()
                        for (c in cols) {
                            val cleaned = c.replace("\u00A0", "").replace(" ", "").replace(",", ".").trim()
                            val v = cleaned.toDoubleOrNull()
                            if (v != null && v.isFinite()) nums.add(v)
                        }
                        if (nums.isEmpty()) continue
                        val amount = if (nums.size >= 3) nums[nums.size - 3] else nums.last()
                        if (amount <= 0.0) continue

                        val isCash = line.lowercase(Locale("pl", "PL")).contains("got")
                        val stableId = if (rawId.isNotEmpty()) rawId else "CSV_${ts}_${plnToGrosze(amount)}"

                        parsedList.add(
                            RideEntry(
                                id = stableId,
                                timestamp = ts,
                                acceptedTimestamp = ts,
                                priceGrosze = plnToGrosze(amount),
                                tripKm = 0.0,
                                pickupKm = 0.0,
                                offerMin = 0,
                                status = OfferStatus.ACCEPTED,
                                destination = if (isCash) "Gotówka (CSV)" else "Karta/Aplikacja (CSV)",
                                source = "CSV"
                            )
                        )
                    }
                }
            } catch (_: Exception) {}
        }

        val existing = RadarStorage.getHistory(ctx)
        val seenIds = existing.map { it.id }.toHashSet()
        var added = 0
        for (item in parsedList) {
            if (!seenIds.contains(item.id)) {
                existing.add(item)
                seenIds.add(item.id)
                added++
            }
        }
        if (added > 0) {
            RadarStorage.saveHistory(ctx, existing)
        }
        return added
    }

    private fun splitCsvLine(line: String, sep: Char): List<String> {
        val out = ArrayList<String>()
        val sb = StringBuilder()
        var inQuotes = false
        for (ch in line) {
            when {
                ch == '"' -> inQuotes = !inQuotes
                ch == sep && !inQuotes -> {
                    out.add(sb.toString().trim().trim('"'))
                    sb.clear()
                }
                else -> sb.append(ch)
            }
        }
        out.add(sb.toString().trim().trim('"'))
        return out
    }

    fun calculatePeriodSummary(
        ctx: Context,
        fromKey: String,
        toKey: String,
        sharePercent: Float,
        calcMode: String
    ): PeriodStatsSummary {
        val fromMs = parseDateKeyToMillis(fromKey, false)
        val toMs = parseDateKeyToMillis(toKey, true)
        val share = (sharePercent.toDouble() / 100.0).coerceIn(0.45, 0.55)

        val allTrips = RadarStorage.getHistory(ctx).filter {
            it.source != "SCREEN" &&
                (it.normalizedStatus == OfferStatus.ACCEPTED || it.source == "CSV" || it.source == "CSV_BUNDLE" || it.source == "CASH_BUNDLE")
        }

        val periodTrips = allTrips.filter { r ->
            val t = r.effectiveTimestamp
            t > 0L && (fromMs <= 0L || t >= fromMs) && (toMs <= 0L || t <= toMs)
        }.sortedBy { it.effectiveTimestamp }

        // Grupowanie zmian (przerwa > 6h rozpoczyna nową zmianę)
        val shifts = ArrayList<List<RideEntry>>()
        var curShift = ArrayList<RideEntry>()
        for (r in periodTrips) {
            if (curShift.isEmpty()) {
                curShift.add(r)
            } else {
                val gap = r.effectiveTimestamp - curShift.last().effectiveTimestamp
                if (gap > 6L * 3600_000L) {
                    shifts.add(curShift)
                    curShift = ArrayList()
                }
                curShift.add(r)
            }
        }
        if (curShift.isNotEmpty()) shifts.add(curShift)

        var totalShiftMin = 0L
        val activeShiftDays = LinkedHashSet<String>()
        for (sh in shifts) {
            if (sh.size >= 2) {
                val durMin = ((sh.last().effectiveTimestamp - sh.first().effectiveTimestamp) / 60_000L).coerceAtLeast(1L)
                totalShiftMin += durMin
            }
            activeShiftDays.add(dayKeyFromMillis(sh.first().effectiveTimestamp))
        }

        val csvTurnover = round2(periodTrips.sumOf { it.priceGross })
        val csvDriverNetPart = round2(csvTurnover * share)

        val boltDays = getBoltDays(ctx)
        val boltWeeks = getBoltWeeks(ctx)

        // Sumowanie screenów dziennych i tygodniowych w zakresie
        val coveredDaysByWeek = HashMap<String, ArrayList<BoltDaySummary>>()
        for ((dk, dSum) in boltDays) {
            val ms = parseDateKeyToMillis(dk, false)
            if (ms > 0L && (fromMs <= 0L || ms >= fromMs) && (toMs <= 0L || ms <= toMs)) {
                val wk = mondayKeyForMillis(ms)
                coveredDaysByWeek.getOrPut(wk) { ArrayList() }.add(dSum)
            }
        }

        var screensTotalBolt = 0.0
        var screensTips = 0.0
        var screensCash = 0.0
        val notes = ArrayList<String>()

        val allWeekStarts = TreeSet<String>()
        allWeekStarts.addAll(coveredDaysByWeek.keys)
        for ((wk, _) in boltWeeks) {
            val wStartMs = parseDateKeyToMillis(wk, false)
            val wEndMs = parseDateKeyToMillis(addDaysToKey(wk, 6), true)
            val overlaps = (fromMs <= 0L || wEndMs >= fromMs) && (toMs <= 0L || wStartMs <= toMs)
            if (overlaps) allWeekStarts.add(wk)
        }

        for (wk in allWeekStarts) {
            val wScreen = boltWeeks[wk]
            val dList = coveredDaysByWeek[wk] ?: emptyList()
            val daysSum = round2(dList.sumOf { it.total })
            if (wScreen != null) {
                screensTotalBolt += wScreen.total
                screensTips += wScreen.tips
                screensCash += wScreen.cash
                if (dList.isNotEmpty() && abs(daysSum - wScreen.total) > 0.05) {
                    val diff = round2(abs(daysSum - wScreen.total))
                    notes.add(
                        "Tydzień ${formatWeekRange(wk)}: suma dni (${formatMoneyPl(daysSum)}) różni się od screena tygodniowego (${formatMoneyPl(wScreen.total)}) o ${formatMoneyPl(diff)}. Liczone ze screena tygodniowego."
                    )
                }
            } else {
                screensTotalBolt += daysSum
                screensTips += dList.sumOf { it.tips }
                screensCash += dList.sumOf { it.cash }
            }
        }

        val screenPay = calculatePay(screensTotalBolt, screensTips, screensCash, sharePercent)
        val hoursEstimated = if (totalShiftMin > 0L) totalShiftMin / 60.0 else 0.0
        val avgHourlyCsv = if (hoursEstimated > 0.05) round2(csvDriverNetPart / hoursEstimated) else 0.0
        val avgHourlyScreens = if (hoursEstimated > 0.05) round2(screenPay.earned / hoursEstimated) else 0.0

        val activeDaysCount = if (calcMode == "csv") {
            activeShiftDays.size
        } else {
            val sDays = LinkedHashSet<String>()
            sDays.addAll(activeShiftDays)
            sDays.addAll(coveredDaysByWeek.values.flatten().map { it.dateKey })
            sDays.size
        }

        val shiftsCount = shifts.size
        val avgShiftMin = if (shiftsCount > 0) totalShiftMin / shiftsCount else 0L

        val displayTurnover = if (calcMode == "csv") csvTurnover else round2(screensTotalBolt)
        val displayNetPart = if (calcMode == "csv") csvDriverNetPart else screenPay.driverShare

        return PeriodStatsSummary(
            label = "${formatShortDate(fromKey)} – ${formatShortDate(toKey)}",
            fromKey = fromKey,
            toKey = toKey,
            tripsCount = periodTrips.size,
            activeDriveDays = activeDaysCount,
            turnoverGross = displayTurnover,
            netDriverPart = displayNetPart,
            estimatedMinutes = totalShiftMin,
            shiftsCount = shiftsCount,
            avgShiftMinutes = avgShiftMin,
            avgHourlyCsv = avgHourlyCsv,
            avgHourlyScreens = avgHourlyScreens,
            pay = screenPay,
            weekDiscrepancyNote = notes.firstOrNull()
        )
    }

    fun formatMoneyPl(v: Double): String {
        return String.format(Locale("pl", "PL"), "%.2f zł", round2(v))
    }

    fun formatHoursMinutes(totalMinutes: Long): String {
        val m = totalMinutes.coerceAtLeast(0L)
        return "${m / 60L} h ${m % 60L} min"
    }

    @Synchronized
    fun snapshotUndo(ctx: Context, actionLabel: String) {
        val root = JSONObject()
        root.put("t", System.currentTimeMillis())
        root.put("label", actionLabel)
        root.put("dismissed", isBundledDismissed(ctx))

        val histArr = JSONArray()
        for (r in RadarStorage.getHistory(ctx)) {
            val o = JSONObject()
            o.put("id", r.id)
            o.put("t", r.timestamp)
            o.put("acc_t", r.acceptedTimestamp)
            o.put("price_grosze", r.priceGrosze)
            o.put("tkm", r.tripKm)
            o.put("pkm", r.pickupKm)
            o.put("min", r.offerMin)
            o.put("status", r.status)
            o.put("dest", r.destination)
            o.put("pickup_addr", r.pickupAddress)
            o.put("rate_c", r.rateCourse)
            o.put("rate_p", r.rateWithPickup)
            o.put("src", r.source)
            histArr.put(o)
        }
        root.put("history", histArr)

        val daysObj = JSONObject()
        for ((k, s) in getBoltDays(ctx)) {
            val o = JSONObject()
            o.put("total", s.total)
            o.put("tips", s.tips)
            o.put("cash", s.cash)
            o.put("camp", s.camp)
            daysObj.put(k, o)
        }
        root.put("bolt_days", daysObj)

        val weeksObj = JSONObject()
        for ((k, w) in getBoltWeeks(ctx)) {
            val o = JSONObject()
            o.put("total", w.total)
            o.put("tips", w.tips)
            o.put("cash", w.cash)
            weeksObj.put(k, o)
        }
        root.put("bolt_weeks", weeksObj)
        p(ctx).edit().putString("last_undo_json", root.toString()).commit()
    }

    fun getUndoInfo(ctx: Context): Pair<String, Long>? {
        val raw = p(ctx).getString("last_undo_json", null) ?: return null
        return try {
            val o = JSONObject(raw)
            val lbl = o.optString("label", "")
            val t = o.optLong("t", 0L)
            if (lbl.isBlank() || t <= 0L) null else Pair(lbl, t)
        } catch (_: Exception) {
            null
        }
    }

    @Synchronized
    fun performUndo(ctx: Context): Boolean {
        val raw = p(ctx).getString("last_undo_json", null) ?: return false
        return try {
            val root = JSONObject(raw)
            setBundledDismissed(ctx, root.optBoolean("dismissed", false))

            val histArr = root.optJSONArray("history") ?: JSONArray()
            val restoredList = ArrayList<RideEntry>(histArr.length())
            for (i in 0 until histArr.length()) {
                val o = histArr.getJSONObject(i)
                restoredList.add(
                    RideEntry(
                        id = o.optString("id"),
                        timestamp = o.optLong("t", 0L),
                        acceptedTimestamp = o.optLong("acc_t", 0L),
                        priceGrosze = o.optLong("price_grosze", 0L),
                        tripKm = o.optDouble("tkm", 0.0),
                        pickupKm = o.optDouble("pkm", 0.0),
                        offerMin = o.optInt("min", 0),
                        status = o.optString("status", OfferStatus.UNDECIDED),
                        destination = o.optString("dest", "Kraków"),
                        pickupAddress = o.optString("pickup_addr", ""),
                        rateCourse = o.optDouble("rate_c", 0.0),
                        rateWithPickup = o.optDouble("rate_p", 0.0),
                        source = o.optString("src", "RADAR")
                    )
                )
            }
            RadarStorage.saveHistory(ctx, restoredList)

            val daysObj = root.optJSONObject("bolt_days") ?: JSONObject()
            val restoredDays = LinkedHashMap<String, BoltDaySummary>()
            val dKeys = daysObj.keys()
            while (dKeys.hasNext()) {
                val k = dKeys.next()
                val d = daysObj.getJSONObject(k)
                restoredDays[k] = BoltDaySummary(
                    dateKey = k,
                    total = d.optDouble("total", 0.0),
                    tips = d.optDouble("tips", 0.0),
                    cash = d.optDouble("cash", 0.0),
                    camp = d.optDouble("camp", 0.0)
                )
            }
            saveBoltDays(ctx, restoredDays)

            val weeksObj = root.optJSONObject("bolt_weeks") ?: JSONObject()
            val restoredWeeks = LinkedHashMap<String, BoltWeekSummary>()
            val wKeys = weeksObj.keys()
            while (wKeys.hasNext()) {
                val k = wKeys.next()
                val w = weeksObj.getJSONObject(k)
                restoredWeeks[k] = BoltWeekSummary(
                    weekStartKey = k,
                    total = w.optDouble("total", 0.0),
                    tips = w.optDouble("tips", 0.0),
                    cash = w.optDouble("cash", 0.0)
                )
            }
            saveBoltWeeks(ctx, restoredWeeks)

            p(ctx).edit().remove("last_undo_json").commit()
            true
        } catch (_: Exception) {
            false
        }
    }

    fun exportBackupJson(ctx: Context, outStream: OutputStream): Boolean {
        return try {
            val root = JSONObject()
            root.put("app", "KursRadar")
            root.put("version", 2)
            root.put("exported_at", System.currentTimeMillis())
            root.put("share_percent", RadarOptions.driverSharePercent(ctx))
            root.put("calc_mode", RadarOptions.calcMode(ctx))
            root.put("dismissed_bundled", isBundledDismissed(ctx))
            root.put("partner_anchor_monday", partnerCycleAnchorMonday(ctx))

            val histArr = JSONArray()
            for (r in RadarStorage.getHistory(ctx)) {
                val o = JSONObject()
                o.put("id", r.id)
                o.put("t", r.timestamp)
                o.put("acc_t", r.acceptedTimestamp)
                o.put("price_grosze", r.priceGrosze)
                o.put("tkm", r.tripKm)
                o.put("pkm", r.pickupKm)
                o.put("min", r.offerMin)
                o.put("status", r.status)
                o.put("dest", r.destination)
                o.put("pickup_addr", r.pickupAddress)
                o.put("rate_c", r.rateCourse)
                o.put("rate_p", r.rateWithPickup)
                o.put("src", r.source)
                histArr.put(o)
            }
            root.put("history", histArr)

            val daysArr = JSONArray()
            for ((_, s) in getBoltDays(ctx)) {
                val o = JSONObject()
                o.put("date", s.dateKey)
                o.put("total", s.total)
                o.put("tips", s.tips)
                o.put("cash", s.cash)
                o.put("camp", s.camp)
                daysArr.put(o)
            }
            root.put("bolt_days", daysArr)

            val weeksArr = JSONArray()
            for ((_, w) in getBoltWeeks(ctx)) {
                val o = JSONObject()
                o.put("week_start", w.weekStartKey)
                o.put("total", w.total)
                o.put("tips", w.tips)
                o.put("cash", w.cash)
                weeksArr.put(o)
            }
            root.put("bolt_weeks", weeksArr)

            outStream.write(root.toString(2).toByteArray(Charsets.UTF_8))
            outStream.flush()
            true
        } catch (_: Exception) {
            false
        }
    }

    fun importBackupJson(ctx: Context, uri: Uri): Pair<Boolean, String> {
        return try {
            val raw = ctx.contentResolver.openInputStream(uri)?.use {
                BufferedReader(InputStreamReader(it, Charsets.UTF_8)).readText()
            } ?: return Pair(false, "Nie udało się odczytać pliku.")
            val root = JSONObject(raw)

            if (root.has("share_percent")) {
                RadarOptions.setDriverSharePercent(ctx, root.optDouble("share_percent", 50.0).toFloat())
            }
            if (root.has("calc_mode")) {
                RadarOptions.setCalcMode(ctx, root.optString("calc_mode", "bolt"))
            }
            if (root.has("dismissed_bundled")) {
                setBundledDismissed(ctx, root.optBoolean("dismissed_bundled", false))
            }
            if (root.has("partner_anchor_monday")) {
                setPartnerCycleAnchorMonday(ctx, root.optString("partner_anchor_monday", mondayKeyForMillis(System.currentTimeMillis())))
            }

            val histArr = root.optJSONArray("history")
            if (histArr != null) {
                val importedList = ArrayList<RideEntry>(histArr.length())
                for (i in 0 until histArr.length()) {
                    val o = histArr.getJSONObject(i)
                    importedList.add(
                        RideEntry(
                            id = o.optString("id").ifEmpty { UUID.randomUUID().toString() },
                            timestamp = o.optLong("t", 0L),
                            acceptedTimestamp = o.optLong("acc_t", 0L),
                            priceGrosze = o.optLong("price_grosze", 0L),
                            tripKm = o.optDouble("tkm", 0.0),
                            pickupKm = o.optDouble("pkm", 0.0),
                            offerMin = o.optInt("min", 0),
                            status = o.optString("status", OfferStatus.UNDECIDED),
                            destination = o.optString("dest", "Kraków"),
                            pickupAddress = o.optString("pickup_addr", ""),
                            rateCourse = o.optDouble("rate_c", 0.0),
                            rateWithPickup = o.optDouble("rate_p", 0.0),
                            source = o.optString("src", "RADAR")
                        )
                    )
                }
                RadarStorage.saveHistory(ctx, importedList)
            }

            val daysArr = root.optJSONArray("bolt_days")
            if (daysArr != null) {
                val map = LinkedHashMap<String, BoltDaySummary>()
                for (i in 0 until daysArr.length()) {
                    val d = daysArr.getJSONObject(i)
                    val dk = d.optString("date", "")
                    if (dk.isNotBlank()) {
                        map[dk] = BoltDaySummary(
                            dateKey = dk,
                            total = d.optDouble("total", 0.0),
                            tips = d.optDouble("tips", 0.0),
                            cash = d.optDouble("cash", 0.0),
                            camp = d.optDouble("camp", 0.0)
                        )
                    }
                }
                saveBoltDays(ctx, map)
            }

            val weeksArr = root.optJSONArray("bolt_weeks")
            if (weeksArr != null) {
                val wMap = LinkedHashMap<String, BoltWeekSummary>()
                for (i in 0 until weeksArr.length()) {
                    val w = weeksArr.getJSONObject(i)
                    val wk = w.optString("week_start", "")
                    if (wk.isNotBlank()) {
                        val mon = mondayKeyForMillis(parseDateKeyToMillis(wk, false))
                        wMap[mon] = BoltWeekSummary(
                            weekStartKey = mon,
                            total = w.optDouble("total", 0.0),
                            tips = w.optDouble("tips", 0.0),
                            cash = w.optDouble("cash", 0.0)
                        )
                    }
                }
                saveBoltWeeks(ctx, wMap)
            }

            Pair(true, "Przywrócono kopię zapasową offline.")
        } catch (e: Exception) {
            Pair(false, "Błąd wczytywania kopii: ${e.message}")
        }
    }

    fun buildDayStats(ctx: Context, sharePercent: Float, calcMode: String): List<DayStat> {
        val history = RadarStorage.getHistory(ctx)
        val boltDays = getBoltDays(ctx)
        val share = (sharePercent.toDouble() / 100.0).coerceIn(0.45, 0.55)

        val tripsByDay = LinkedHashMap<String, ArrayList<RideEntry>>()
        for (r in history) {
            if (r.source == "SCREEN") continue
            if (r.normalizedStatus != OfferStatus.ACCEPTED && r.source != "CSV" && r.source != "CSV_BUNDLE" && r.source != "CASH_BUNDLE") continue
            val dk = dayKeyFromMillis(r.effectiveTimestamp)
            tripsByDay.getOrPut(dk) { ArrayList() }.add(r)
        }

        val allKeys = TreeSet<String>()
        allKeys.addAll(tripsByDay.keys)
        if (calcMode == "bolt") {
            allKeys.addAll(boltDays.keys)
        }

        val sdfShort = SimpleDateFormat("EEE dd.MM", Locale("pl", "PL"))
        val result = ArrayList<DayStat>(allKeys.size)

        for (dk in allKeys) {
            val dayTrips = tripsByDay[dk] ?: emptyList()
            val bSummary = boltDays[dk]
            val ms = parseDateKeyToMillis(dk, false)
            val dayNum = try { dk.split("-")[2].toInt() } catch (_: Exception) { 1 }
            val labelShort = if (ms > 0L) sdfShort.format(Date(ms)) else dk

            var tripsGross = 0.0
            var cashGross = 0.0
            for (t in dayTrips) {
                val g = t.priceGross
                tripsGross += g
                val isCash = t.source == "CASH_BUNDLE" || t.destination.lowercase(Locale("pl", "PL")).contains("got")
                if (isCash) cashGross += g
            }
            val cardGross = (tripsGross - cashGross).coerceAtLeast(0.0)

            val (grossOut, earnedOut, srcTag) = if (calcMode == "bolt" && bSummary != null) {
                val pay = calculatePay(bSummary.total, bSummary.tips, bSummary.cash, sharePercent)
                Triple(bSummary.total, pay.earned, "Screen Bolta")
            } else {
                val est = round2(tripsGross * share)
                Triple(round2(tripsGross), est, "CSV / Historia")
            }

            result.add(
                DayStat(
                    dateKey = dk,
                    labelShort = labelShort,
                    dayOfMonth = dayNum,
                    tripsCount = dayTrips.size,
                    acceptedCount = dayTrips.count { it.normalizedStatus == OfferStatus.ACCEPTED },
                    grossSum = grossOut,
                    cashSum = round2(cashGross),
                    cardSum = round2(cardGross),
                    estimatedDriverEarned = earnedOut,
                    sourceTag = srcTag
                )
            )
        }
        return result
    }

    fun buildHourStats(ctx: Context, sharePercent: Float): List<HourStat> {
        val share = (sharePercent.toDouble() / 100.0).coerceIn(0.45, 0.55)
        val counts = IntArray(24)
        val grossByHour = DoubleArray(24)
        val cal = Calendar.getInstance()

        for (r in RadarStorage.getHistory(ctx)) {
            if (r.source == "SCREEN") continue
            if (r.normalizedStatus != OfferStatus.ACCEPTED && r.source != "CSV" && r.source != "CSV_BUNDLE" && r.source != "CASH_BUNDLE") continue
            val ts = r.effectiveTimestamp
            if (ts <= 0L) continue
            cal.timeInMillis = ts
            val h = cal.get(Calendar.HOUR_OF_DAY).coerceIn(0, 23)
            counts[h]++
            grossByHour[h] += r.priceGross
        }

        return (0..23).map { h ->
            val g = round2(grossByHour[h])
            HourStat(
                hour = h,
                label = String.format(Locale.US, "%02d:00", h),
                tripsCount = counts[h],
                grossSum = g,
                estimatedDriverEarned = round2(g * share)
            )
        }
    }

    data class ParsedBoltSummaryDraft(
        val dateKey: String,
        val isWeek: Boolean,
        val total: Double,
        val tips: Double,
        val cash: Double,
        val notes: List<String>
    )

    fun parseBoltSummaryTextOffline(rawText: String): ParsedBoltSummaryDraft {
        val notes = ArrayList<String>()
        val lines = rawText.lines().map { it.trim() }.filter { it.isNotEmpty() }
        val amtRegex = Regex("""(?<![A-Za-z0-9])(\d{1,5}(?:[.,]\d{1,2})?)(?!\s*/|\s*km|\s*min)""")

        fun extractAmount(matchLine: String): Double? {
            val clean = matchLine.replace("\u00A0", " ")
            return amtRegex.findAll(clean)
                .mapNotNull { it.groupValues[1].replace(",", ".").toDoubleOrNull() }
                .lastOrNull()
        }

        var totalVal: Double? = null
        var tipsVal: Double? = null
        var cashVal: Double? = null

        for (i in lines.indices) {
            val l = lines[i].lowercase(Locale("pl", "PL"))
            val nextLine = if (i + 1 < lines.size) lines[i + 1] else ""
            val vHere = extractAmount(lines[i])
            val vNext = extractAmount(nextLine)
            val chosen = vHere ?: vNext

            when {
                totalVal == null && (l.contains("twoje zarobki") || l.contains("zarobki") || l.contains("przychody")) && chosen != null -> {
                    totalVal = chosen
                }
                tipsVal == null && (l.contains("napiwk") || l.contains("napiw")) && chosen != null -> {
                    tipsVal = chosen
                }
                cashVal == null && (l.contains("got") || l.contains("płatności gotówką") || l.contains("platnosci gotowka")) && chosen != null -> {
                    cashVal = chosen
                }
            }
        }

        if (totalVal == null) {
            val allNums = amtRegex.findAll(rawText.replace("\u00A0", " "))
                .mapNotNull { it.groupValues[1].replace(",", ".").toDoubleOrNull() }
                .filter { it in 1.0..50000.0 }
                .toList()
            if (allNums.isNotEmpty()) {
                totalVal = allNums.maxOrNull()
                notes.add("Nie znaleziono etykiety zarobków — podstawiono największą kwotę (${formatMoneyPl(totalVal ?: 0.0)}), sprawdź ręcznie.")
            } else {
                totalVal = 0.0
                notes.add("Nie wykryto kwot w tekście — wpisz wartości ręcznie.")
            }
        }

        val tFinal = round2(tipsVal ?: 0.0)
        val cFinal = round2(cashVal ?: 0.0)
        val bFinal = round2(totalVal ?: 0.0)

        val dateMatch = Regex("""(\d{4}-\d{2}-\d{2})""").find(rawText)
        val dmyMatch = Regex("""\b(\d{1,2})[./-](\d{1,2})[./-](20\d{2})\b""").find(rawText)
        val detectedDateKey = when {
            dateMatch != null -> dateMatch.groupValues[1]
            dmyMatch != null -> {
                val d = dmyMatch.groupValues[1].toInt().coerceIn(1, 31)
                val mo = dmyMatch.groupValues[2].toInt().coerceIn(1, 12)
                val yr = dmyMatch.groupValues[3].toInt()
                String.format(Locale.US, "%04d-%02d-%02d", yr, mo, d)
            }
            else -> {
                notes.add("Nie wykryto daty na podsumowaniu — podstawiono dzisiejszą datę.")
                dayKeyFromMillis(System.currentTimeMillis())
            }
        }

        val isWeek = rawText.lowercase(Locale("pl", "PL")).contains("tydzie") ||
            Regex("""\d{1,2}\s*[–-]\s*\d{1,2}""").containsMatchIn(rawText)

        return ParsedBoltSummaryDraft(
            dateKey = detectedDateKey,
            isWeek = isWeek,
            total = bFinal,
            tips = tFinal,
            cash = cFinal,
            notes = notes
        )
    }
}
