package com.example.kalkulatorkursow

import android.Manifest
import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import androidx.core.content.ContextCompat
import java.util.Locale

class WorkSessionService : Service() {

    companion object {
        const val ACTION_START = "com.example.kalkulatorkursow.action.START_SESSION"
        const val ACTION_STOP = "com.example.kalkulatorkursow.action.STOP_SESSION"
        private const val NOTIF_ID = 7001
        private const val CHANNEL_ID = "kursradar_session"

        @Volatile
        var isRunning: Boolean = false

        @Volatile
        var lastKnownLocation: Location? = null

        @Volatile
        private var instance: WorkSessionService? = null

        fun refreshNow() {
            val svc = instance ?: return
            try {
                svc.handler.post { svc.updateNotificationOnly() }
            } catch (_: Exception) {
            }
        }

        fun start(ctx: Context) {
            try {
                val intent = Intent(ctx.applicationContext, WorkSessionService::class.java).apply {
                    action = ACTION_START
                }
                ContextCompat.startForegroundService(ctx.applicationContext, intent)
            } catch (_: Exception) {
            }
        }

        fun stop(ctx: Context) {
            try {
                val intent = Intent(ctx.applicationContext, WorkSessionService::class.java).apply {
                    action = ACTION_STOP
                }
                ctx.applicationContext.startService(intent)
            } catch (_: Exception) {
                try {
                    ctx.applicationContext.stopService(Intent(ctx.applicationContext, WorkSessionService::class.java))
                } catch (_: Exception) {
                }
            }
        }
    }

    private val handler = Handler(Looper.getMainLooper())
    private var locationManager: LocationManager? = null
    private var locationActive = false
    private var countLast: Location? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var lastWakeRenewMs = 0L
    private var channelCreated = false

    private val locListener = object : LocationListener {
        override fun onLocationChanged(location: Location) {
            lastKnownLocation = location
            if (!RadarStorage.isSessionRunning(this@WorkSessionService)) return
            if (location.hasAccuracy() && location.accuracy > 35f) return
            val prev = countLast
            if (prev != null) {
                val d = prev.distanceTo(location)
                val dtSec = ((location.time - prev.time) / 1000.0).coerceAtLeast(1.0)
                val speedMps = d / dtSec
                if (d >= 3.0f && d <= 15_000f && speedMps <= 55.6) {
                    RadarStorage.addGpsDistanceMeters(this@WorkSessionService, d)
                }
            }
            countLast = location
        }
    }

    private val watchdog = object : Runnable {
        override fun run() {
            if (!RadarStorage.isSessionRunning(this@WorkSessionService)) {
                stopSelfClean()
                return
            }
            acquireWakeLock()
            startLocationIfNeeded()
            updateNotificationOnly()
            RideScannerService.pingFromWatchdog()
            handler.postDelayed(this, 2000L)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        locationManager = getSystemService(LOCATION_SERVICE) as? LocationManager
        isRunning = true
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP || !RadarStorage.isSessionRunning(this)) {
            stopSelfClean()
            return START_NOT_STICKY
        }
        isRunning = true
        ensureForeground(buildNotification())
        acquireWakeLock()
        startLocationIfNeeded()
        handler.removeCallbacks(watchdog)
        handler.post(watchdog)
        return START_STICKY
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        super.onTaskRemoved(rootIntent)
        if (RadarStorage.isSessionRunning(this)) {
            start(applicationContext)
        }
    }

    override fun onDestroy() {
        if (instance === this) instance = null
        isRunning = false
        handler.removeCallbacks(watchdog)
        stopLocation()
        releaseWakeLock()
        super.onDestroy()
    }

    private fun stopSelfClean() {
        isRunning = false
        handler.removeCallbacks(watchdog)
        stopLocation()
        releaseWakeLock()
        try {
            stopForeground(STOP_FOREGROUND_REMOVE)
        } catch (_: Exception) {
        }
        try {
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).cancel(NOTIF_ID)
        } catch (_: Exception) {
        }
        stopSelf()
    }

    private fun hasLocationPermission(): Boolean {
        val fine = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val coarse = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        return fine || coarse
    }

    private fun startLocationIfNeeded() {
        if (locationActive || !hasLocationPermission()) return
        val lm = locationManager ?: return
        try {
            if (lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 2000L, 4f, locListener)
                locationActive = true
                countLast = null
            }
        } catch (_: Exception) {
        }
    }

    private fun stopLocation() {
        if (!locationActive) return
        try {
            locationManager?.removeUpdates(locListener)
        } catch (_: Exception) {
        }
        locationActive = false
        countLast = null
    }

    @SuppressLint("WakelockTimeout")
    private fun acquireWakeLock() {
        try {
            val now = SystemClock.elapsedRealtime()
            if (wakeLock?.isHeld == true && now - lastWakeRenewMs < 4 * 60_000L) return
            if (wakeLock == null) {
                val pm = getSystemService(POWER_SERVICE) as? PowerManager
                wakeLock = pm?.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "ScanBolt::WorkSessionWakeLock")
                    ?.apply { setReferenceCounted(false) }
            }
            wakeLock?.acquire(10 * 60_000L)
            lastWakeRenewMs = now
        } catch (_: Exception) {
        }
    }

    private fun releaseWakeLock() {
        try {
            if (wakeLock?.isHeld == true) wakeLock?.release()
        } catch (_: Exception) {
        }
    }

    private fun ensureForeground(n: Notification) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            val types = mutableListOf<Int>()
            if (hasLocationPermission()) types += ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION
            types += ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            for (t in types) {
                try {
                    startForeground(NOTIF_ID, n, t)
                    return
                } catch (_: Exception) {
                }
            }
        } else {
            try {
                startForeground(NOTIF_ID, n)
                return
            } catch (_: Exception) {
            }
        }
        try {
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(NOTIF_ID, n)
        } catch (_: Exception) {
        }
    }

    private fun updateNotificationOnly() {
        try {
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            nm.notify(NOTIF_ID, buildNotification())
        } catch (_: Exception) {
        }
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (!channelCreated) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "Praca kierowcy", NotificationManager.IMPORTANCE_LOW)
            )
            channelCreated = true
        }
        val start = RadarStorage.getSessionStartTime(this)
        val sec = ((System.currentTimeMillis() - start) / 1000L).coerceAtLeast(0L)
        val time = String.format(Locale.US, "%02d:%02d:%02d", sec / 3600, (sec % 3600) / 60, sec % 60)
        val km = RadarStorage.getGpsDistanceMeters(this) / 1000.0
        val (count, gross) = RadarStorage.getCurrentSessionAcceptedStats(this)
        val netEst = gross * 0.93
        val scannerInfo = if (RideScannerService.isConnected) "Skaner OK" else "⚠ Skaner rozłączony"
        val title = String.format(Locale("pl", "PL"), "ScanBolt · %.2f zł (-7%%) · %s", netEst, scannerInfo)
        val text = String.format(Locale("pl", "PL"), "%s · %.2f km · Przyjętych: %d · %.2f zł (-7%%)", time, km, count, netEst)
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(Notification.BigTextStyle().bigText(text))
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setShowWhen(false)
            .setContentIntent(pi)
            .build()
    }
}
