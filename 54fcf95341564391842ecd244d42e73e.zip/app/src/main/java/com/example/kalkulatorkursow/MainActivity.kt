package com.example.kalkulatorkursow

import android.Manifest
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import java.math.BigDecimal
import java.math.RoundingMode
import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.UUID
import kotlin.math.abs

object OfferStatus {
    const val DETECTED = "DETECTED"
    const val UNDECIDED = "UNDECIDED"
    const val ACCEPTED = "ACCEPTED"
    const val REJECTED = "REJECTED"
    const val REVIEW = "REVIEW"

    fun normalize(raw: String?): String {
        return when (raw?.trim()?.uppercase(Locale.US)) {
            "ACCEPTED", "PRZYJĘTY", "PRZYJETY", "PRZYJĘTA", "PRZYJETA", "ZAAKCEPTOWANY" -> ACCEPTED
            "REJECTED", "ODRZUCONY", "ODRZUCONA" -> REJECTED
            "REVIEW", "DO OCENY" -> REVIEW
            "UNDECIDED", "BEZ DECYZJI" -> UNDECIDED
            "DETECTED", "WYKRYTY", "WYKRYTA", "" -> UNDECIDED
            else -> UNDECIDED
        }
    }

    fun labelPl(status: String, source: String = "RADAR"): String {
        val norm = normalize(status)
        if (norm == REVIEW || source == "SCREEN") return "Ze screena — do oceny"
        return when (norm) {
            ACCEPTED -> "Zaakceptowany"
            REJECTED -> "Odrzucony"
            UNDECIDED -> "Bez decyzji"
            else -> "Bez decyzji"
        }
    }
}

fun plnToGrosze(amount: Double): Long {
    if (!amount.isFinite() || amount <= 0.0) return 0L
    return BigDecimal.valueOf(amount)
        .setScale(2, RoundingMode.HALF_UP)
        .movePointRight(2)
        .longValueExact()
}

fun groszeToPln(grosze: Long): Double {
    return BigDecimal.valueOf(grosze, 2).toDouble()
}

data class RideEntry(
    val id: String,
    val timestamp: Long,               // czas wykrycia oferty (ms)
    val acceptedTimestamp: Long = 0L,  // czas przyjęcia kursu (ms, 0 gdy brak)
    val priceGrosze: Long,             // kwota w groszach
    val tripKm: Double,
    val pickupKm: Double,
    val offerMin: Int,
    val status: String,
    val destination: String,
    val pickupAddress: String = "",
    val rateCourse: Double = 0.0,
    val rateWithPickup: Double = 0.0,
    val source: String = "RADAR"
) {
    val priceGross: Double get() = groszeToPln(priceGrosze)
    val totalKm: Double get() = tripKm + pickupKm
    val normalizedStatus: String get() = OfferStatus.normalize(status)

    val effectiveTimestamp: Long
        get() = if (normalizedStatus == OfferStatus.ACCEPTED && source != "SCREEN" && acceptedTimestamp > 0L) {
            acceptedTimestamp
        } else {
            timestamp
        }
}

data class HistorySummary(
    val totalFilteredCount: Int,
    val acceptedCount: Int,
    val acceptedSumGrosze: Long
) {
    val acceptedSumPln: Double get() = groszeToPln(acceptedSumGrosze)
}

object RadarStorage {
    private const val PREFS = "KursRadarPrefsV3"
    private const val SUPPRESSED_PREFS = "KursRadarSuppressedV1"
    private fun p(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    private fun sp(ctx: Context) = ctx.getSharedPreferences(SUPPRESSED_PREFS, Context.MODE_PRIVATE)

    fun isSessionRunning(ctx: Context): Boolean = p(ctx).getBoolean("session_running", false)
    fun setSessionRunning(ctx: Context, running: Boolean) = p(ctx).edit().putBoolean("session_running", running).apply()

    fun getSessionStartTime(ctx: Context): Long = p(ctx).getLong("session_start_ms", 0L)
    fun setSessionStartTime(ctx: Context, ms: Long) = p(ctx).edit().putLong("session_start_ms", ms).apply()

    fun getSessionStopTime(ctx: Context): Long = p(ctx).getLong("session_stop_ms", 0L)
    fun setSessionStopTime(ctx: Context, ms: Long) = p(ctx).edit().putLong("session_stop_ms", ms).apply()

    fun getGpsDistanceMeters(ctx: Context): Float = p(ctx).getFloat("gps_distance_m", 0f)
    fun setGpsDistanceMeters(ctx: Context, meters: Float) = p(ctx).edit().putFloat("gps_distance_m", meters).apply()
    fun addGpsDistanceMeters(ctx: Context, deltaMeters: Float) {
        setGpsDistanceMeters(ctx, getGpsDistanceMeters(ctx) + deltaMeters)
    }

    fun getSessionAcceptedCount(ctx: Context): Int = p(ctx).getInt("session_acc_count", 0)
    fun setSessionAcceptedCount(ctx: Context, count: Int) = p(ctx).edit().putInt("session_acc_count", count).apply()

    fun getSessionGrossTotal(ctx: Context): Float = p(ctx).getFloat("session_gross_total", 0f)
    fun setSessionGrossTotal(ctx: Context, total: Float) = p(ctx).edit().putFloat("session_gross_total", total).apply()

    fun isDualRateEnabled(ctx: Context): Boolean = p(ctx).getBoolean("dual_rate_enabled", true)
    fun setDualRateEnabled(ctx: Context, enabled: Boolean) = p(ctx).edit().putBoolean("dual_rate_enabled", enabled).apply()

    fun getOverlayScale(ctx: Context): Float = p(ctx).getFloat("overlay_scale", 1.0f)
    fun setOverlayScale(ctx: Context, scale: Float) = p(ctx).edit().putFloat("overlay_scale", scale).apply()

    fun getGreenKmRate(ctx: Context): Float = p(ctx).getFloat("green_km_rate", 3.00f)
    fun setGreenKmRate(ctx: Context, v: Float) = p(ctx).edit().putFloat("green_km_rate", v).apply()

    fun getYellowKmRate(ctx: Context): Float = p(ctx).getFloat("yellow_km_rate", 2.40f)
    fun setYellowKmRate(ctx: Context, v: Float) = p(ctx).edit().putFloat("yellow_km_rate", v).apply()

    fun getPickupGreenKmRate(ctx: Context): Float =
        p(ctx).getFloat("pickup_green_km_rate", 2.50f)

    fun getPickupYellowKmRate(ctx: Context): Float =
        p(ctx).getFloat("pickup_yellow_km_rate", 2.00f)

    fun saveRateThresholds(
        ctx: Context,
        tripGreen: Float,
        tripYellow: Float,
        pickupGreen: Float,
        pickupYellow: Float
    ) {
        p(ctx).edit()
            .putFloat("green_km_rate", tripGreen)
            .putFloat("yellow_km_rate", tripYellow)
            .putFloat("pickup_green_km_rate", pickupGreen)
            .putFloat("pickup_yellow_km_rate", pickupYellow)
            .apply()
    }

    fun suppressOfferSignature(ctx: Context, signature: String) {
        if (signature.isBlank()) return
        sp(ctx).edit()
            .putString("sig", signature)
            .putLong("ts", System.currentTimeMillis())
            .apply()
    }

    fun isOfferSignatureSuppressed(ctx: Context, signature: String): Boolean {
        if (signature.isBlank()) return false
        val savedSig = sp(ctx).getString("sig", "") ?: ""
        val savedTs = sp(ctx).getLong("ts", 0L)
        return savedSig == signature && System.currentTimeMillis() - savedTs < 180_000L
    }

    @Synchronized
    fun getHistory(ctx: Context): MutableList<RideEntry> {
        val raw = p(ctx).getString("history_json", "[]") ?: "[]"
        val list = mutableListOf<RideEntry>()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val src = o.optString("src", "RADAR")
                val statusNorm = if (src == "SCREEN") {
                    OfferStatus.REVIEW
                } else {
                    OfferStatus.normalize(o.optString("status", OfferStatus.UNDECIDED))
                }
                val ts = o.optLong("t", 0L)
                var accTs = o.optLong("acc_t", 0L)
                if (statusNorm == OfferStatus.ACCEPTED && accTs <= 0L && ts > 0L) {
                    accTs = ts
                }
                val grosze = if (o.has("price_grosze")) {
                    o.optLong("price_grosze", 0L)
                } else {
                    plnToGrosze(o.optDouble("price", 0.0))
                }
                val pricePln = groszeToPln(grosze)
                val tkm = o.optDouble("tkm", 0.0)
                val pkm = o.optDouble("pkm", 0.0)
                val savedRateC = o.optDouble("rate_c", 0.0)
                val savedRateP = o.optDouble("rate_p", 0.0)
                val computedRateC = if (savedRateC > 0.0) savedRateC else if (tkm > 0.0) pricePln / tkm else 0.0
                val computedRateP = if (savedRateP > 0.0) savedRateP else if (pkm > 0.0 && (tkm + pkm) > 0.0) pricePln / (tkm + pkm) else 0.0

                list.add(
                    RideEntry(
                        id = o.optString("id").ifEmpty { UUID.randomUUID().toString() },
                        timestamp = ts,
                        acceptedTimestamp = accTs,
                        priceGrosze = grosze,
                        tripKm = tkm,
                        pickupKm = pkm,
                        offerMin = o.optInt("min", 1),
                        status = statusNorm,
                        destination = o.optString("dest", "Kraków"),
                        pickupAddress = o.optString("pickup_addr", ""),
                        rateCourse = computedRateC,
                        rateWithPickup = computedRateP,
                        source = src
                    )
                )
            }
        } catch (_: Exception) {}
        list.sortByDescending { it.effectiveTimestamp }
        return list
    }

    @Synchronized
    fun saveHistory(ctx: Context, list: List<RideEntry>) {
        val arr = JSONArray()
        list.forEach { r ->
            val o = JSONObject()
            o.put("id", r.id)
            o.put("t", r.timestamp)
            o.put("acc_t", r.acceptedTimestamp)
            o.put("price_grosze", r.priceGrosze)
            o.put("price", r.priceGross)
            o.put("tkm", r.tripKm)
            o.put("pkm", r.pickupKm)
            o.put("min", r.offerMin)
            o.put("status", OfferStatus.normalize(r.status))
            o.put("dest", r.destination)
            o.put("pickup_addr", r.pickupAddress)
            o.put("rate_c", r.rateCourse)
            o.put("rate_p", r.rateWithPickup)
            o.put("src", r.source)
            arr.put(o)
        }
        p(ctx).edit().putString("history_json", arr.toString()).commit()
    }

    @Synchronized
    fun recordDecision(ctx: Context, entry: RideEntry) {
        if (RadarOptions.historyEnabled(ctx)) {
            val list = getHistory(ctx)
            val idx = list.indexOfFirst { it.id == entry.id }
            if (idx >= 0) {
                list[idx] = entry
            } else {
                list.add(0, entry)
            }
            saveHistory(ctx, list)
        }

        if (
            entry.normalizedStatus == OfferStatus.ACCEPTED &&
            entry.source != "SCREEN" &&
            isSessionRunning(ctx)
        ) {
            setSessionAcceptedCount(
                ctx,
                getSessionAcceptedCount(ctx) + 1
            )

            setSessionGrossTotal(
                ctx,
                getSessionGrossTotal(ctx) + entry.priceGross.toFloat()
            )
        }
    }

    @Synchronized
    fun upsertOffer(
        ctx: Context,
        entry: RideEntry,
        alreadyCountedInSession: Boolean = false,
        previousCountedGrosze: Long = 0L
    ): Pair<RideEntry, Boolean> {
        val isScreen = entry.source == "SCREEN"
        val normalizedIncoming = if (isScreen) OfferStatus.REVIEW else OfferStatus.normalize(entry.status)

        val list = getHistory(ctx)
        val idx = list.indexOfFirst { it.id == entry.id }
        val old = if (idx >= 0) list[idx] else null
        val oldStatus = old?.normalizedStatus

        val finalStatus = when {
            isScreen -> OfferStatus.REVIEW
            oldStatus == OfferStatus.ACCEPTED -> OfferStatus.ACCEPTED
            normalizedIncoming == OfferStatus.ACCEPTED -> OfferStatus.ACCEPTED
            oldStatus == OfferStatus.REJECTED && normalizedIncoming == OfferStatus.UNDECIDED -> OfferStatus.REJECTED
            else -> normalizedIncoming
        }

        val finalAcceptedTs = when {
            finalStatus == OfferStatus.ACCEPTED && !isScreen && old != null && old.acceptedTimestamp > 0L -> old.acceptedTimestamp
            finalStatus == OfferStatus.ACCEPTED && !isScreen && entry.acceptedTimestamp > 0L -> entry.acceptedTimestamp
            finalStatus == OfferStatus.ACCEPTED && !isScreen -> System.currentTimeMillis()
            else -> 0L
        }

        val finalPickupKm = if (entry.pickupKm > 0.0) entry.pickupKm else (old?.pickupKm ?: 0.0)
        val finalTripKm = if (entry.tripKm > 0.0) entry.tripKm else (old?.tripKm ?: 0.0)
        val finalGrosze = if (entry.priceGrosze > 0L) entry.priceGrosze else (old?.priceGrosze ?: 0L)
        val finalPricePln = groszeToPln(finalGrosze)
        val finalDest = if (entry.destination.isNotBlank() && entry.destination != "Kraków") {
            entry.destination
        } else {
            old?.destination ?: entry.destination.ifBlank { "Kraków" }
        }
        val finalPickupAddr = if (entry.pickupAddress.isNotBlank()) {
            entry.pickupAddress
        } else {
            old?.pickupAddress ?: ""
        }

        val rateC = if (finalTripKm > 0.0) finalPricePln / finalTripKm else 0.0
        val rateP = if (finalPickupKm > 0.0 && (finalTripKm + finalPickupKm) > 0.0) {
            finalPricePln / (finalTripKm + finalPickupKm)
        } else {
            0.0
        }

        val resultEntry = RideEntry(
            id = entry.id,
            timestamp = if (old != null && old.timestamp > 0L) old.timestamp else entry.timestamp,
            acceptedTimestamp = finalAcceptedTs,
            priceGrosze = finalGrosze,
            tripKm = finalTripKm,
            pickupKm = finalPickupKm,
            offerMin = if (entry.offerMin > 0) entry.offerMin else (old?.offerMin ?: 1),
            status = finalStatus,
            destination = finalDest,
            pickupAddress = finalPickupAddr,
            rateCourse = rateC,
            rateWithPickup = rateP,
            source = entry.source
        )

        if (RadarOptions.historyEnabled(ctx)) {
            if (idx >= 0) {
                list[idx] = resultEntry
            } else {
                list.add(0, resultEntry)
            }
            saveHistory(ctx, list)
        }

        var nowCounted = alreadyCountedInSession
        if (finalStatus == OfferStatus.ACCEPTED && !isScreen && isSessionRunning(ctx)) {
            if (!alreadyCountedInSession) {
                setSessionAcceptedCount(ctx, getSessionAcceptedCount(ctx) + 1)
                setSessionGrossTotal(ctx, getSessionGrossTotal(ctx) + resultEntry.priceGross.toFloat())
                nowCounted = true
            } else if (previousCountedGrosze != resultEntry.priceGrosze) {
                val diffPln = groszeToPln(resultEntry.priceGrosze - previousCountedGrosze).toFloat()
                setSessionGrossTotal(ctx, (getSessionGrossTotal(ctx) + diffPln).coerceAtLeast(0f))
            }
        }

        return Pair(resultEntry, nowCounted)
    }

    @Synchronized
    fun deleteHistoryItem(ctx: Context, id: String) {
        val list = getHistory(ctx).filterNot { it.id == id }
        saveHistory(ctx, list)
    }

    fun isInRange(entry: RideEntry, fromInclusive: Long?, toExclusive: Long?): Boolean {
        val t = entry.effectiveTimestamp
        if (fromInclusive != null && t < fromInclusive) return false
        if (toExclusive != null && t >= toExclusive) return false
        return true
    }

    fun filterHistory(ctx: Context, fromInclusive: Long?, toExclusive: Long?): List<RideEntry> {
        return getHistory(ctx).filter { isInRange(it, fromInclusive, toExclusive) }
    }

    fun calculateSummary(entries: List<RideEntry>): HistorySummary {
        var acceptedCount = 0
        var sumGrosze = 0L
        for (item in entries) {
            if (item.normalizedStatus == OfferStatus.ACCEPTED && item.source != "SCREEN" && item.priceGrosze > 0L) {
                acceptedCount++
                sumGrosze += item.priceGrosze
            }
        }
        return HistorySummary(
            totalFilteredCount = entries.size,
            acceptedCount = acceptedCount,
            acceptedSumGrosze = sumGrosze
        )
    }

    @Synchronized
    fun deleteHistoryInRange(ctx: Context, fromInclusive: Long, toExclusive: Long): Int {
        val all = getHistory(ctx)
        val remaining = ArrayList<RideEntry>(all.size)
        var deletedCount = 0
        for (item in all) {
            if (isInRange(item, fromInclusive, toExclusive)) {
                deletedCount++
            } else {
                remaining.add(item)
            }
        }
        if (deletedCount > 0) {
            saveHistory(ctx, remaining)
        }
        return deletedCount
    }

    @Synchronized
    fun clearAllHistory(ctx: Context): Int {
        val count = getHistory(ctx).size
        saveHistory(ctx, emptyList())
        return count
    }
}

class MainActivity : AppCompatActivity(), LocationListener {

    private lateinit var contentFrame: FrameLayout
    private lateinit var bottomNav: LinearLayout
    private var currentTab = "start"

    private var locationManager: LocationManager? = null
    private var lastLocation: Location? = null
    private val uiHandler = Handler(Looper.getMainLooper())

    private var filterFromCal: Calendar? = null
    private var filterToCal: Calendar? = null

    private var selectedBarDayKey: String? = null
    private var compareWeekAKey: String? = null
    private var compareWeekBKey: String? = null
    private var calYear = 0
    private var calMonth = 0
    private var paySelectedDateKey: String = OfflineAnalytics.dayKeyFromMillis(System.currentTimeMillis())

    private val tickerRunnable = object : Runnable {
        override fun run() {
            if (RadarStorage.isSessionRunning(this@MainActivity) && currentTab == "start") {
                refreshCurrentTab()
            }
            uiHandler.postDelayed(this, 1000L)
        }
    }

    private val pickCsvLauncher = registerForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        if (uris.isNotEmpty()) {
            val added = OfflineAnalytics.importCsvFilesOffline(this, uris)
            Toast.makeText(this, "Zaimportowano kursów (CSV offline): $added", Toast.LENGTH_LONG).show()
            if (currentTab == "rozliczenia") refreshCurrentTab()
        }
    }

    private val exportBackupLauncher = registerForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) {
            try {
                contentResolver.openOutputStream(uri)?.use { out ->
                    val ok = OfflineAnalytics.exportBackupJson(this, out)
                    Toast.makeText(
                        this,
                        if (ok) "Zapisano kopię zapasową JSON (offline)." else "Nie udało się zapisać kopii.",
                        Toast.LENGTH_LONG
                    ).show()
                }
            } catch (e: Exception) {
                Toast.makeText(this, "Błąd eksportu: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private val importBackupLauncher = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            val (ok, msg) = OfflineAnalytics.importBackupJson(this, uri)
            Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
            if (ok) refreshCurrentTab()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val crashFile = java.io.File(filesDir, "crash.txt")
        if (crashFile.exists()) {
            val tv = TextView(this).apply {
                text = crashFile.readText()
                setTextIsSelectable(true)
                setPadding(24, 24, 24, 24)
            }
            setContentView(ScrollView(this).apply { addView(tv) })
            crashFile.delete()
            return
        }
        try {
            locationManager = getSystemService(Context.LOCATION_SERVICE) as? LocationManager

            val root = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setBackgroundColor(Color.parseColor("#080E1A"))
                layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            }

            contentFrame = FrameLayout(this).apply {
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
            }

            bottomNav = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                background = roundedBox("#0D1526", 28f, "#1E2D4A")
                setPadding(dp(6), dp(10), dp(6), dp(10))
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                    setMargins(dp(10), dp(4), dp(10), dp(12))
                }
            }

            root.addView(contentFrame)
            root.addView(bottomNav)
            setContentView(root)

            switchTab("start")
            if (RadarStorage.isSessionRunning(this)) startGps()
        } catch (e: Exception) {
            Toast.makeText(this, "Błąd startu: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    override fun onResume() {
        super.onResume()
        try {
            uiHandler.removeCallbacks(tickerRunnable)
            uiHandler.post(tickerRunnable)
            if (::contentFrame.isInitialized) refreshCurrentTab()
        } catch (_: Exception) {}
    }

    override fun onPause() {
        super.onPause()
        uiHandler.removeCallbacks(tickerRunnable)
    }

    override fun onDestroy() {
        super.onDestroy()
        uiHandler.removeCallbacks(tickerRunnable)
        stopGps()
    }

    private fun startGps() {
        try {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), 101)
                return
            }
            lastLocation = null
            if (locationManager?.isProviderEnabled(LocationManager.GPS_PROVIDER) == true) {
                locationManager?.requestLocationUpdates(LocationManager.GPS_PROVIDER, 2000L, 4f, this)
            }
            if (locationManager?.isProviderEnabled(LocationManager.NETWORK_PROVIDER) == true) {
                locationManager?.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 3000L, 8f, this)
            }
        } catch (_: Exception) {}
    }

    private fun stopGps() {
        try {
            locationManager?.removeUpdates(this)
            lastLocation = null
        } catch (_: Exception) {}
    }

    override fun onLocationChanged(location: Location) {
        if (!RadarStorage.isSessionRunning(this)) return
        val prev = lastLocation
        if (prev != null) {
            val delta = prev.distanceTo(location)
            if (delta in 3.0f..500.0f) {
                // licznik km działa w usłudze (RideScannerService)
            }
        }
        lastLocation = location
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 101 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            if (RadarStorage.isSessionRunning(this)) startGps()
        }
    }

    private fun switchTab(tab: String) {
        currentTab = tab
        val tabs = listOf(
            "start" to "⚡\nStart",
            "historia" to "🕒\nHistoria",
            "rozliczenia" to "💰\nRozliczenia",
            "progi" to "☰\nProgi PRO",
            "ustawienia" to "⚙️\nUstawienia"
        )
        bottomNav.removeAllViews()
        tabs.forEach { (key, label) ->
            val active = currentTab == key
            bottomNav.addView(TextView(this).apply {
                text = label
                gravity = Gravity.CENTER
                textSize = 10.5f
                setTextColor(if (active) Color.parseColor("#38B6FF") else Color.parseColor("#8A99B5"))
                typeface = if (active) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                setOnClickListener { switchTab(key) }
            })
        }
        refreshCurrentTab()
    }

    private fun refreshCurrentTab() {
        if (!::contentFrame.isInitialized) return
        contentFrame.removeAllViews()
        val view = when (currentTab) {
            "start" -> buildStartAndStatsView()
            "historia" -> buildHistoryView()
            "rozliczenia" -> buildSettlementsView()
            "progi" -> buildThresholdsView()
            else -> buildSettingsView()
        }
        contentFrame.addView(view)
    }

    private fun buildStartAndStatsView(): View {
        val scroll = ScrollView(this)
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(20), dp(16), dp(28))
        }

        val running = RadarStorage.isSessionRunning(this)
        val startMs = RadarStorage.getSessionStartTime(this)
        val stopMs = if (running) System.currentTimeMillis() else RadarStorage.getSessionStopTime(this)

        val sdfDate = SimpleDateFormat("dd.MM HH:mm", Locale.getDefault())
        val sdfHour = SimpleDateFormat("HH:mm", Locale.getDefault())

        val topRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val titleCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        titleCol.addView(TextView(this).apply {
            text = if (running) "Odczyt ekranu aktywny" else "Sesja zakończona"
            textSize = 25f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        })
        titleCol.addView(TextView(this).apply {
            text = if (startMs > 0) "Taxi • ${sdfDate.format(Date(startMs))} do ${sdfHour.format(Date(stopMs))}" else "Taxi • Kliknij START, aby rozpocząć zmianę"
            textSize = 13f
            setTextColor(Color.parseColor("#8A99B5"))
        })

        val badge = TextView(this).apply {
            text = if (running) "● AKTYWNA" else "✓ ZAKOŃCZONA"
            textSize = 12f
            setTextColor(if (running) Color.parseColor("#3DDC84") else Color.parseColor("#4CE0B3"))
            background = roundedBox("#0C261E", 22f, "#2E7D32")
            setPadding(dp(14), dp(10), dp(14), dp(10))
        }
        topRow.addView(titleCol)
        topRow.addView(badge)
        container.addView(topRow)

        val btnStartStop = Button(this).apply {
            text = if (running) "⏹ STOP (Wyłącz nakładkę i zatrzymaj GPS)" else "▶ START (Włącz odczyt ekranu i licznik km GPS)"
            textSize = 15f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(if (running) Color.WHITE else Color.parseColor("#041E14"))
            background = roundedBox(if (running) "#D32F2F" else "#2CE574", 20f, if (running) "#FF6659" else "#65ECC5")
            setPadding(dp(16), dp(18), dp(16), dp(18))
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                topMargin = dp(18)
                bottomMargin = dp(16)
            }
            setOnClickListener {
                if (!running) {
                    if (!Settings.canDrawOverlays(this@MainActivity)) {
                        Toast.makeText(this@MainActivity, "Włącz uprawnienie Nakładki ekranowej!", Toast.LENGTH_LONG).show()
                        try {
                            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                        } catch (_: Exception) {}
                        return@setOnClickListener
                    }
                    val now = System.currentTimeMillis()
                    RadarStorage.setSessionStartTime(this@MainActivity, now)
                    RadarStorage.setSessionStopTime(this@MainActivity, now)
                    RadarStorage.setGpsDistanceMeters(this@MainActivity, 0f)
                    RadarStorage.setSessionAcceptedCount(this@MainActivity, 0)
                    RadarStorage.setSessionGrossTotal(this@MainActivity, 0f)
                    RadarStorage.setSessionRunning(this@MainActivity, true)
                    startGps()
                    if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this@MainActivity, "android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
                        ActivityCompat.requestPermissions(this@MainActivity, arrayOf("android.permission.POST_NOTIFICATIONS"), 102)
                    }
                    Toast.makeText(this@MainActivity, "START! Nakładka i licznik GPS włączone.", Toast.LENGTH_SHORT).show()
                } else {
                    RadarStorage.setSessionStopTime(this@MainActivity, System.currentTimeMillis())
                    RadarStorage.setSessionRunning(this@MainActivity, false)
                    stopGps()
                    Toast.makeText(this@MainActivity, "STOP! Odczyt wyłączony. Podsumowanie poniżej.", Toast.LENGTH_SHORT).show()
                }
                refreshCurrentTab()
            }
        }
        container.addView(btnStartStop)

        val gross = RadarStorage.getSessionGrossTotal(this).toDouble()
        val acceptedCount = RadarStorage.getSessionAcceptedCount(this)
        val gpsKm = RadarStorage.getGpsDistanceMeters(this) / 1000.0
        val avgKm = if (gpsKm > 0.05) gross / gpsKm else 0.0

        val sec = if (startMs > 0 && stopMs >= startMs) ((stopMs - startMs) / 1000L) else 0L
        val timeStr = String.format(Locale.US, "%02d:%02d:%02d", sec / 3600, (sec % 3600) / 60, sec % 60)

        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = roundedBox("#0A2229", 28f, "#26A69A")
            setPadding(dp(20), dp(26), dp(20), dp(26))
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = dp(16)
            }
        }
        hero.addView(TextView(this).apply {
            text = "SUMA PRZYJĘTYCH OFERT • SESJA"
            textSize = 12f
            setTextColor(Color.parseColor("#A5B8D1"))
            gravity = Gravity.CENTER
        })
        hero.addView(TextView(this).apply {
            text = formatMoney(gross)
            textSize = 42f
            setTextColor(Color.parseColor("#2CE574"))
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(0, dp(6), 0, dp(6))
        })
        hero.addView(TextView(this).apply {
            text = if (running) "Liczenie km GPS i oczekiwanie na oferty..." else "Statystyki zakończonej sesji"
            textSize = 13f
            setTextColor(Color.parseColor("#C2D1E5"))
            gravity = Gravity.CENTER
        })
        container.addView(hero)

        container.addView(twoCols(statTile("Czas pracy", timeStr, "#FFFFFF"), statTile("Dystans GPS", String.format(Locale("pl", "PL"), "%.2f km", gpsKm), "#38B6FF")))
        container.addView(twoCols(statTile("Przyjęte kursy", "$acceptedCount", "#3DDC84"), statTile("Średnio za km (GPS)", String.format(Locale("pl", "PL"), "%.2f zł/km", avgKm), "#3DDC84")))

        val bottomBtns = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                topMargin = dp(10)
            }
        }
        bottomBtns.addView(Button(this).apply {
            text = "Historia"
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            background = roundedBox("#0099FF", 24f)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { rightMargin = dp(8) }
            setOnClickListener { switchTab("historia") }
        })
        bottomBtns.addView(Button(this).apply {
            text = "Udostępnij"
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            background = roundedBox("#0C1626", 24f, "#3DD5B0")
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = dp(8) }
            setOnClickListener {
                val txt = String.format(Locale("pl", "PL"), "Podsumowanie sesji:\nPrzyjęte kursy: %d\nSuma przyjętych ofert: %s\nPrzejechane km (GPS): %.2f km\nCzas: %s", acceptedCount, formatMoney(gross), gpsKm, timeStr)
                startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, txt) }, "Udostępnij"))
            }
        })
        container.addView(bottomBtns)

        scroll.addView(container)
        return scroll
    }

    private fun buildSettlementsView(): View {
        val scroll = ScrollView(this)
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(16), dp(14), dp(28))
        }

        val sharePct = RadarOptions.driverSharePercent(this)
        val calcMode = RadarOptions.calcMode(this)
        val boltDays = OfflineAnalytics.getBoltDays(this)
        val currentDaySummary = boltDays[paySelectedDateKey] ?: BoltDaySummary(paySelectedDateKey, 0.0, 0.0, 0.0, 0.0)
        val pay = OfflineAnalytics.calculatePay(
            totalBolt = currentDaySummary.total,
            tips = currentDaySummary.tips,
            cash = currentDaySummary.cash,
            sharePercent = sharePct
        )

        container.addView(TextView(this).apply {
            text = "Rozliczenia i statystyki (Offline)"
            textSize = 21f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 0, 0, dp(10))
        })

        // 1. Karta podziału 45%-55% i trybu liczenia
        val shareCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = roundedBox("#101827", 22f, "#24344E")
            setPadding(dp(14), dp(14), dp(14), dp(14))
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = dp(12)
            }
        }
        shareCard.addView(TextView(this).apply {
            text = String.format(Locale("pl", "PL"), "Twój udział w podziale: %.1f%% (partner: %.1f%%)", sharePct, 100.0f - sharePct)
            textSize = 15f
            setTextColor(Color.parseColor("#65ECC5"))
            typeface = Typeface.DEFAULT_BOLD
        })
        shareCard.addView(TextView(this).apply {
            text = "Zakres udziału kierowcy: 45,0% – 55,0% (napiwki 100% dla kierowcy, odebrana gotówka odliczana)."
            textSize = 12f
            setTextColor(Color.parseColor("#9BA9C2"))
            setPadding(0, dp(4), 0, dp(8))
        })

        val shareStepRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun addShareBtn(label: String, delta: Float) {
            shareStepRow.addView(Button(this).apply {
                text = label
                textSize = 12f
                setTextColor(Color.WHITE)
                background = roundedBox("#1B2942", 14f, "#38B6FF")
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                    rightMargin = dp(4)
                }
                setOnClickListener {
                    RadarOptions.setDriverSharePercent(this@MainActivity, RadarOptions.driverSharePercent(this@MainActivity) + delta)
                    refreshCurrentTab()
                }
            })
        }
        addShareBtn("-1,0%", -1.0f)
        addShareBtn("-0,5%", -0.5f)
        addShareBtn("50,0%", 50.0f - sharePct)
        addShareBtn("+0,5%", 0.5f)
        addShareBtn("+1,0%", 1.0f)
        shareCard.addView(shareStepRow)

        val modeRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                topMargin = dp(8)
            }
        }
        modeRow.addView(Button(this).apply {
            text = if (calcMode == "bolt") "✓ Tryb: Screeny / Dni Bolta" else "Tryb: Screeny / Dni Bolta"
            textSize = 11.5f
            setTextColor(if (calcMode == "bolt") Color.parseColor("#041E14") else Color.WHITE)
            background = roundedBox(if (calcMode == "bolt") "#65ECC5" else "#162338", 14f, "#65ECC5")
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { rightMargin = dp(4) }
            setOnClickListener {
                RadarOptions.setCalcMode(this@MainActivity, "bolt")
                refreshCurrentTab()
            }
        })
        modeRow.addView(Button(this).apply {
            text = if (calcMode == "csv") "✓ Tryb: CSV / Historia" else "Tryb: CSV / Historia"
            textSize = 11.5f
            setTextColor(if (calcMode == "csv") Color.parseColor("#041E14") else Color.WHITE)
            background = roundedBox(if (calcMode == "csv") "#65ECC5" else "#162338", 14f, "#65ECC5")
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = dp(4) }
            setOnClickListener {
                RadarOptions.setCalcMode(this@MainActivity, "csv")
                refreshCurrentTab()
            }
        })
        shareCard.addView(modeRow)
        container.addView(shareCard)

        // 2. Kalkulator wypłaty dla wybranego dnia (zapisywany offline)
        val payCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = roundedBox("#0A2229", 22f, "#26A69A")
            setPadding(dp(14), dp(14), dp(14), dp(14))
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = dp(12)
            }
        }
        payCard.addView(TextView(this).apply {
            text = "Rozliczenie dnia: $paySelectedDateKey"
            textSize = 16f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        })
        payCard.addView(TextView(this).apply {
            text = if (pay.payout >= 0.0) {
                "Do wypłaty od partnera: ${formatMoney(pay.payout)}"
            } else {
                "Do oddania partnerowi: ${formatMoney(abs(pay.payout))}"
            }
            textSize = 21f
            setTextColor(if (pay.payout >= 0.0) Color.parseColor("#2CE574") else Color.parseColor("#FF8A8A"))
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(6), 0, dp(4))
        })
        payCard.addView(TextView(this).apply {
            text = "Podstawa (Bolt − napiwki): ${formatMoney(pay.basis)} • Twój udział: ${formatMoney(pay.driverShare)} • Napiwki: +${formatMoney(pay.tips)} • Gotówka: −${formatMoney(pay.cash)}"
            textSize = 12f
            setTextColor(Color.parseColor("#C2D1E5"))
            setPadding(0, 0, 0, dp(8))
        })

        val etDayKey = addInputField(payCard, "Data dnia (RRRR-MM-DD):", paySelectedDateKey).apply {
            inputType = InputType.TYPE_CLASS_TEXT
        }
        val etBoltTotal = addInputField(payCard, "Twoje zarobki z Bolta (zł):", currentDaySummary.total.toString())
        val etTips = addInputField(payCard, "Napiwki (zł):", currentDaySummary.tips.toString())
        val etCash = addInputField(payCard, "Odebrana gotówka (zł):", currentDaySummary.cash.toString())

        payCard.addView(Button(this).apply {
            text = "Zapisz dane dnia offline"
            setTextColor(Color.parseColor("#041E14"))
            typeface = Typeface.DEFAULT_BOLD
            background = roundedBox("#2CE574", 16f)
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                topMargin = dp(10)
            }
            setOnClickListener {
                val dk = etDayKey.text.toString().trim()
                if (!Regex("""\d{4}-\d{2}-\d{2}""").matches(dk)) {
                    Toast.makeText(this@MainActivity, "Wpisz datę w formacie RRRR-MM-DD.", Toast.LENGTH_LONG).show()
                    return@setOnClickListener
                }
                val tVal = etBoltTotal.text.toString().trim().replace(",", ".").toDoubleOrNull() ?: 0.0
                val tpVal = etTips.text.toString().trim().replace(",", ".").toDoubleOrNull() ?: 0.0
                val csVal = etCash.text.toString().trim().replace(",", ".").toDoubleOrNull() ?: 0.0
                if (tVal < 0.0 || tpVal < 0.0 || csVal < 0.0 || tpVal > tVal) {
                    Toast.makeText(this@MainActivity, "Sprawdź kwoty (nie mogą być ujemne, napiwki nie mogą przekraczać zarobków).", Toast.LENGTH_LONG).show()
                    return@setOnClickListener
                }
                OfflineAnalytics.upsertBoltDay(this@MainActivity, BoltDaySummary(dk, tVal, tpVal, csVal, currentDaySummary.camp))
                paySelectedDateKey = dk
                Toast.makeText(this@MainActivity, "Zapisano rozliczenie dla $dk.", Toast.LENGTH_SHORT).show()
                refreshCurrentTab()
            }
        })
        container.addView(payCard)

        // 3. Narzędzia offline: CSV, kopia zapasowa JSON, przywracanie kursów z paczki oraz cofanie czyszczenia
        val toolsCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = roundedBox("#101827", 22f, "#24344E")
            setPadding(dp(14), dp(14), dp(14), dp(14))
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = dp(12)
            }
        }
        toolsCard.addView(TextView(this).apply {
            text = "Import CSV, kopia JSON i dane offline"
            textSize = 16f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 0, 0, dp(8))
        })

        val rowCsvJson = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = dp(8)
            }
        }
        rowCsvJson.addView(Button(this).apply {
            text = "📄 Wgraj CSV (offline)"
            textSize = 12f
            setTextColor(Color.parseColor("#041E14"))
            typeface = Typeface.DEFAULT_BOLD
            background = roundedBox("#65ECC5", 14f)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { rightMargin = dp(4) }
            setOnClickListener { pickCsvLauncher.launch("*/*") }
        })
        rowCsvJson.addView(Button(this).apply {
            text = "💾 Kopia JSON"
            textSize = 12f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            background = roundedBox("#1B2942", 14f, "#38B6FF")
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = dp(4) }
            setOnClickListener { exportBackupLauncher.launch("kursradar-kopia-offline.json") }
        })
        toolsCard.addView(rowCsvJson)

        val rowRestore = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = dp(8)
            }
        }
        rowRestore.addView(Button(this).apply {
            text = "📥 Wczytaj kopię JSON"
            textSize = 12f
            setTextColor(Color.WHITE)
            background = roundedBox("#1B2942", 14f, "#38B6FF")
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { rightMargin = dp(4) }
            setOnClickListener { importBackupLauncher.launch("*/*") }
        })
        rowRestore.addView(Button(this).apply {
            text = "📦 Przywróć paczkę kursów"
            textSize = 12f
            setTextColor(Color.WHITE)
            background = roundedBox("#1B2942", 14f, "#38B6FF")
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = dp(4) }
            setOnClickListener {
                val added = OfflineAnalytics.restoreBundledTrips(this@MainActivity)
                Toast.makeText(this@MainActivity, "Dodano z wbudowanej paczki: $added kursów", Toast.LENGTH_LONG).show()
                refreshCurrentTab()
            }
        })
        toolsCard.addView(rowRestore)

        val undoInfo = OfflineAnalytics.getUndoInfo(this)
        if (undoInfo != null) {
            toolsCard.addView(Button(this).apply {
                text = "↩ Cofnij ostatnie czyszczenie (${undoInfo.first})"
                textSize = 12f
                setTextColor(Color.parseColor("#FFD54F"))
                background = roundedBox("#262112", 14f, "#8E733B")
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                setOnClickListener {
                    if (OfflineAnalytics.performUndo(this@MainActivity)) {
                        Toast.makeText(this@MainActivity, "Przywrócono stan sprzed czyszczenia.", Toast.LENGTH_SHORT).show()
                        refreshCurrentTab()
                    }
                }
            })
        }
        container.addView(toolsCard)

        // 4. Wykres słupkowy 7 dni (poniedziałek-niedziela) + wybór dnia
        val dayStats = OfflineAnalytics.buildDayStats(this, sharePct, calcMode)
        val weekMondays = dayStats.map { OfflineAnalytics.mondayKeyForMillis(OfflineAnalytics.parseDateKeyToMillis(it.dateKey, false)) }.distinct().sorted()
        val activeMonday = if (compareWeekAKey != null && weekMondays.contains(compareWeekAKey)) {
            compareWeekAKey!!
        } else {
            weekMondays.lastOrNull() ?: OfflineAnalytics.mondayKeyForMillis(System.currentTimeMillis())
        }

        val weekDays = (0..6).map { offset ->
            val dk = OfflineAnalytics.addDaysToKey(activeMonday, offset)
            dayStats.find { it.dateKey == dk } ?: DayStat(dk, dk.takeLast(5), dk.takeLast(2).toInt(), 0, 0, 0.0, 0.0, 0.0, 0.0, calcMode)
        }
        val maxEarned = weekDays.maxOfOrNull { it.estimatedDriverEarned }?.coerceAtLeast(1.0) ?: 1.0

        val chartCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = roundedBox("#101827", 22f, "#24344E")
            setPadding(dp(14), dp(14), dp(14), dp(14))
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = dp(12)
            }
        }
        chartCard.addView(TextView(this).apply {
            text = "Wykres tygodniowy: ${OfflineAnalytics.formatWeekRange(activeMonday)}"
            textSize = 16f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 0, 0, dp(8))
        })

        val barsRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.BOTTOM
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(140)).apply {
                bottomMargin = dp(8)
            }
        }

        for (dStat in weekDays) {
            val col = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f).apply {
                    rightMargin = dp(3)
                }
                setOnClickListener {
                    selectedBarDayKey = dStat.dateKey
                    paySelectedDateKey = dStat.dateKey
                    refreshCurrentTab()
                }
            }
            val ratio = if (maxEarned > 0.0) (dStat.estimatedDriverEarned / maxEarned).coerceIn(0.05, 1.0) else 0.05
            val barHeightPx = dp((ratio * 95.0).toInt().coerceAtLeast(8))
            val isSelected = selectedBarDayKey == dStat.dateKey

            col.addView(TextView(this).apply {
                text = if (dStat.estimatedDriverEarned > 0.0) "${dStat.estimatedDriverEarned.toInt()}" else "0"
                textSize = 9.5f
                setTextColor(Color.parseColor("#C2D1E5"))
                gravity = Gravity.CENTER
            })
            col.addView(LinearLayout(this).apply {
                background = roundedBox(if (isSelected) "#FFE45E" else "#65ECC5", 6f)
                layoutParams = LinearLayout.LayoutParams(dp(22), barHeightPx).apply {
                    topMargin = dp(2)
                    bottomMargin = dp(4)
                }
            })
            col.addView(TextView(this).apply {
                text = dStat.labelShort.take(2)
                textSize = 10.5f
                setTextColor(if (isSelected) Color.parseColor("#FFE45E") else Color.parseColor("#9BA9C2"))
                typeface = if (isSelected) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
            })
            barsRow.addView(col)
        }
        chartCard.addView(barsRow)

        val chosenStat = weekDays.find { it.dateKey == selectedBarDayKey } ?: weekDays.last()
        chartCard.addView(TextView(this).apply {
            text = "Wybrany dzień (${chosenStat.dateKey}): zarobek ~${formatMoney(chosenStat.estimatedDriverEarned)} • kursy: ${chosenStat.tripsCount} • karta: ${formatMoney(chosenStat.cardSum)} • gotówka: ${formatMoney(chosenStat.cashSum)}"
            textSize = 12f
            setTextColor(Color.parseColor("#80E8B6"))
        })
        container.addView(chartCard)

        // 5. Porównanie dwóch tygodni (Tydzień A vs Tydzień B)
        if (weekMondays.size >= 2) {
            val wA = compareWeekAKey ?: weekMondays.last()
            val wB = compareWeekBKey ?: weekMondays[weekMondays.size - 2]
            val sumA = dayStats.filter { OfflineAnalytics.mondayKeyForMillis(OfflineAnalytics.parseDateKeyToMillis(it.dateKey, false)) == wA }.sumOf { it.estimatedDriverEarned }
            val sumB = dayStats.filter { OfflineAnalytics.mondayKeyForMillis(OfflineAnalytics.parseDateKeyToMillis(it.dateKey, false)) == wB }.sumOf { it.estimatedDriverEarned }
            val diffAB = OfflineAnalytics.round2(sumA - sumB)

            val cmpCard = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                background = roundedBox("#101827", 22f, "#24344E")
                setPadding(dp(14), dp(14), dp(14), dp(14))
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                    bottomMargin = dp(12)
                }
            }
            cmpCard.addView(TextView(this).apply {
                text = "Porównanie tygodni (A vs B)"
                textSize = 16f
                setTextColor(Color.WHITE)
                typeface = Typeface.DEFAULT_BOLD
            })
            cmpCard.addView(TextView(this).apply {
                text = "Tydzień A (${OfflineAnalytics.formatWeekRange(wA)}): ${formatMoney(OfflineAnalytics.round2(sumA))}\nTydzień B (${OfflineAnalytics.formatWeekRange(wB)}): ${formatMoney(OfflineAnalytics.round2(sumB))}\nRóżnica A − B: ${if (diffAB >= 0) "+" else ""}${formatMoney(diffAB)}"
                textSize = 13f
                setTextColor(Color.parseColor("#D5E3F7"))
                setPadding(0, dp(6), 0, dp(8))
            })
            cmpCard.addView(Button(this).apply {
                text = "Zamień tygodnie miejscami"
                textSize = 12f
                setTextColor(Color.WHITE)
                background = roundedBox("#1B2942", 14f, "#38B6FF")
                setOnClickListener {
                    compareWeekAKey = wB
                    compareWeekBKey = wA
                    refreshCurrentTab()
                }
            })
            container.addView(cmpCard)
        }

        // 6. Mapa kolorów dni (kalendarz miesięczny)
        val calNow = Calendar.getInstance()
        if (calYear == 0) {
            calYear = calNow.get(Calendar.YEAR)
            calMonth = calNow.get(Calendar.MONTH)
        }
        val calCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = roundedBox("#101827", 22f, "#24344E")
            setPadding(dp(14), dp(14), dp(14), dp(14))
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = dp(12)
            }
        }
        val monthName = SimpleDateFormat("LLLL yyyy", Locale("pl", "PL")).format(Date(OfflineAnalytics.parseDateKeyToMillis(String.format(Locale.US, "%04d-%02d-01", calYear, calMonth + 1), false)))
        val calNav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = dp(8)
            }
        }
        calNav.addView(Button(this).apply {
            text = "◀"
            setTextColor(Color.WHITE)
            background = roundedBox("#1B2942", 12f, "#32486E")
            layoutParams = LinearLayout.LayoutParams(dp(46), dp(40))
            setOnClickListener {
                if (calMonth == 0) { calMonth = 11; calYear-- } else calMonth--
                refreshCurrentTab()
            }
        })
        calNav.addView(TextView(this).apply {
            text = "Mapa kolorów: ${monthName.replaceFirstChar { it.uppercase() }}"
            textSize = 15f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        })
        calNav.addView(Button(this).apply {
            text = "▶"
            setTextColor(Color.WHITE)
            background = roundedBox("#1B2942", 12f, "#32486E")
            layoutParams = LinearLayout.LayoutParams(dp(46), dp(40))
            setOnClickListener {
                if (calMonth == 11) { calMonth = 0; calYear++ } else calMonth++
                refreshCurrentTab()
            }
        })
        calCard.addView(calNav)

        val monthPrefix = String.format(Locale.US, "%04d-%02d-", calYear, calMonth + 1)
        val monthStats = dayStats.filter { it.dateKey.startsWith(monthPrefix) }
        val nonZero = monthStats.map { it.estimatedDriverEarned }.filter { it > 0.0 }.sorted()
        val lowCut = if (nonZero.size >= 3) nonZero[nonZero.size / 3] else 50.0
        val highCut = if (nonZero.size >= 3) nonZero[(nonZero.size * 2) / 3] else 150.0

        val daysInMonth = Calendar.getInstance().apply { set(calYear, calMonth, 1) }.getActualMaximum(Calendar.DAY_OF_MONTH)
        val statByKey = monthStats.associateBy { it.dateKey }

        var rowIdx = 0
        var dayCursor = 1
        while (dayCursor <= daysInMonth) {
            val rLay = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                    bottomMargin = dp(4)
                }
            }
            for (cIdx in 0..6) {
                if (dayCursor > daysInMonth) {
                    rLay.addView(View(this).apply {
                        layoutParams = LinearLayout.LayoutParams(0, dp(36), 1f).apply { rightMargin = dp(3) }
                    })
                    continue
                }
                val dk = String.format(Locale.US, "%04d-%02d-%02d", calYear, calMonth + 1, dayCursor)
                val st = statByKey[dk]
                val valEarned = st?.estimatedDriverEarned ?: 0.0
                val bgHex = when {
                    valEarned <= 0.0 -> "#162033"
                    valEarned >= highCut && highCut > 0.0 -> "#1E5631"
                    valEarned >= lowCut && lowCut > 0.0 -> "#5C4914"
                    else -> "#5E1E28"
                }
                val dNum = dayCursor
                rLay.addView(Button(this).apply {
                    text = "$dNum"
                    textSize = 11f
                    setTextColor(Color.WHITE)
                    background = roundedBox(bgHex, 10f, "#2E4266")
                    setPadding(0, 0, 0, 0)
                    layoutParams = LinearLayout.LayoutParams(0, dp(36), 1f).apply { rightMargin = dp(3) }
                    setOnClickListener {
                        paySelectedDateKey = dk
                        selectedBarDayKey = dk
                        Toast.makeText(
                            this@MainActivity,
                            "$dk: ~${formatMoney(valEarned)} (${st?.tripsCount ?: 0} kursów)",
                            Toast.LENGTH_SHORT
                        ).show()
                        refreshCurrentTab()
                    }
                })
                dayCursor++
            }
            calCard.addView(rLay)
            rowIdx++
        }
        container.addView(calCard)

        // 7. Analiza godzinowa ("Kiedy rosną zarobki") + TOP 3 godziny
        val hourStats = OfflineAnalytics.buildHourStats(this, sharePct)
        val topHours = hourStats.filter { it.grossSum > 0.0 }.sortedByDescending { it.grossSum }.take(3)
        val hourCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = roundedBox("#101827", 22f, "#24344E")
            setPadding(dp(14), dp(14), dp(14), dp(14))
        }
        hourCard.addView(TextView(this).apply {
            text = "Kiedy rosną zarobki (TOP 3 godziny)"
            textSize = 16f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 0, 0, dp(6))
        })
        if (topHours.isEmpty()) {
            hourCard.addView(TextView(this).apply {
                text = "Brak danych godzinowych — wgraj CSV lub zapisz kursy w historii."
                textSize = 12.5f
                setTextColor(Color.parseColor("#8A99B5"))
            })
        } else {
            topHours.forEachIndexed { idx, hStat ->
                hourCard.addView(TextView(this).apply {
                    text = "${idx + 1}. ${hStat.label} — suma: ${formatMoney(hStat.grossSum)} (szac. udział: ${formatMoney(hStat.estimatedDriverEarned)}, kursów: ${hStat.tripsCount})"
                    textSize = 13f
                    setTextColor(Color.parseColor("#D5E3F7"))
                    setPadding(0, dp(3), 0, dp(3))
                })
            }
        }
        container.addView(hourCard)

        scroll.addView(container)
        return scroll
    }

    private fun fromInclusiveMillis(cal: Calendar): Long {
        val c = cal.clone() as Calendar
        c.set(Calendar.SECOND, 0)
        c.set(Calendar.MILLISECOND, 0)
        return c.timeInMillis
    }

    private fun toExclusiveMillis(cal: Calendar): Long {
        val c = cal.clone() as Calendar
        c.set(Calendar.SECOND, 0)
        c.set(Calendar.MILLISECOND, 0)
        c.add(Calendar.MINUTE, 1)
        return c.timeInMillis
    }

    private fun formatRangeDisplay(fromInclusive: Long, toExclusive: Long): String {
        val sdf = SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault())
        val endDisplay = Date(maxOf(fromInclusive, toExclusive - 60_000L))
        return "${sdf.format(Date(fromInclusive))} – ${sdf.format(endDisplay)}"
    }

    private fun formatMoney(value: Double): String {
        val symbols = DecimalFormatSymbols(Locale("pl", "PL")).apply {
            groupingSeparator = ' '
            decimalSeparator = ','
        }
        val df = DecimalFormat("#,##0.00", symbols)
        return "${df.format(value)} zł"
    }

    private fun pickDate(initial: Calendar, onPicked: (Calendar) -> Unit) {
        DatePickerDialog(
            this,
            { _, year, month, dayOfMonth ->
                val res = initial.clone() as Calendar
                res.set(Calendar.YEAR, year)
                res.set(Calendar.MONTH, month)
                res.set(Calendar.DAY_OF_MONTH, dayOfMonth)
                onPicked(res)
            },
            initial.get(Calendar.YEAR),
            initial.get(Calendar.MONTH),
            initial.get(Calendar.DAY_OF_MONTH)
        ).show()
    }

    private fun pickTime(initial: Calendar, onPicked: (Calendar) -> Unit) {
        TimePickerDialog(
            this,
            { _, hourOfDay, minute ->
                val res = initial.clone() as Calendar
                res.set(Calendar.HOUR_OF_DAY, hourOfDay)
                res.set(Calendar.MINUTE, minute)
                onPicked(res)
            },
            initial.get(Calendar.HOUR_OF_DAY),
            initial.get(Calendar.MINUTE),
            true
        ).show()
    }

    private fun buildHistoryView(): View {
        val scroll = ScrollView(this)
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(16), dp(14), dp(28))
        }

        val sdfDate = SimpleDateFormat("dd.MM.yyyy", Locale.getDefault())
        val sdfTime = SimpleDateFormat("HH:mm", Locale.getDefault())
        val sdfFull = SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault())

        val draftFrom = (filterFromCal?.clone() as? Calendar) ?: Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val draftTo = (filterToCal?.clone() as? Calendar) ?: Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 23)
            set(Calendar.MINUTE, 59)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }

        val filterCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = roundedBox("#101827", 22f, "#24344E")
            setPadding(dp(14), dp(14), dp(14), dp(14))
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = dp(12)
            }
        }

        filterCard.addView(TextView(this).apply {
            text = "ZAKRES HISTORII"
            textSize = 15f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 0, 0, dp(8))
        })

        val shortcutsRow1 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = dp(6)
            }
        }
        val shortcutsRow2 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = dp(10)
            }
        }
        fun addShortcut(parentRow: LinearLayout, label: String, onClick: () -> Unit) {
            parentRow.addView(Button(this).apply {
                text = label
                textSize = 11f
                setTextColor(Color.parseColor("#C2D1E5"))
                background = roundedBox("#162338", 14f, "#2E4266")
                setPadding(dp(6), dp(4), dp(6), dp(4))
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                    rightMargin = dp(4)
                }
                setOnClickListener { onClick() }
            })
        }
        addShortcut(shortcutsRow1, "Dzisiaj") {
            val f = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            }
            val t = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, 23); set(Calendar.MINUTE, 59); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            }
            filterFromCal = f
            filterToCal = t
            refreshCurrentTab()
        }
        addShortcut(shortcutsRow1, "Wczoraj") {
            val f = Calendar.getInstance().apply {
                add(Calendar.DAY_OF_MONTH, -1)
                set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            }
            val t = Calendar.getInstance().apply {
                add(Calendar.DAY_OF_MONTH, -1)
                set(Calendar.HOUR_OF_DAY, 23); set(Calendar.MINUTE, 59); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            }
            filterFromCal = f
            filterToCal = t
            refreshCurrentTab()
        }
        addShortcut(shortcutsRow2, "Ten tydzień") {
            val f = Calendar.getInstance().apply {
                firstDayOfWeek = Calendar.MONDAY
                set(Calendar.DAY_OF_WEEK, Calendar.MONDAY)
                set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            }
            val t = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, 23); set(Calendar.MINUTE, 59); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            }
            filterFromCal = f
            filterToCal = t
            refreshCurrentTab()
        }
        addShortcut(shortcutsRow2, "Ten miesiąc") {
            val f = Calendar.getInstance().apply {
                set(Calendar.DAY_OF_MONTH, 1)
                set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            }
            val t = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, 23); set(Calendar.MINUTE, 59); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            }
            filterFromCal = f
            filterToCal = t
            refreshCurrentTab()
        }
        filterCard.addView(shortcutsRow1)
        filterCard.addView(shortcutsRow2)

        val fromLabels = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fromLabels.addView(TextView(this).apply {
            text = "Data od:"
            textSize = 12f
            setTextColor(Color.parseColor("#8A99B5"))
            typeface = Typeface.DEFAULT_BOLD
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.3f)
        })
        fromLabels.addView(TextView(this).apply {
            text = "Godzina od:"
            textSize = 12f
            setTextColor(Color.parseColor("#8A99B5"))
            typeface = Typeface.DEFAULT_BOLD
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        })
        filterCard.addView(fromLabels)

        val fromRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                topMargin = dp(4)
                bottomMargin = dp(8)
            }
        }
        val btnFromDate = Button(this).apply {
            text = "📅 ${sdfDate.format(draftFrom.time)}"
            textSize = 12f
            setTextColor(Color.WHITE)
            background = roundedBox("#162338", 14f, "#32486E")
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.3f).apply { rightMargin = dp(6) }
        }
        val btnFromTime = Button(this).apply {
            text = "🕒 ${sdfTime.format(draftFrom.time)}"
            textSize = 12f
            setTextColor(Color.WHITE)
            background = roundedBox("#162338", 14f, "#32486E")
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        btnFromDate.setOnClickListener {
            pickDate(draftFrom) { chosen ->
                draftFrom.set(Calendar.YEAR, chosen.get(Calendar.YEAR))
                draftFrom.set(Calendar.MONTH, chosen.get(Calendar.MONTH))
                draftFrom.set(Calendar.DAY_OF_MONTH, chosen.get(Calendar.DAY_OF_MONTH))
                btnFromDate.text = "📅 ${sdfDate.format(draftFrom.time)}"
            }
        }
        btnFromTime.setOnClickListener {
            pickTime(draftFrom) { chosen ->
                draftFrom.set(Calendar.HOUR_OF_DAY, chosen.get(Calendar.HOUR_OF_DAY))
                draftFrom.set(Calendar.MINUTE, chosen.get(Calendar.MINUTE))
                btnFromTime.text = "🕒 ${sdfTime.format(draftFrom.time)}"
            }
        }
        fromRow.addView(btnFromDate)
        fromRow.addView(btnFromTime)
        filterCard.addView(fromRow)

        val toLabels = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        toLabels.addView(TextView(this).apply {
            text = "Data do:"
            textSize = 12f
            setTextColor(Color.parseColor("#8A99B5"))
            typeface = Typeface.DEFAULT_BOLD
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.3f)
        })
        toLabels.addView(TextView(this).apply {
            text = "Godzina do:"
            textSize = 12f
            setTextColor(Color.parseColor("#8A99B5"))
            typeface = Typeface.DEFAULT_BOLD
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        })
        filterCard.addView(toLabels)

        val toRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                topMargin = dp(4)
                bottomMargin = dp(10)
            }
        }
        val btnToDate = Button(this).apply {
            text = "📅 ${sdfDate.format(draftTo.time)}"
            textSize = 12f
            setTextColor(Color.WHITE)
            background = roundedBox("#162338", 14f, "#32486E")
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.3f).apply { rightMargin = dp(6) }
        }
        val btnToTime = Button(this).apply {
            text = "🕒 ${sdfTime.format(draftTo.time)}"
            textSize = 12f
            setTextColor(Color.WHITE)
            background = roundedBox("#162338", 14f, "#32486E")
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        btnToDate.setOnClickListener {
            pickDate(draftTo) { chosen ->
                draftTo.set(Calendar.YEAR, chosen.get(Calendar.YEAR))
                draftTo.set(Calendar.MONTH, chosen.get(Calendar.MONTH))
                draftTo.set(Calendar.DAY_OF_MONTH, chosen.get(Calendar.DAY_OF_MONTH))
                btnToDate.text = "📅 ${sdfDate.format(draftTo.time)}"
            }
        }
        btnToTime.setOnClickListener {
            pickTime(draftTo) { chosen ->
                draftTo.set(Calendar.HOUR_OF_DAY, chosen.get(Calendar.HOUR_OF_DAY))
                draftTo.set(Calendar.MINUTE, chosen.get(Calendar.MINUTE))
                btnToTime.text = "🕒 ${sdfTime.format(draftTo.time)}"
            }
        }
        toRow.addView(btnToDate)
        toRow.addView(btnToTime)
        filterCard.addView(toRow)

        val actionRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }
        actionRow.addView(Button(this).apply {
            text = "Zastosuj"
            setTextColor(Color.parseColor("#041E14"))
            typeface = Typeface.DEFAULT_BOLD
            background = roundedBox("#2CE574", 16f)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { rightMargin = dp(6) }
            setOnClickListener {
                val fromInc = fromInclusiveMillis(draftFrom)
                val toExc = toExclusiveMillis(draftTo)
                if (toExc <= fromInc) {
                    Toast.makeText(
                        this@MainActivity,
                        "Nieprawidłowy zakres: data i godzina końcowa nie mogą być wcześniejsze od początkowej.",
                        Toast.LENGTH_LONG
                    ).show()
                    return@setOnClickListener
                }
                filterFromCal = (draftFrom.clone() as Calendar).apply {
                    set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
                }
                filterToCal = (draftTo.clone() as Calendar).apply {
                    set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
                }
                refreshCurrentTab()
            }
        })
        actionRow.addView(Button(this).apply {
            text = "Wszystko"
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            background = roundedBox(if (filterFromCal == null && filterToCal == null) "#0099FF" else "#1B2942", 16f, "#38B6FF")
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = dp(6) }
            setOnClickListener {
                filterFromCal = null
                filterToCal = null
                refreshCurrentTab()
            }
        })
        filterCard.addView(actionRow)
        container.addView(filterCard)

        val activeFromInc = filterFromCal?.let { fromInclusiveMillis(it) }
        val activeToExc = filterToCal?.let { toExclusiveMillis(it) }
        val filteredList = RadarStorage.filterHistory(this, activeFromInc, activeToExc)
        val summary = RadarStorage.calculateSummary(filteredList)

        val periodLabel = if (activeFromInc != null && activeToExc != null) {
            formatRangeDisplay(activeFromInc, activeToExc)
        } else {
            "Wszystko"
        }

        val summaryCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = roundedBox("#0A2229", 22f, "#26A69A")
            setPadding(dp(16), dp(14), dp(16), dp(14))
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = dp(12)
            }
        }
        summaryCard.addView(TextView(this).apply {
            text = "Wybrany okres: $periodLabel"
            textSize = 13f
            setTextColor(Color.parseColor("#A5B8D1"))
        })
        summaryCard.addView(TextView(this).apply {
            text = "Przyjęte kursy: ${summary.acceptedCount}"
            textSize = 15f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(4), 0, dp(2))
        })
        summaryCard.addView(TextView(this).apply {
            text = "Suma przyjętych ofert: ${formatMoney(summary.acceptedSumPln)}"
            textSize = 19f
            setTextColor(Color.parseColor("#2CE574"))
            typeface = Typeface.DEFAULT_BOLD
        })
        summaryCard.addView(TextView(this).apply {
            text = "Kwoty z ofert zapisanych jako przyjęte (bez screenów)"
            textSize = 11f
            setTextColor(Color.parseColor("#8A99B5"))
            setPadding(0, dp(2), 0, 0)
        })
        container.addView(summaryCard)

        container.addView(Button(this).apply {
            text = "Usuń historię"
            textSize = 13f
            setTextColor(Color.parseColor("#FF8A8A"))
            typeface = Typeface.DEFAULT_BOLD
            background = roundedBox("#24131B", 16f, "#6E2E40")
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = dp(14)
            }
            setOnClickListener { openDeleteHistoryDialog() }
        })

        container.addView(TextView(this).apply {
            text = "Wszystkie zapisane kursy (${filteredList.size})"
            textSize = 16f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 0, 0, dp(10))
        })

        if (filteredList.isEmpty()) {
            container.addView(TextView(this).apply {
                text = "Brak kursów w wybranym okresie"
                textSize = 14f
                setTextColor(Color.parseColor("#8A99B5"))
                setPadding(dp(8), dp(20), dp(8), dp(20))
            })
        }

        filteredList.take(250).forEach { item ->
            val rateTrip = if (item.rateCourse > 0.0) item.rateCourse else if (item.tripKm > 0) item.priceGross / item.tripKm else 0.0
            val rateTotal = if (item.rateWithPickup > 0.0) item.rateWithPickup else if (item.totalKm > 0) item.priceGross / item.totalKm else rateTrip
            val st = item.normalizedStatus
            val isScreen = item.source == "SCREEN" || st == OfferStatus.REVIEW

            val borderColor = when {
                isScreen -> "#2F6C9A"
                st == OfferStatus.ACCEPTED -> "#2E7D32"
                st == OfferStatus.REJECTED -> "#6E2E40"
                else -> "#24344E"
            }

            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                background = roundedBox("#101827", 22f, borderColor)
                setPadding(dp(15), dp(14), dp(15), dp(14))
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                    bottomMargin = dp(10)
                }
            }

            val row1 = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            val srcTag = when (item.source) {
                "SCREEN" -> "Screen"
                "CSV", "CSV_BUNDLE", "CASH_BUNDLE" -> "CSV"
                else -> "Bolt"
            }
            val timeInfo = if (!isScreen && st == OfferStatus.ACCEPTED && item.acceptedTimestamp > 0L && item.acceptedTimestamp != item.timestamp) {
                "$srcTag • Przyjęto: ${sdfFull.format(Date(item.acceptedTimestamp))} (wykryto ${sdfTime.format(Date(item.timestamp))})"
            } else {
                "$srcTag • ${sdfFull.format(Date(item.effectiveTimestamp))}"
            }
            row1.addView(TextView(this).apply {
                text = timeInfo
                textSize = 12f
                setTextColor(Color.parseColor("#9BA9C2"))
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            })

            val statusLabel = OfferStatus.labelPl(st, item.source)
            val (statusTextColor, statusBg, statusStroke) = when {
                isScreen -> arrayOf("#6AB7FF", "#10202E", "#2F6C9A")
                st == OfferStatus.ACCEPTED -> arrayOf("#4CE0B3", "#0E2923", "#2E7D32")
                st == OfferStatus.REJECTED -> arrayOf("#FF8A8A", "#2B141C", "#8E3B4E")
                else -> arrayOf("#FFD54F", "#2B2414", "#8E733B")
            }
            row1.addView(TextView(this).apply {
                text = statusLabel
                textSize = 11f
                setTextColor(Color.parseColor(statusTextColor))
                background = roundedBox(statusBg, 16f, statusStroke)
                setPadding(dp(10), dp(4), dp(10), dp(4))
            })
            card.addView(row1)

            val row2 = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, dp(8), 0, dp(4))
            }
            row2.addView(TextView(this).apply {
                text = formatMoney(item.priceGross)
                textSize = 25f
                setTextColor(Color.WHITE)
                typeface = Typeface.DEFAULT_BOLD
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            })
            if (rateTrip > 0.0) {
                row2.addView(TextView(this).apply {
                    text = String.format(Locale("pl", "PL"), "%.2f zł/km", rateTrip)
                    textSize = 20f
                    setTextColor(
                        when {
                            isScreen -> Color.parseColor("#6AB7FF")
                            st == OfferStatus.ACCEPTED -> Color.parseColor("#3DDC84")
                            st == OfferStatus.REJECTED -> Color.parseColor("#FF8A8A")
                            else -> Color.parseColor("#FFD54F")
                        }
                    )
                    typeface = Typeface.DEFAULT_BOLD
                })
            }
            card.addView(row2)

            val row3 = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            row3.addView(TextView(this).apply {
                text = if (item.tripKm > 0.0) {
                    if (item.pickupKm > 0.05) {
                        String.format(
                            Locale("pl", "PL"),
                            "Kurs: %.1f km (%.2f zł/km) • Dojazd: %.1f km (z dojazdem: %.2f zł/km)",
                            item.tripKm, rateTrip, item.pickupKm, rateTotal
                        )
                    } else {
                        String.format(Locale("pl", "PL"), "Kurs: %.1f km • brak danych dojazdu", item.tripKm)
                    }
                } else {
                    "Wpis rozliczeniowy / import"
                }
                textSize = 12f
                setTextColor(Color.parseColor("#6AB7FF"))
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            })
            row3.addView(Button(this).apply {
                text = "Usuń"
                textSize = 11f
                setTextColor(Color.parseColor("#FF8A8A"))
                background = roundedBox("#28151E", 14f, "#5C2B38")
                setPadding(dp(10), dp(2), dp(10), dp(2))
                setOnClickListener {
                    OfflineAnalytics.snapshotUndo(this@MainActivity, "usunięcie wpisu")
                    RadarStorage.deleteHistoryItem(this@MainActivity, item.id)
                    refreshCurrentTab()
                }
            })
            card.addView(row3)

            if (item.pickupAddress.isNotBlank()) {
                card.addView(TextView(this).apply {
                    text = "Odbiór: ${item.pickupAddress}"
                    textSize = 12f
                    setTextColor(Color.parseColor("#9BA9C2"))
                    setPadding(0, dp(6), 0, 0)
                })
            }
            card.addView(TextView(this).apply {
                text = "Cel: ${item.destination}"
                textSize = 13f
                setTextColor(Color.parseColor("#8A99B5"))
                setPadding(0, dp(4), 0, 0)
            })

            container.addView(card)
        }

        if (filteredList.size > 250) {
            container.addView(TextView(this).apply {
                text = "Wyświetlono 250 najnowszych pozycji z ${filteredList.size}. Zawęź zakres dat, aby przeglądać starsze."
                textSize = 12f
                setTextColor(Color.parseColor("#8A99B5"))
                setPadding(0, dp(4), 0, dp(8))
            })
        }

        scroll.addView(container)
        return scroll
    }

    private fun openDeleteHistoryDialog() {
        val options = arrayOf(
            "Usuń z wybranego zakresu",
            "Usuń całą historię"
        )
        AlertDialog.Builder(this)
            .setTitle("Usuń historię")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> openDeleteRangeDialog()
                    1 -> openConfirmDeleteAllDialog()
                }
            }
            .setNegativeButton("Anuluj", null)
            .show()
    }

    private fun openDeleteRangeDialog() {
        val sdfDate = SimpleDateFormat("dd.MM.yyyy", Locale.getDefault())
        val sdfTime = SimpleDateFormat("HH:mm", Locale.getDefault())

        val delFrom = (filterFromCal?.clone() as? Calendar) ?: Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val delTo = (filterToCal?.clone() as? Calendar) ?: Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 23)
            set(Calendar.MINUTE, 59)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(14), dp(20), dp(8))
        }

        box.addView(TextView(this).apply { text = "Data od:"; textSize = 12f; typeface = Typeface.DEFAULT_BOLD })
        val bFromDate = Button(this).apply { text = sdfDate.format(delFrom.time) }
        box.addView(bFromDate)

        box.addView(TextView(this).apply { text = "Godzina od:"; textSize = 12f; typeface = Typeface.DEFAULT_BOLD; setPadding(0, dp(6), 0, 0) })
        val bFromTime = Button(this).apply { text = sdfTime.format(delFrom.time) }
        box.addView(bFromTime)

        box.addView(TextView(this).apply { text = "Data do:"; textSize = 12f; typeface = Typeface.DEFAULT_BOLD; setPadding(0, dp(8), 0, 0) })
        val bToDate = Button(this).apply { text = sdfDate.format(delTo.time) }
        box.addView(bToDate)

        box.addView(TextView(this).apply { text = "Godzina do:"; textSize = 12f; typeface = Typeface.DEFAULT_BOLD; setPadding(0, dp(6), 0, 0) })
        val bToTime = Button(this).apply { text = sdfTime.format(delTo.time) }
        box.addView(bToTime)

        bFromDate.setOnClickListener {
            pickDate(delFrom) { c ->
                delFrom.set(Calendar.YEAR, c.get(Calendar.YEAR))
                delFrom.set(Calendar.MONTH, c.get(Calendar.MONTH))
                delFrom.set(Calendar.DAY_OF_MONTH, c.get(Calendar.DAY_OF_MONTH))
                bFromDate.text = sdfDate.format(delFrom.time)
            }
        }
        bFromTime.setOnClickListener {
            pickTime(delFrom) { c ->
                delFrom.set(Calendar.HOUR_OF_DAY, c.get(Calendar.HOUR_OF_DAY))
                delFrom.set(Calendar.MINUTE, c.get(Calendar.MINUTE))
                bFromTime.text = sdfTime.format(delFrom.time)
            }
        }
        bToDate.setOnClickListener {
            pickDate(delTo) { c ->
                delTo.set(Calendar.YEAR, c.get(Calendar.YEAR))
                delTo.set(Calendar.MONTH, c.get(Calendar.MONTH))
                delTo.set(Calendar.DAY_OF_MONTH, c.get(Calendar.DAY_OF_MONTH))
                bToDate.text = sdfDate.format(delTo.time)
            }
        }
        bToTime.setOnClickListener {
            pickTime(delTo) { c ->
                delTo.set(Calendar.HOUR_OF_DAY, c.get(Calendar.HOUR_OF_DAY))
                delTo.set(Calendar.MINUTE, c.get(Calendar.MINUTE))
                bToTime.text = sdfTime.format(delTo.time)
            }
        }

        AlertDialog.Builder(this)
            .setTitle("Usuń z wybranego zakresu")
            .setView(box)
            .setNegativeButton("Anuluj", null)
            .setPositiveButton("Dalej") { _, _ ->
                val fromInc = fromInclusiveMillis(delFrom)
                val toExc = toExclusiveMillis(delTo)
                if (toExc <= fromInc) {
                    Toast.makeText(
                        this,
                        "Nieprawidłowy zakres: data i godzina końcowa nie mogą być wcześniejsze od początkowej.",
                        Toast.LENGTH_LONG
                    ).show()
                    return@setPositiveButton
                }
                val matching = RadarStorage.filterHistory(this, fromInc, toExc)
                openConfirmDeleteRangeDialog(fromInc, toExc, matching)
            }
            .show()
    }

    private fun openConfirmDeleteRangeDialog(fromInc: Long, toExc: Long, matching: List<RideEntry>) {
        val count = matching.size
        val rangeText = formatRangeDisplay(fromInc, toExc)
        val msg = "Usunąć $count wpisów historii z okresu\n$rangeText?\nTej operacji nie można cofnąć."
        AlertDialog.Builder(this)
            .setTitle("Potwierdzenie usunięcia")
            .setMessage(msg)
            .setNegativeButton("Anuluj", null)
            .setPositiveButton("Usuń") { _, _ ->
                OfflineAnalytics.snapshotUndo(this, "usunięcie zakresu historii")
                matching.firstOrNull()?.let { latest ->
                    val sig = String.format(Locale.US, "%d|%.1f", latest.priceGrosze, latest.tripKm)
                    RadarStorage.suppressOfferSignature(this, sig)
                }
                val deleted = RadarStorage.deleteHistoryInRange(this, fromInc, toExc)
                Toast.makeText(this, "Usunięto wpisów: $deleted", Toast.LENGTH_SHORT).show()
                refreshCurrentTab()
            }
            .show()
    }

    private fun openConfirmDeleteAllDialog() {
        val total = RadarStorage.getHistory(this).size
        val msg = "Usunąć całą historię — łącznie $total wpisów?\nTej operacji nie można cofnąć."
        AlertDialog.Builder(this)
            .setTitle("Potwierdzenie usunięcia")
            .setMessage(msg)
            .setNegativeButton("Anuluj", null)
            .setPositiveButton("Usuń") { _, _ ->
                OfflineAnalytics.snapshotUndo(this, "usunięcie całej historii")
                RadarStorage.getHistory(this).firstOrNull()?.let { latest ->
                    val sig = String.format(Locale.US, "%d|%.1f", latest.priceGrosze, latest.tripKm)
                    RadarStorage.suppressOfferSignature(this, sig)
                }
                val deleted = RadarStorage.clearAllHistory(this)
                Toast.makeText(this, "Usunięto całą historię ($deleted wpisów).", Toast.LENGTH_SHORT).show()
                refreshCurrentTab()
            }
            .show()
    }

    private fun buildThresholdsView(): View {
        val scroll = ScrollView(this)

        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(20), dp(16), dp(28))
        }

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = roundedBox("#101827", 24f, "#24344E")
            setPadding(dp(18), dp(18), dp(18), dp(18))
        }

        fun addHeading(label: String) {
            card.addView(TextView(this@MainActivity).apply {
                text = label
                textSize = 18f
                setTextColor(Color.WHITE)
                typeface = Typeface.DEFAULT_BOLD
                setPadding(0, dp(14), 0, dp(8))
            })
        }

        addHeading("Sam kurs — lewa stawka")

        val tripGreen = addInputField(
            card,
            "Zielony od (zł/km):",
            RadarStorage.getGreenKmRate(this).toString()
        )

        val tripYellow = addInputField(
            card,
            "Żółty od (zł/km):",
            RadarStorage.getYellowKmRate(this).toString()
        )

        addHeading("Z dolotem — prawa stawka")

        val pickupGreen = addInputField(
            card,
            "Zielony od (zł/km):",
            RadarStorage.getPickupGreenKmRate(this).toString()
        )

        val pickupYellow = addInputField(
            card,
            "Żółty od (zł/km):",
            RadarStorage.getPickupYellowKmRate(this).toString()
        )

        card.addView(TextView(this).apply {
            text = "Poniżej progu żółtego stawka będzie czerwona."
            textSize = 13f
            setTextColor(Color.parseColor("#8A99B5"))
            setPadding(0, dp(14), 0, dp(8))
        })

        card.addView(Button(this).apply {
            text = "Zapisz progi obu stawek"
            setTextColor(Color.parseColor("#041E14"))
            typeface = Typeface.DEFAULT_BOLD
            background = roundedBox("#2CE574", 18f)

            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                topMargin = dp(16)
            }

            setOnClickListener {
                fun readValue(field: EditText): Float? =
                    field.text.toString()
                        .trim()
                        .replace(",", ".")
                        .toFloatOrNull()

                val tg = readValue(tripGreen)
                val ty = readValue(tripYellow)
                val pg = readValue(pickupGreen)
                val py = readValue(pickupYellow)

                if (
                    tg == null || ty == null ||
                    pg == null || py == null
                ) {
                    Toast.makeText(
                        this@MainActivity,
                        "Wpisz poprawne liczby we wszystkich polach.",
                        Toast.LENGTH_LONG
                    ).show()
                    return@setOnClickListener
                }

                if (
                    !tg.isFinite() || !ty.isFinite() ||
                    !pg.isFinite() || !py.isFinite() ||
                    tg <= 0f || ty <= 0f ||
                    pg <= 0f || py <= 0f ||
                    tg <= ty || pg <= py
                ) {
                    Toast.makeText(
                        this@MainActivity,
                        "Progi muszą być dodatnie. Zielony musi być wyższy od żółtego.",
                        Toast.LENGTH_LONG
                    ).show()
                    return@setOnClickListener
                }

                RadarStorage.saveRateThresholds(
                    this@MainActivity,
                    tg,
                    ty,
                    pg,
                    py
                )

                Toast.makeText(
                    this@MainActivity,
                    "Zapisano osobne progi obu stawek.",
                    Toast.LENGTH_SHORT
                ).show()
            }
        })

        container.addView(card)
        scroll.addView(container)
        return scroll
    }

    private fun buildSettingsView(): View {
        val scroll = ScrollView(this)
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(20), dp(16), dp(28))
        }

        val readingCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = roundedBox("#101827", 24f, "#24344E")
            setPadding(dp(18), dp(18), dp(18), dp(18))

            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = dp(16)
            }
        }

        readingCard.addView(TextView(this).apply {
            text = "Odczyt ekranu i historia"
            textSize = 18f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        })

        readingCard.addView(CheckBox(this).apply {
            text = "Zapisuj historię"
            textSize = 15f
            setTextColor(Color.WHITE)
            isChecked = RadarOptions.historyEnabled(this@MainActivity)

            setOnCheckedChangeListener { _, checked ->
                RadarOptions.setHistoryEnabled(this@MainActivity, checked)
            }
        })

        readingCard.addView(TextView(this).apply {
            text = "Wyłączenie zatrzymuje zapis nowych wpisów. " +
                "Nie usuwa dotychczasowej historii."
            textSize = 12f
            setTextColor(Color.parseColor("#9BA9C2"))
            setPadding(0, 0, 0, dp(12))
        })

        val fastId = View.generateViewId()
        val normalId = View.generateViewId()

        val readingModes = RadioGroup(this).apply {
            orientation = RadioGroup.VERTICAL
        }

        readingModes.addView(RadioButton(this).apply {
            id = fastId
            text = "Szybszy odczyt + weryfikacja"
            textSize = 15f
            setTextColor(Color.WHITE)
        })

        readingModes.addView(RadioButton(this).apply {
            id = normalId
            text = "Standardowy odczyt"
            textSize = 15f
            setTextColor(Color.WHITE)
        })

        readingModes.check(
            if (RadarOptions.fastReadEnabled(this)) fastId else normalId
        )

        readingModes.setOnCheckedChangeListener { _, id ->
            RadarOptions.setFastReadEnabled(
                this@MainActivity,
                id == fastId
            )
        }

        readingCard.addView(readingModes)

        readingCard.addView(TextView(this).apply {
            text = "Szybszy odczyt + weryfikacja: najpierw szybki wynik wstępny, " +
                "następnie odczyt w pełnej rozdzielczości sprawdzający cenę i dystanse.\n" +
                "Standardowy odczyt: od początku pełna rozdzielczość; " +
                "nowa oferta jest pokazywana po potwierdzeniu odczytu.\n" +
                "Oba tryby odczytują screeny widoczne w innych aplikacjach."
            textSize = 12f
            setTextColor(Color.parseColor("#9BA9C2"))
            setPadding(0, dp(8), 0, 0)
        })

        container.addView(readingCard)

        val modeCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = roundedBox("#101827", 24f, "#24344E")
            setPadding(dp(18), dp(18), dp(18), dp(18))
        }
        modeCard.addView(TextView(this).apply {
            text = "Wygląd wyskakującego okienka"
            textSize = 18f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        })

        val chkDual = CheckBox(this).apply {
            text = "Pokazuj dwie kwoty obok siebie:\nLewa: zł/km za sam kurs | Prawa: zł/km z dojazdem"
            setTextColor(Color.WHITE)
            textSize = 14f
            isChecked = RadarStorage.isDualRateEnabled(this@MainActivity)
            setPadding(0, dp(10), 0, dp(12))
            setOnCheckedChangeListener { _, checked ->
                RadarStorage.setDualRateEnabled(this@MainActivity, checked)
                Toast.makeText(this@MainActivity, if (checked) "Włączono widok dwóch stawek obok siebie" else "Włączono widok jednej stawki", Toast.LENGTH_SHORT).show()
            }
        }
        modeCard.addView(chkDual)

        val currentScale = RadarStorage.getOverlayScale(this)
        modeCard.addView(TextView(this).apply {
            text = "Skalowanie wielkości okienka (aktualnie: ${(currentScale * 100).toInt()}%):"
            textSize = 14f
            setTextColor(Color.parseColor("#3DDC84"))
            setPadding(0, dp(4), 0, dp(10))
        })

        val scales = listOf(
            0.80f to "Małe (80%)",
            1.00f to "Standardowe (100%)",
            1.20f to "Powiększone (120%)",
            1.40f to "Duże (140%)"
        )
        scales.forEach { (sc, label) ->
            val sel = abs(currentScale - sc) < 0.05f
            modeCard.addView(Button(this).apply {
                text = if (sel) "✓ $label" else label
                setTextColor(if (sel) Color.parseColor("#041E14") else Color.WHITE)
                background = roundedBox(if (sel) "#2CE574" else "#1B2942", 16f, if (sel) "#2CE574" else "#32486E")
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(8) }
                setOnClickListener {
                    RadarStorage.setOverlayScale(this@MainActivity, sc)
                    refreshCurrentTab()
                }
            })
        }
        container.addView(modeCard)

        val permCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = roundedBox("#101827", 24f, "#24344E")
            setPadding(dp(18), dp(18), dp(18), dp(18))
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(16) }
        }
        permCard.addView(TextView(this).apply {
            text = "Uprawnienia (Nakładka, Odczyt ekranu, GPS)"
            textSize = 17f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 0, 0, dp(10))
        })
        permCard.addView(Button(this).apply {
            text = "1. Zezwól na wyświetlanie nad innymi aplikacjami"
            setTextColor(Color.WHITE)
            background = roundedBox("#1B2942", 16f, "#38B6FF")
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(8) }
            setOnClickListener {
                try {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                } catch (_: Exception) {}
            }
        })
        permCard.addView(Button(this).apply {
            text = "2. Włącz Usługę Odczytu Ekranu (Ułatwienia dostępu)"
            setTextColor(Color.WHITE)
            background = roundedBox("#1B2942", 16f, "#38B6FF")
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(8) }
            setOnClickListener {
                try {
                    startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                } catch (_: Exception) {}
            }
        })
        permCard.addView(Button(this).apply {
            text = "3. Zezwól na dostęp do GPS (Licznik km)"
            setTextColor(Color.WHITE)
            background = roundedBox("#1B2942", 16f, "#38B6FF")
            setOnClickListener {
                ActivityCompat.requestPermissions(this@MainActivity, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), 101)
            }
        })
        val btnBg = Button(this).apply {
            text = "Lokalizacja: ustaw Zawsze zezwalaj (potrzebne w tle)"
            setTextColor(Color.WHITE)
            background = roundedBox("#1B2942", 16f, "#38B6FF")
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(16) }
            setOnClickListener {
                try {
                    startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
                } catch (_: Exception) {}
            }
        }
        container.addView(permCard)
        container.addView(btnBg)

        val dbgPrefs = this@MainActivity.getSharedPreferences("KursRadarDebug", Context.MODE_PRIVATE)
        val dbgCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = roundedBox("#101827", 24f, "#24344E")
            setPadding(dp(18), dp(18), dp(18), dp(18))
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(16) }
        }
        dbgCard.addView(TextView(this).apply {
            text = "Diagnostyka odczytu i OCR"
            textSize = 15f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        })
        dbgCard.addView(TextView(this).apply {
            text = dbgPrefs.getString("ocr_performance", "Brak pomiaru OCR") ?: "Brak pomiaru OCR"
            textSize = 12f
            setTextColor(Color.parseColor("#C2D1E5"))
            setTextIsSelectable(true)
            setPadding(0, dp(8), 0, dp(8))
        })
        dbgCard.addView(TextView(this).apply {
            text = dbgPrefs.getString("last_text", "(jeszcze nic nie odczytano)") ?: ""
            textSize = 11f
            setTextColor(Color.parseColor("#8A99B5"))
            setTextIsSelectable(true)
        })
        container.addView(dbgCard)

        scroll.addView(container)
        return scroll
    }

    private fun twoCols(left: View, right: View): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(12) }
            left.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { rightMargin = dp(6) }
            right.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = dp(6) }
            addView(left)
            addView(right)
        }
    }

    private fun statTile(label: String, value: String, colorHex: String): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = roundedBox("#101929", 22f, "#22324C")
            setPadding(dp(16), dp(16), dp(16), dp(16))
            addView(TextView(this@MainActivity).apply { text = label; textSize = 13f; setTextColor(Color.parseColor("#99AABB")) })
            addView(TextView(this@MainActivity).apply {
                text = value; textSize = 21f; setTextColor(Color.parseColor(colorHex)); typeface = Typeface.DEFAULT_BOLD; setPadding(0, dp(6), 0, 0)
            })
        }
    }

    private fun addInputField(parent: LinearLayout, label: String, initVal: String): EditText {
        parent.addView(TextView(this).apply { text = label; textSize = 13f; setTextColor(Color.parseColor("#99AABB")); setPadding(0, dp(10), 0, dp(4)) })
        val et = EditText(this).apply {
            setText(initVal); setTextColor(Color.WHITE); inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            background = roundedBox("#162338", 14f, "#32486E"); setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        parent.addView(et)
        return et
    }

    private fun roundedBox(fillHex: String, radiusDp: Float, strokeHex: String? = null): GradientDrawable {
        return GradientDrawable().apply {
            setColor(Color.parseColor(fillHex))
            cornerRadius = dp(radiusDp.toInt()).toFloat()
            if (strokeHex != null) setStroke(dp(1), Color.parseColor(strokeHex))
        }
    }

    private fun dp(v: Int): Int = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics).toInt()
}
