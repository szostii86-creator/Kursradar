package com.example.kalkulatorkursow

import android.Manifest
import android.accessibilityservice.AccessibilityService
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.text.InputType
import android.util.TypedValue
import android.view.*
import android.view.accessibility.AccessibilityEvent
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.max

data class RideEntry(
    val id: String,
    val timestamp: Long,
    val priceGross: Double,
    val tripKm: Double,
    val pickupKm: Double,
    val offerMin: Int,
    val status: String,
    val destination: String,
    val source: String = "RADAR"
) {
    val totalKm: Double get() = tripKm + pickupKm
}

data class ScreenSummaryEntry(
    val dateKey: String,
    val totalBolt: Double,
    val campaigns: Double,
    val tips: Double,
    val cash: Double
)

object RadarStorage {
    private const val PREFS = "KursRadarPrefsV3"
    private fun p(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun isSessionRunning(ctx: Context): Boolean = p(ctx).getBoolean("session_running", false)
    fun setSessionRunning(ctx: Context, running: Boolean) = p(ctx).edit().putBoolean("session_running", running).apply()

    fun getSessionStartTime(ctx: Context): Long = p(ctx).getLong("session_start_ms", 0L)
    fun setSessionStartTime(ctx: Context, ms: Long) = p(ctx).edit().putLong("session_start_ms", ms).apply()

    fun getSessionStopTime(ctx: Context): Long = p(ctx).getLong("session_stop_ms", 0L)
    fun setSessionStopTime(ctx: Context, ms: Long) = p(ctx).edit().putLong("session_stop_ms", ms).apply()

    fun getGpsDistanceMeters(ctx: Context): Float = p(ctx).getFloat("gps_distance_m", 0f)
    fun setGpsDistanceMeters(ctx: Context, meters: Float) = p(ctx).edit().putFloat("gps_distance_m", meters).apply()
    fun addGpsDistanceMeters(ctx: Context, deltaMeters: Float) {
        setGpsDistanceMeters(ctx, getGpsDistanceMeters(ctx) + deltaMeters)
    }

    fun getSessionAcceptedCount(ctx: Context): Int = p(ctx).getInt("session_acc_count", 0)
    fun setSessionAcceptedCount(ctx: Context, count: Int) = p(ctx).edit().putInt("session_acc_count", count).apply()

    fun getSessionGrossTotal(ctx: Context): Float = p(ctx).getFloat("session_gross_total", 0f)
    fun setSessionGrossTotal(ctx: Context, total: Float) = p(ctx).edit().putFloat("session_gross_total", total).apply()

    fun isDualRateEnabled(ctx: Context): Boolean = p(ctx).getBoolean("dual_rate_enabled", true)
    fun setDualRateEnabled(ctx: Context, enabled: Boolean) = p(ctx).edit().putBoolean("dual_rate_enabled", enabled).apply()

    fun getOverlayScale(ctx: Context): Float = p(ctx).getFloat("overlay_scale", 1.0f)
    fun setOverlayScale(ctx: Context, scale: Float) = p(ctx).edit().putFloat("overlay_scale", scale).apply()

    fun getGreenKmRate(ctx: Context): Float = p(ctx).getFloat("green_km_rate", 2.80f)
    fun setGreenKmRate(ctx: Context, v: Float) = p(ctx).edit().putFloat("green_km_rate", v).apply()

    fun getYellowKmRate(ctx: Context): Float = p(ctx).getFloat("yellow_km_rate", 2.00f)
    fun setYellowKmRate(ctx: Context, v: Float) = p(ctx).edit().putFloat("yellow_km_rate", v).apply()

    fun getGreenPickupKmRate(ctx: Context): Float = p(ctx).getFloat("green_pickup_km_rate", 2.20f)
    fun setGreenPickupKmRate(ctx: Context, v: Float) = p(ctx).edit().putFloat("green_pickup_km_rate", v).apply()

    fun getYellowPickupKmRate(ctx: Context): Float = p(ctx).getFloat("yellow_pickup_km_rate", 1.60f)
    fun setYellowPickupKmRate(ctx: Context, v: Float) = p(ctx).edit().putFloat("yellow_pickup_km_rate", v).apply()

    fun getFuelConsumption(ctx: Context): Float = p(ctx).getFloat("fuel_consumption", 7.26f)
    fun setFuelConsumption(ctx: Context, fuel: Float) = p(ctx).edit().putFloat("fuel_consumption", fuel).apply()

    fun getHistory(ctx: Context): MutableList<RideEntry> {
        val raw = p(ctx).getString("history_json", "[]") ?: "[]"
        val list = mutableListOf<RideEntry>()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                list.add(
                    RideEntry(
                        id = o.optString("id"),
                        timestamp = o.optLong("t"),
                        priceGross = o.optDouble("price"),
                        tripKm = o.optDouble("tkm"),
                        pickupKm = o.optDouble("pkm"),
                        offerMin = o.optInt("min"),
                        status = o.optString("status", "ACCEPTED"),
                        destination = o.optString("dest", "Kraków"),
                        source = o.optString("src", "RADAR")
                    )
                )
            }
        } catch (_: Exception) {}
        list.sortByDescending { it.timestamp }
        return list
    }

    fun saveHistory(ctx: Context, list: List<RideEntry>) {
        val arr = JSONArray()
        list.forEach { r ->
            val o = JSONObject()
            o.put("id", r.id)
            o.put("t", r.timestamp)
            o.put("price", r.priceGross)
            o.put("tkm", r.tripKm)
            o.put("pkm", r.pickupKm)
            o.put("min", r.offerMin)
            o.put("status", r.status)
            o.put("dest", r.destination)
            o.put("src", r.source)
            arr.put(o)
        }
        p(ctx).edit().putString("history_json", arr.toString()).apply()
    }

    fun recordDecision(ctx: Context, entry: RideEntry) {
        val list = getHistory(ctx)
        list.add(0, entry)
        saveHistory(ctx, list)

        if (entry.status == "ACCEPTED" && isSessionRunning(ctx)) {
            setSessionAcceptedCount(ctx, getSessionAcceptedCount(ctx) + 1)
            setSessionGrossTotal(ctx, getSessionGrossTotal(ctx) + entry.priceGross.toFloat())
        }
    }

    fun deleteHistoryItem(ctx: Context, id: String) {
        val list = getHistory(ctx).filterNot { it.id == id }
        saveHistory(ctx, list)
    }

    fun importCsvTrips(ctx: Context, newEntries: List<RideEntry>): Int {
        val existing = getHistory(ctx)
        val seenIds = existing.map { it.id }.toHashSet()
        var added = 0
        newEntries.forEach { item ->
            if (!seenIds.contains(item.id)) {
                existing.add(item)
                seenIds.add(item.id)
                added++
            }
        }
        saveHistory(ctx, existing)
        return added
    }

    fun getScreenSummaries(ctx: Context): MutableList<ScreenSummaryEntry> {
        val raw = p(ctx).getString("screens_json", "[]") ?: "[]"
        val list = mutableListOf<ScreenSummaryEntry>()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                list.add(
                    ScreenSummaryEntry(
                        dateKey = o.optString("date"),
                        totalBolt = o.optDouble("bolt"),
                        campaigns = o.optDouble("camp"),
                        tips = o.optDouble("tips"),
                        cash = o.optDouble("cash")
                    )
                )
            }
        } catch (_: Exception) {}
        return list
    }

    fun addScreenSummary(ctx: Context, item: ScreenSummaryEntry) {
        val list = getScreenSummaries(ctx).filterNot { it.dateKey == item.dateKey }.toMutableList()
        list.add(0, item)
        val arr = JSONArray()
        list.forEach { s ->
            val o = JSONObject()
            o.put("date", s.dateKey)
            o.put("bolt", s.totalBolt)
            o.put("camp", s.campaigns)
            o.put("tips", s.tips)
            o.put("cash", s.cash)
            arr.put(o)
        }
        p(ctx).edit().putString("screens_json", arr.toString()).apply()
    }
}

class MainActivity : AppCompatActivity(), LocationListener {

    private lateinit var contentFrame: FrameLayout
    private lateinit var bottomNav: LinearLayout
    private var currentTab = "start"

    private var locationManager: LocationManager? = null
    private var lastLocation: Location? = null
    private val uiHandler = Handler(Looper.getMainLooper())
    private var recognizer: TextRecognizer? = null

    private fun getOrCreateRecognizer(): TextRecognizer? {
        if (recognizer == null) {
            recognizer = try {
                TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
            } catch (_: Exception) {
                null
            }
        }
        return recognizer
    }

    private val tickerRunnable = object : Runnable {
        override fun run() {
            if (RadarStorage.isSessionRunning(this@MainActivity) && currentTab == "start") {
                refreshCurrentTab()
            }
            uiHandler.postDelayed(this, 1000L)
        }
    }

    private val pickCsvLauncher = registerForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        if (uris.isNotEmpty()) handleCsvImport(uris)
    }

    private val pickScreensLauncher = registerForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        if (uris.isNotEmpty()) handleScreenshotsOcr(uris)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val crashFile = java.io.File(filesDir, "crash.txt")
        if (crashFile.exists()) {
            val tv = TextView(this).apply {
                text = crashFile.readText()
                setTextIsSelectable(true)
                setPadding(24, 24, 24, 24)
            }
            setContentView(ScrollView(this).apply { addView(tv) })
            crashFile.delete()
            return
        }
        try {
            locationManager = getSystemService(Context.LOCATION_SERVICE) as? LocationManager

            val root = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setBackgroundColor(Color.parseColor("#080E1A"))
                layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            }

            contentFrame = FrameLayout(this).apply {
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
            }

            bottomNav = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                background = roundedBox("#0D1526", 28f, "#1E2D4A")
                setPadding(dp(8), dp(10), dp(8), dp(10))
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                    setMargins(dp(12), dp(4), dp(12), dp(12))
                }
            }

            root.addView(contentFrame)
            root.addView(bottomNav)
            setContentView(root)

            switchTab("start")
            if (RadarStorage.isSessionRunning(this)) startGps()
        } catch (e: Exception) {
            Toast.makeText(this, "Błąd startu: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    override fun onResume() {
        super.onResume()
        try {
            uiHandler.removeCallbacks(tickerRunnable)
            uiHandler.post(tickerRunnable)
            if (::contentFrame.isInitialized) refreshCurrentTab()
        } catch (_: Exception) {}
    }

    override fun onPause() {
        super.onPause()
        uiHandler.removeCallbacks(tickerRunnable)
    }

    override fun onDestroy() {
        super.onDestroy()
        uiHandler.removeCallbacks(tickerRunnable)
        stopGps()
        try {
            recognizer?.close()
        } catch (_: Exception) {}
    }

    private fun startGps() {
        try {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), 101)
                return
            }
            lastLocation = null
            if (locationManager?.isProviderEnabled(LocationManager.GPS_PROVIDER) == true) {
                locationManager?.requestLocationUpdates(LocationManager.GPS_PROVIDER, 2000L, 4f, this)
            }
            if (locationManager?.isProviderEnabled(LocationManager.NETWORK_PROVIDER) == true) {
                locationManager?.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 3000L, 8f, this)
            }
        } catch (_: Exception) {}
    }

    private fun stopGps() {
        try {
            locationManager?.removeUpdates(this)
            lastLocation = null
        } catch (_: Exception) {}
    }

    override fun onLocationChanged(location: Location) {
        if (!RadarStorage.isSessionRunning(this)) return
        val prev = lastLocation
        if (prev != null) {
            val delta = prev.distanceTo(location)
            if (delta in 3.0f..500.0f) {
                // licznik km działa w usłudze (RideScannerService)
            }
        }
        lastLocation = location
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 101 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            if (RadarStorage.isSessionRunning(this)) startGps()
        }
    }

    private fun switchTab(tab: String) {
        currentTab = tab
        val tabs = listOf(
            "start" to "⚡\nStart",
            "historia" to "🕒\nHistoria",
            "progi" to "☰\nProgi PRO",
            "import" to "📂\nCSV / Screen",
            "ustawienia" to "⚙️\nUstawienia"
        )
        bottomNav.removeAllViews()
        tabs.forEach { (key, label) ->
            val active = currentTab == key
            bottomNav.addView(TextView(this).apply {
                text = label
                gravity = Gravity.CENTER
                textSize = 11f
                setTextColor(if (active) Color.parseColor("#38B6FF") else Color.parseColor("#8A99B5"))
                typeface = if (active) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                setOnClickListener { switchTab(key) }
            })
        }
        refreshCurrentTab()
    }

    private fun refreshCurrentTab() {
        if (!::contentFrame.isInitialized) return
        contentFrame.removeAllViews()
        val view = when (currentTab) {
            "start" -> buildStartAndStatsView()
            "historia" -> buildHistoryView()
            "progi" -> buildThresholdsView()
            "import" -> buildCsvAndScreensView()
            else -> buildSettingsView()
        }
        contentFrame.addView(view)
    }

    private fun buildStartAndStatsView(): View {
        val scroll = ScrollView(this)
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(20), dp(16), dp(28))
        }

        val running = RadarStorage.isSessionRunning(this)
        val startMs = RadarStorage.getSessionStartTime(this)
        val stopMs = if (running) System.currentTimeMillis() else RadarStorage.getSessionStopTime(this)

        val sdfDate = SimpleDateFormat("dd.MM HH:mm", Locale.getDefault())
        val sdfHour = SimpleDateFormat("HH:mm", Locale.getDefault())

        val topRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val titleCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        titleCol.addView(TextView(this).apply {
            text = if (running) "Odczyt ekranu aktywny" else "Sesja zakończona"
            textSize = 25f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        })
        titleCol.addView(TextView(this).apply {
            text = if (startMs > 0) "Taxi • ${sdfDate.format(Date(startMs))} do ${sdfHour.format(Date(stopMs))}" else "Taxi • Kliknij START, aby rozpocząć zmianę"
            textSize = 13f
            setTextColor(Color.parseColor("#8A99B5"))
        })

        val badge = TextView(this).apply {
            text = if (running) "● AKTYWNA" else "✓ ZAKOŃCZONA"
            textSize = 12f
            setTextColor(if (running) Color.parseColor("#3DDC84") else Color.parseColor("#4CE0B3"))
            background = roundedBox("#0C261E", 22f, "#2E7D32")
            setPadding(dp(14), dp(10), dp(14), dp(10))
        }
        topRow.addView(titleCol)
        topRow.addView(badge)
        container.addView(topRow)

        val btnStartStop = Button(this).apply {
            text = if (running) "⏹ STOP (Wyłącz nakładkę i zatrzymaj GPS)" else "▶ START (Włącz odczyt ekranu i licznik km GPS)"
            textSize = 15f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(if (running) Color.WHITE else Color.parseColor("#041E14"))
            background = roundedBox(if (running) "#D32F2F" else "#2CE574", 20f, if (running) "#FF6659" else "#65ECC5")
            setPadding(dp(16), dp(18), dp(16), dp(18))
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                topMargin = dp(18)
                bottomMargin = dp(16)
            }
            setOnClickListener {
                if (!running) {
                    if (!Settings.canDrawOverlays(this@MainActivity)) {
                        Toast.makeText(this@MainActivity, "Włącz uprawnienie Nakładki ekranowej!", Toast.LENGTH_LONG).show()
                        try {
                            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                        } catch (_: Exception) {}
                        return@setOnClickListener
                    }
                    val now = System.currentTimeMillis()
                    RadarStorage.setSessionStartTime(this@MainActivity, now)
                    RadarStorage.setSessionStopTime(this@MainActivity, now)
                    RadarStorage.setGpsDistanceMeters(this@MainActivity, 0f)
                    RadarStorage.setSessionAcceptedCount(this@MainActivity, 0)
                    RadarStorage.setSessionGrossTotal(this@MainActivity, 0f)
                    RadarStorage.setSessionRunning(this@MainActivity, true)
                    startGps()
                    if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this@MainActivity, "android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
                        ActivityCompat.requestPermissions(this@MainActivity, arrayOf("android.permission.POST_NOTIFICATIONS"), 102)
                    }
                    Toast.makeText(this@MainActivity, "START! Nakładka i licznik GPS włączone.", Toast.LENGTH_SHORT).show()
                } else {
                    RadarStorage.setSessionStopTime(this@MainActivity, System.currentTimeMillis())
                    RadarStorage.setSessionRunning(this@MainActivity, false)
                    stopGps()
                    Toast.makeText(this@MainActivity, "STOP! Odczyt wyłączony. Podsumowanie poniżej.", Toast.LENGTH_SHORT).show()
                }
                refreshCurrentTab()
            }
        }
        container.addView(btnStartStop)

        val gross = RadarStorage.getSessionGrossTotal(this).toDouble()
        val acceptedCount = RadarStorage.getSessionAcceptedCount(this)
        val gpsKm = RadarStorage.getGpsDistanceMeters(this) / 1000.0
        val avgKm = if (gpsKm > 0.05) gross / gpsKm else 0.0

        val sec = if (startMs > 0 && stopMs >= startMs) ((stopMs - startMs) / 1000L) else 0L
        val timeStr = String.format(Locale.US, "%02d:%02d:%02d", sec / 3600, (sec % 3600) / 60, sec % 60)

        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = roundedBox("#0A2229", 28f, "#26A69A")
            setPadding(dp(20), dp(26), dp(20), dp(26))
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = dp(16)
            }
        }
        hero.addView(TextView(this).apply {
            text = "PRZYCHÓD BRUTTO • ZAAKCEPTOWANE KURSY"
            textSize = 12f
            setTextColor(Color.parseColor("#A5B8D1"))
            gravity = Gravity.CENTER
        })
        hero.addView(TextView(this).apply {
            text = String.format(Locale("pl", "PL"), "%.2f zł", gross)
            textSize = 42f
            setTextColor(Color.parseColor("#2CE574"))
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(0, dp(6), 0, dp(6))
        })
        hero.addView(TextView(this).apply {
            text = if (running) "Liczenie km GPS i oczekiwanie na oferty..." else "Statystyki zakończonej sesji"
            textSize = 13f
            setTextColor(Color.parseColor("#C2D1E5"))
            gravity = Gravity.CENTER
        })
        container.addView(hero)

        container.addView(twoCols(statTile("Czas pracy", timeStr, "#FFFFFF"), statTile("Dystans GPS", String.format(Locale("pl", "PL"), "%.2f km", gpsKm), "#38B6FF")))
        container.addView(twoCols(statTile("Przyjęte kursy", "$acceptedCount ukoń.", "#3DDC84"), statTile("Średnio za km (GPS)", String.format(Locale("pl", "PL"), "%.2f zł/km", avgKm), "#3DDC84")))

        val bottomBtns = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                topMargin = dp(10)
            }
        }
        bottomBtns.addView(Button(this).apply {
            text = "Historia"
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            background = roundedBox("#0099FF", 24f)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { rightMargin = dp(8) }
            setOnClickListener { switchTab("historia") }
        })
        bottomBtns.addView(Button(this).apply {
            text = "Udostępnij"
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            background = roundedBox("#0C1626", 24f, "#3DD5B0")
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = dp(8) }
            setOnClickListener {
                val txt = String.format(Locale("pl", "PL"), "Podsumowanie sesji:\nPrzyjęte kursy: %d\nZarobek: %.2f zł\nPrzejechane km (GPS): %.2f km\nCzas: %s", acceptedCount, gross, gpsKm, timeStr)
                startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, txt) }, "Udostępnij"))
            }
        })
        container.addView(bottomBtns)

        scroll.addView(container)
        return scroll
    }

    private fun buildHistoryView(): View {
        val scroll = ScrollView(this)
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(16), dp(14), dp(28))
        }

        val list = RadarStorage.getHistory(this)
        val sdf = SimpleDateFormat("dd.MM HH:mm", Locale.getDefault())

        container.addView(TextView(this).apply {
            text = "Historia przejazdów i ofert (${list.size})"
            textSize = 18f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 0, 0, dp(12))
        })

        if (list.isEmpty()) {
            container.addView(TextView(this).apply {
                text = "Brak zapisanych kursów.\nKliknij ✓ lub ✕ na wyskakującym okienku podczas oferty albo wgraj plik CSV w zakładce 'CSV / Screen'."
                textSize = 14f
                setTextColor(Color.parseColor("#8A99B5"))
                setPadding(dp(8), dp(20), dp(8), dp(20))
            })
        }

        list.take(150).forEach { item ->
            val rateTrip = if (item.tripKm > 0) item.priceGross / item.tripKm else 0.0
            val rateTotal = if (item.totalKm > 0) item.priceGross / item.totalKm else rateTrip

            val isRejected = item.status == "REJECTED"
            val isCsv = item.source == "CSV"

            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                background = roundedBox("#101827", 24f, if (isRejected) "#5C2B38" else "#24344E")
                setPadding(dp(16), dp(16), dp(16), dp(16))
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                    bottomMargin = dp(12)
                }
            }

            val row1 = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            row1.addView(TextView(this).apply {
                val srcTag = if (isCsv) "CSV" else "Bolt"
                text = "Taxi • $srcTag • ${sdf.format(Date(item.timestamp))}"
                textSize = 13f
                setTextColor(Color.parseColor("#9BA9C2"))
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            })
            row1.addView(TextView(this).apply {
                text = when {
                    isRejected -> "✕ Odrzucony"
                    isCsv -> "✓ Zrealizowana (CSV)"
                    else -> "✓ Zaakceptowany"
                }
                textSize = 11f
                setTextColor(if (isRejected) Color.parseColor("#FF8A8A") else Color.parseColor("#4CE0B3"))
                background = roundedBox(if (isRejected) "#2B141C" else "#0E2923", 18f, if (isRejected) "#8E3B4E" else "#2E7D32")
                setPadding(dp(12), dp(4), dp(12), dp(4))
            })
            card.addView(row1)

            val row2 = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, dp(8), 0, dp(6))
            }
            row2.addView(TextView(this).apply {
                text = String.format(Locale("pl", "PL"), "%.2f zł", item.priceGross)
                textSize = 27f
                setTextColor(Color.WHITE)
                typeface = Typeface.DEFAULT_BOLD
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            })
            row2.addView(TextView(this).apply {
                text = String.format(Locale("pl", "PL"), "%.2f zł/km", rateTrip)
                textSize = 21f
                setTextColor(if (isRejected) Color.parseColor("#FF8A8A") else Color.parseColor("#3DDC84"))
                typeface = Typeface.DEFAULT_BOLD
            })
            card.addView(row2)

            val row3 = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            row3.addView(TextView(this).apply {
                text = if (item.pickupKm > 0.05) {
                    String.format(Locale("pl", "PL"), "Kurs: %.1f km (%.2f zł/km) • Z dojazdem: %.1f km (%.2f zł/km)", item.tripKm, rateTrip, item.totalKm, rateTotal)
                } else {
                    String.format(Locale("pl", "PL"), "Dystans łączny %.1f km • czas %d min", item.totalKm, item.offerMin)
                }
                textSize = 12f
                setTextColor(Color.parseColor("#6AB7FF"))
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            })
            row3.addView(Button(this).apply {
                text = "Usuń"
                textSize = 11f
                setTextColor(Color.parseColor("#FF8A8A"))
                background = roundedBox("#28151E", 16f, "#5C2B38")
                setPadding(dp(10), dp(2), dp(10), dp(2))
                setOnClickListener {
                    RadarStorage.deleteHistoryItem(this@MainActivity, item.id)
                    refreshCurrentTab()
                }
            })
            card.addView(row3)

            card.addView(TextView(this).apply {
                text = "Cel: ${item.destination}"
                textSize = 13f
                setTextColor(Color.parseColor("#8A99B5"))
                setPadding(0, dp(8), 0, 0)
            })

            container.addView(card)
        }

        scroll.addView(container)
        return scroll
    }

    private fun buildThresholdsView(): View {
        val scroll = ScrollView(this)
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(20), dp(16), dp(28))
        }

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = roundedBox("#101827", 24f, "#24344E")
            setPadding(dp(18), dp(18), dp(18), dp(18))
        }
        card.addView(TextView(this).apply {
            text = "Progi PRO – Kolory okienka"
            textSize = 19f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 0, 0, dp(8))
        })

        val inGreen = addInputField(card, "🟢 DOBRY (sam kurs) – Zielony od (zł/km):", RadarStorage.getGreenKmRate(this).toString())
        val inYellow = addInputField(card, "🟡 ŚREDNI (sam kurs) – Żółty od (zł/km):", RadarStorage.getYellowKmRate(this).toString())

        val inGreenPickup = addInputField(card, "🟢 DOBRY (z dojazdem) – Zielony od (zł/km):", RadarStorage.getGreenPickupKmRate(this).toString())
        val inYellowPickup = addInputField(card, "🟡 ŚREDNI (z dojazdem) – Żółty od (zł/km):", RadarStorage.getYellowPickupKmRate(this).toString())

        card.addView(Button(this).apply {
            text = "✓ Zapisz Progi PRO"
            setTextColor(Color.parseColor("#041E14"))
            typeface = Typeface.DEFAULT_BOLD
            background = roundedBox("#2CE574", 18f)
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(16) }
            setOnClickListener {
                RadarStorage.setGreenKmRate(this@MainActivity, inGreen.text.toString().replace(",", ".").toFloatOrNull() ?: 2.80f)
                RadarStorage.setYellowKmRate(this@MainActivity, inYellow.text.toString().replace(",", ".").toFloatOrNull() ?: 2.00f)
                RadarStorage.setGreenPickupKmRate(this@MainActivity, inGreenPickup.text.toString().replace(",", ".").toFloatOrNull() ?: 2.20f)
                RadarStorage.setYellowPickupKmRate(this@MainActivity, inYellowPickup.text.toString().replace(",", ".").toFloatOrNull() ?: 1.60f)
                Toast.makeText(this@MainActivity, "Zapisano progi!", Toast.LENGTH_SHORT).show()
            }
        })
        container.addView(card)
        scroll.addView(container)
        return scroll
    }

    private fun buildCsvAndScreensView(): View {
        val scroll = ScrollView(this)
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(20), dp(16), dp(28))
        }

        val csvCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = roundedBox("#101827", 24f, "#24344E")
            setPadding(dp(18), dp(18), dp(18), dp(18))
        }
        csvCard.addView(TextView(this).apply {
            text = "📄 Wgraj plik CSV z przejazdami (Faktury za przejazdy)"
            textSize = 18f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        })
        csvCard.addView(TextView(this).apply {
            text = "Importuje wszystkie kursy z pliku CSV Bolta bezpośrednio do zakładki Historia (bez duplikatów)."
            textSize = 13f
            setTextColor(Color.parseColor("#8A99B5"))
            setPadding(0, dp(6), 0, dp(12))
        })
        csvCard.addView(Button(this).apply {
            text = "📂 Wybierz plik CSV z telefonu"
            setTextColor(Color.parseColor("#041E14"))
            typeface = Typeface.DEFAULT_BOLD
            background = roundedBox("#65ECC5", 18f)
            setOnClickListener { pickCsvLauncher.launch("*/*") }
        })
        container.addView(csvCard)

        val scrCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = roundedBox("#101827", 24f, "#24344E")
            setPadding(dp(18), dp(18), dp(18), dp(18))
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(16) }
        }
        scrCard.addView(TextView(this).apply {
            text = "📷 Wgraj Screeny podsumowań Bolta (OCR)"
            textSize = 18f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        })
        scrCard.addView(TextView(this).apply {
            text = "Odczytuje kwoty zarobków, kampanii, napiwków oraz gotówki ze screenów dziennych/tygodniowych."
            textSize = 13f
            setTextColor(Color.parseColor("#8A99B5"))
            setPadding(0, dp(6), 0, dp(12))
        })
        scrCard.addView(Button(this).apply {
            text = "🖼️ Wybierz screeny z galerii"
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            background = roundedBox("#0099FF", 18f)
            setOnClickListener { pickScreensLauncher.launch("image/*") }
        })

        val summaries = RadarStorage.getScreenSummaries(this)
        summaries.forEach { s ->
            scrCard.addView(TextView(this).apply {
                text = String.format(Locale("pl", "PL"), "\n📅 %s • Saldo: %.2f zł | Kampanie: %.2f zł | Napiwki: %.2f zł | Gotówka: %.2f zł", s.dateKey, s.totalBolt, s.campaigns, s.tips, s.cash)
                textSize = 12f
                setTextColor(Color.parseColor("#80E8B6"))
            })
        }
        container.addView(scrCard)

        scroll.addView(container)
        return scroll
    }

    private fun buildSettingsView(): View {
        val scroll = ScrollView(this)
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(20), dp(16), dp(28))
        }

        val modeCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = roundedBox("#101827", 24f, "#24344E")
            setPadding(dp(18), dp(18), dp(18), dp(18))
        }
        modeCard.addView(TextView(this).apply {
            text = "Wygląd wyskakującego okienka"
            textSize = 18f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        })

        val chkDual = CheckBox(this).apply {
            text = "Pokazuj dwie kwoty obok siebie:\nLewa: zł/km za sam kurs | Prawa: zł/km z dojazdem"
            setTextColor(Color.WHITE)
            textSize = 14f
            isChecked = RadarStorage.isDualRateEnabled(this@MainActivity)
            setPadding(0, dp(10), 0, dp(12))
            setOnCheckedChangeListener { _, checked ->
                RadarStorage.setDualRateEnabled(this@MainActivity, checked)
                Toast.makeText(this@MainActivity, if (checked) "Włączono widok dwóch stawek obok siebie" else "Włączono widok jednej stawki", Toast.LENGTH_SHORT).show()
            }
        }
        modeCard.addView(chkDual)

        val currentScale = RadarStorage.getOverlayScale(this)
        modeCard.addView(TextView(this).apply {
            text = "Skalowanie wielkości okienka (aktualnie: ${(currentScale * 100).toInt()}%):"
            textSize = 14f
            setTextColor(Color.parseColor("#3DDC84"))
            setPadding(0, dp(4), 0, dp(10))
        })

        val scales = listOf(
            0.80f to "Małe (80%)",
            1.00f to "Standardowe (100%)",
            1.20f to "Powiększone (120%)",
            1.40f to "Duże (140%)"
        )
        scales.forEach { (sc, label) ->
            val sel = abs(currentScale - sc) < 0.05f
            modeCard.addView(Button(this).apply {
                text = if (sel) "✓ $label" else label
                setTextColor(if (sel) Color.parseColor("#041E14") else Color.WHITE)
                background = roundedBox(if (sel) "#2CE574" else "#1B2942", 16f, if (sel) "#2CE574" else "#32486E")
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(8) }
                setOnClickListener {
                    RadarStorage.setOverlayScale(this@MainActivity, sc)
                    refreshCurrentTab()
                }
            })
        }
        container.addView(modeCard)

        val permCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = roundedBox("#101827", 24f, "#24344E")
            setPadding(dp(18), dp(18), dp(18), dp(18))
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(16) }
        }
        permCard.addView(TextView(this).apply {
            text = "Uprawnienia (Nakładka, Odczyt ekranu, GPS)"
            textSize = 17f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 0, 0, dp(10))
        })
        permCard.addView(Button(this).apply {
            text = "1. Zezwól na wyświetlanie nad innymi aplikacjami"
            setTextColor(Color.WHITE)
            background = roundedBox("#1B2942", 16f, "#38B6FF")
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(8) }
            setOnClickListener {
                try {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                } catch (_: Exception) {}
            }
        })
        permCard.addView(Button(this).apply {
            text = "2. Włącz Usługę Odczytu Ekranu (Ułatwienia dostępu)"
            setTextColor(Color.WHITE)
            background = roundedBox("#1B2942", 16f, "#38B6FF")
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(8) }
            setOnClickListener {
                try {
                    startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                } catch (_: Exception) {}
            }
        })
        permCard.addView(Button(this).apply {
            text = "3. Zezwól na dostęp do GPS (Licznik km)"
            setTextColor(Color.WHITE)
            background = roundedBox("#1B2942", 16f, "#38B6FF")
            setOnClickListener {
                ActivityCompat.requestPermissions(this@MainActivity, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), 101)
            }
        })
        val btnBg = Button(this).apply {
            text = "Lokalizacja: ustaw Zawsze zezwalaj (potrzebne w tle)"
            setTextColor(Color.WHITE)
            background = roundedBox("#1B2942", 16f, "#38B6FF")
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(16) }
            setOnClickListener {
                try {
                    startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
                } catch (_: Exception) {}
            }
        }
        container.addView(permCard)
        container.addView(btnBg)
        val dbgCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = roundedBox("#101827", 24f, "#24344E")
            setPadding(dp(18), dp(18), dp(18), dp(18))
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(16) }
        }
        dbgCard.addView(TextView(this).apply {
            text = "Diagnostyka: ostatni tekst odczytany z ekranu"
            textSize = 15f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        })
        dbgCard.addView(TextView(this).apply {
            text = this@MainActivity.getSharedPreferences("KursRadarDebug", Context.MODE_PRIVATE).getString("last_text", "(jeszcze nic nie odczytano)") ?: ""
            textSize = 11f
            setTextColor(Color.parseColor("#8A99B5"))
            setTextIsSelectable(true)
        })
        container.addView(dbgCard)

        scroll.addView(container)
        return scroll
    }

    private fun handleCsvImport(uris: List<Uri>) {
        val imported = mutableListOf<RideEntry>()
        val sdf1 = SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.US)
        val sdf2 = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US)

        uris.forEach { uri ->
            try {
                contentResolver.openInputStream(uri)?.use { stream ->
                    val reader = BufferedReader(InputStreamReader(stream, Charsets.UTF_8))
                    val lines = reader.readLines()
                    if (lines.isEmpty()) return@use
                    val sep = if (lines[0].count { it == ';' } > lines[0].count { it == ',' }) ';' else ','

                    lines.drop(1).forEach { line ->
                        val cols = line.split(sep).map { it.trim().trim('"') }
                        if (cols.size >= 4) {
                            val id = cols[0].ifEmpty { UUID.randomUUID().toString() }
                            var ts = 0L
                            for (c in cols) {
                                ts = try { sdf1.parse(c)?.time ?: 0L } catch (_: Exception) { 0L }
                                if (ts == 0L) ts = try { sdf2.parse(c.replace("T", " "))?.time ?: 0L } catch (_: Exception) { 0L }
                                if (ts > 0L) break
                            }
                            val gross = cols.last().replace(" ", "").replace(",", ".").toDoubleOrNull() ?: 0.0
                            if (ts > 0L && gross > 0.0) {
                                imported.add(
                                    RideEntry(
                                        id = id,
                                        timestamp = ts,
                                        priceGross = gross,
                                        tripKm = max(1.0, gross / 3.2),
                                        pickupKm = 0.0,
                                        offerMin = 12,
                                        status = "ACCEPTED",
                                        destination = "Import CSV",
                                        source = "CSV"
                                    )
                                )
                            }
                        }
                    }
                }
            } catch (_: Exception) {}
        }

        val addedCount = RadarStorage.importCsvTrips(this, imported)
        Toast.makeText(this, "Zaimportowano $addedCount kursów z pliku CSV!", Toast.LENGTH_LONG).show()
        switchTab("historia")
    }

    private fun handleScreenshotsOcr(uris: List<Uri>) {
        val rec = getOrCreateRecognizer() ?: return
        var done = 0
        uris.forEach { uri ->
            try {
                val img = InputImage.fromFilePath(this, uri)
                rec.process(img).addOnSuccessListener { vision ->
                    val txt = vision.text
                    val amtRegex = Regex("""(\d+[.,]\d{2})""")
                    var bolt = 0.0
                    var camp = 0.0
                    var tips = 0.0
                    var cash = 0.0
                    txt.lines().forEach { l ->
                        val low = l.lowercase(Locale.getDefault())
                        val num = amtRegex.findAll(l).lastOrNull()?.value?.replace(",", ".")?.toDoubleOrNull()
                        if (num != null) {
                            when {
                                low.contains("zarobki") -> bolt = num
                                low.contains("kampan") || low.contains("bonus") -> camp += num
                                low.contains("napiw") -> tips = num
                                low.contains("got") -> cash = num
                            }
                        }
                    }
                    val dateKey = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
                    RadarStorage.addScreenSummary(this, ScreenSummaryEntry(dateKey, bolt, camp, tips, cash))
                    done++
                    if (done == uris.size) {
                        Toast.makeText(this, "Odczytano $done screen(y)!", Toast.LENGTH_SHORT).show()
                        refreshCurrentTab()
                    }
                }
            } catch (_: Exception) { done++ }
        }
    }

    private fun twoCols(left: View, right: View): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(12) }
            left.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { rightMargin = dp(6) }
            right.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = dp(6) }
            addView(left)
            addView(right)
        }
    }

    private fun statTile(label: String, value: String, colorHex: String): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = roundedBox("#101929", 22f, "#22324C")
            setPadding(dp(16), dp(16), dp(16), dp(16))
            addView(TextView(this@MainActivity).apply { text = label; textSize = 13f; setTextColor(Color.parseColor("#99AABB")) })
            addView(TextView(this@MainActivity).apply {
                text = value; textSize = 21f; setTextColor(Color.parseColor(colorHex)); typeface = Typeface.DEFAULT_BOLD; setPadding(0, dp(6), 0, 0)
            })
        }
    }

    private fun addInputField(parent: LinearLayout, label: String, initVal: String): EditText {
        parent.addView(TextView(this).apply { text = label; textSize = 13f; setTextColor(Color.parseColor("#99AABB")); setPadding(0, dp(10), 0, dp(4)) })
        val et = EditText(this).apply {
            setText(initVal); setTextColor(Color.WHITE); inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            background = roundedBox("#162338", 14f, "#32486E"); setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        parent.addView(et)
        return et
    }

    private fun roundedBox(fillHex: String, radiusDp: Float, strokeHex: String? = null): GradientDrawable {
        return GradientDrawable().apply {
            setColor(Color.parseColor(fillHex))
            cornerRadius = dp(radiusDp.toInt()).toFloat()
            if (strokeHex != null) setStroke(dp(1), Color.parseColor(strokeHex))
        }
    }

    private fun dp(v: Int): Int = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics).toInt()
}
