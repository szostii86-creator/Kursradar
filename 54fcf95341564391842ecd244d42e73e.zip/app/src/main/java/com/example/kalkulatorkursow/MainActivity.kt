package com.example.kalkulatorkursow

import android.Manifest
import android.annotation.SuppressLint
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import java.io.File
import java.io.FileOutputStream
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import java.math.BigDecimal
import java.math.RoundingMode
import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.UUID
import kotlin.math.abs

object OfferStatus {
    const val DETECTED = "DETECTED"
    const val UNDECIDED = "UNDECIDED"
    const val ACCEPTED = "ACCEPTED"
    const val REJECTED = "REJECTED"
    const val REVIEW = "REVIEW"

    fun normalize(raw: String?): String {
        return when (raw?.trim()?.uppercase(Locale.US)) {
            "ACCEPTED", "PRZYJĘTY", "PRZYJETY", "PRZYJĘTA", "PRZYJETA", "ZAAKCEPTOWANY" -> ACCEPTED
            "REJECTED", "ODRZUCONY", "ODRZUCONA" -> REJECTED
            "REVIEW", "DO OCENY" -> REVIEW
            "UNDECIDED", "BEZ DECYZJI" -> UNDECIDED
            "DETECTED", "WYKRYTY", "WYKRYTA", "" -> UNDECIDED
            else -> UNDECIDED
        }
    }

    fun labelPl(status: String, source: String = "RADAR"): String {
        val norm = normalize(status)
        if (norm == REVIEW || source == "SCREEN") return "Ze screena — do oceny"
        return when (norm) {
            ACCEPTED -> "Zaakceptowany"
            REJECTED -> "Odrzucony"
            UNDECIDED -> "Bez decyzji"
            else -> "Bez decyzji"
        }
    }
}

fun plnToGrosze(amount: Double): Long {
    if (!amount.isFinite() || amount <= 0.0) return 0L
    return BigDecimal.valueOf(amount)
        .setScale(2, RoundingMode.HALF_UP)
        .movePointRight(2)
        .longValueExact()
}

fun groszeToPln(grosze: Long): Double {
    return BigDecimal.valueOf(grosze, 2).toDouble()
}

data class RideEntry(
    val id: String,
    val timestamp: Long,               // czas wykrycia oferty (ms)
    val acceptedTimestamp: Long = 0L,  // czas przyjęcia kursu (ms, 0 gdy brak)
    val priceGrosze: Long,             // kwota w groszach
    val tripKm: Double,
    val pickupKm: Double,
    val offerMin: Int,
    val status: String,
    val destination: String,
    val pickupAddress: String = "",
    val rateCourse: Double = 0.0,
    val rateWithPickup: Double = 0.0,
    val source: String = "RADAR"
) {
    val priceGross: Double get() = groszeToPln(priceGrosze)
    val totalKm: Double get() = tripKm + pickupKm
    val normalizedStatus: String get() = OfferStatus.normalize(status)

    val effectiveTimestamp: Long
        get() = if (normalizedStatus == OfferStatus.ACCEPTED && source != "SCREEN" && acceptedTimestamp > 0L) {
            acceptedTimestamp
        } else {
            timestamp
        }
}

data class HistorySummary(
    val totalFilteredCount: Int,
    val acceptedCount: Int,
    val acceptedSumGrosze: Long
) {
    val acceptedSumPln: Double get() = groszeToPln(acceptedSumGrosze)
}

object RadarStorage {
    private const val PREFS = "KursRadarPrefsV3"
    private const val SUPPRESSED_PREFS = "KursRadarSuppressedV1"
    private fun p(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    private fun sp(ctx: Context) = ctx.getSharedPreferences(SUPPRESSED_PREFS, Context.MODE_PRIVATE)

    fun isSessionRunning(ctx: Context): Boolean = p(ctx).getBoolean("session_running", false)
    fun setSessionRunning(ctx: Context, running: Boolean) = p(ctx).edit().putBoolean("session_running", running).apply()

    fun getSessionStartTime(ctx: Context): Long = p(ctx).getLong("session_start_ms", 0L)
    fun setSessionStartTime(ctx: Context, ms: Long) = p(ctx).edit().putLong("session_start_ms", ms).apply()

    fun getSessionStopTime(ctx: Context): Long = p(ctx).getLong("session_stop_ms", 0L)
    fun setSessionStopTime(ctx: Context, ms: Long) = p(ctx).edit().putLong("session_stop_ms", ms).apply()

    fun getGpsDistanceMeters(ctx: Context): Float = p(ctx).getFloat("gps_distance_m", 0f)
    fun setGpsDistanceMeters(ctx: Context, meters: Float) = p(ctx).edit().putFloat("gps_distance_m", meters).apply()
    fun addGpsDistanceMeters(ctx: Context, deltaMeters: Float) {
        setGpsDistanceMeters(ctx, getGpsDistanceMeters(ctx) + deltaMeters)
    }

    fun getSessionAcceptedCount(ctx: Context): Int = p(ctx).getInt("session_acc_count", 0)
    fun setSessionAcceptedCount(ctx: Context, count: Int) = p(ctx).edit().putInt("session_acc_count", count).apply()

    fun getSessionGrossTotal(ctx: Context): Float = p(ctx).getFloat("session_gross_total", 0f)
    fun setSessionGrossTotal(ctx: Context, total: Float) = p(ctx).edit().putFloat("session_gross_total", total).apply()

    fun isDualRateEnabled(ctx: Context): Boolean = p(ctx).getBoolean("dual_rate_enabled", true)
    fun setDualRateEnabled(ctx: Context, enabled: Boolean) = p(ctx).edit().putBoolean("dual_rate_enabled", enabled).apply()

    fun getOverlayScale(ctx: Context): Float = p(ctx).getFloat("overlay_scale", 1.0f)
    fun setOverlayScale(ctx: Context, scale: Float) = p(ctx).edit().putFloat("overlay_scale", scale).apply()

    fun getGreenKmRate(ctx: Context): Float = p(ctx).getFloat("green_km_rate", 3.00f)
    fun setGreenKmRate(ctx: Context, v: Float) = p(ctx).edit().putFloat("green_km_rate", v).apply()

    fun getYellowKmRate(ctx: Context): Float = p(ctx).getFloat("yellow_km_rate", 2.40f)
    fun setYellowKmRate(ctx: Context, v: Float) = p(ctx).edit().putFloat("yellow_km_rate", v).apply()

    fun getPickupGreenKmRate(ctx: Context): Float =
        p(ctx).getFloat("pickup_green_km_rate", 2.50f)

    fun getPickupYellowKmRate(ctx: Context): Float =
        p(ctx).getFloat("pickup_yellow_km_rate", 2.00f)

    fun saveRateThresholds(
        ctx: Context,
        tripGreen: Float,
        tripYellow: Float,
        pickupGreen: Float,
        pickupYellow: Float
    ) {
        p(ctx).edit()
            .putFloat("green_km_rate", tripGreen)
            .putFloat("yellow_km_rate", tripYellow)
            .putFloat("pickup_green_km_rate", pickupGreen)
            .putFloat("pickup_yellow_km_rate", pickupYellow)
            .apply()
    }

    fun suppressOfferSignature(ctx: Context, signature: String) {
        if (signature.isBlank()) return
        sp(ctx).edit()
            .putString("sig", signature)
            .putLong("ts", System.currentTimeMillis())
            .apply()
    }

    fun isOfferSignatureSuppressed(ctx: Context, signature: String): Boolean {
        if (signature.isBlank()) return false
        val savedSig = sp(ctx).getString("sig", "") ?: ""
        val savedTs = sp(ctx).getLong("ts", 0L)
        return savedSig == signature && System.currentTimeMillis() - savedTs < 180_000L
    }

    @Synchronized
    fun getHistory(ctx: Context): MutableList<RideEntry> {
        val raw = p(ctx).getString("history_json", "[]") ?: "[]"
        val list = mutableListOf<RideEntry>()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val src = o.optString("src", "RADAR")
                val statusNorm = if (src == "SCREEN") {
                    OfferStatus.REVIEW
                } else {
                    OfferStatus.normalize(o.optString("status", OfferStatus.UNDECIDED))
                }
                val ts = o.optLong("t", 0L)
                var accTs = o.optLong("acc_t", 0L)
                if (statusNorm == OfferStatus.ACCEPTED && accTs <= 0L && ts > 0L) {
                    accTs = ts
                }
                val grosze = if (o.has("price_grosze")) {
                    o.optLong("price_grosze", 0L)
                } else {
                    plnToGrosze(o.optDouble("price", 0.0))
                }
                val pricePln = groszeToPln(grosze)
                val tkm = o.optDouble("tkm", 0.0)
                val pkm = o.optDouble("pkm", 0.0)
                val savedRateC = o.optDouble("rate_c", 0.0)
                val savedRateP = o.optDouble("rate_p", 0.0)
                val computedRateC = if (savedRateC > 0.0) savedRateC else if (tkm > 0.0) pricePln / tkm else 0.0
                val computedRateP = if (savedRateP > 0.0) savedRateP else if (pkm > 0.0 && (tkm + pkm) > 0.0) pricePln / (tkm + pkm) else 0.0

                list.add(
                    RideEntry(
                        id = o.optString("id").ifEmpty { UUID.randomUUID().toString() },
                        timestamp = ts,
                        acceptedTimestamp = accTs,
                        priceGrosze = grosze,
                        tripKm = tkm,
                        pickupKm = pkm,
                        offerMin = o.optInt("min", 1),
                        status = statusNorm,
                        destination = o.optString("dest", "Kraków"),
                        pickupAddress = o.optString("pickup_addr", ""),
                        rateCourse = computedRateC,
                        rateWithPickup = computedRateP,
                        source = src
                    )
                )
            }
        } catch (_: Exception) {}
        list.sortByDescending { it.effectiveTimestamp }
        return list
    }

    @Synchronized
    fun saveHistory(ctx: Context, list: List<RideEntry>) {
        val arr = JSONArray()
        list.forEach { r ->
            val o = JSONObject()
            o.put("id", r.id)
            o.put("t", r.timestamp)
            o.put("acc_t", r.acceptedTimestamp)
            o.put("price_grosze", r.priceGrosze)
            o.put("price", r.priceGross)
            o.put("tkm", r.tripKm)
            o.put("pkm", r.pickupKm)
            o.put("min", r.offerMin)
            o.put("status", OfferStatus.normalize(r.status))
            o.put("dest", r.destination)
            o.put("pickup_addr", r.pickupAddress)
            o.put("rate_c", r.rateCourse)
            o.put("rate_p", r.rateWithPickup)
            o.put("src", r.source)
            arr.put(o)
        }
        p(ctx).edit().putString("history_json", arr.toString()).commit()
    }

    @Synchronized
    fun recordDecision(ctx: Context, entry: RideEntry) {
        if (RadarOptions.historyEnabled(ctx)) {
            val list = getHistory(ctx)
            val idx = list.indexOfFirst { it.id == entry.id }
            if (idx >= 0) {
                list[idx] = entry
            } else {
                list.add(0, entry)
            }
            saveHistory(ctx, list)
        }

        if (
            entry.normalizedStatus == OfferStatus.ACCEPTED &&
            entry.source != "SCREEN" &&
            isSessionRunning(ctx)
        ) {
            setSessionAcceptedCount(
                ctx,
                getSessionAcceptedCount(ctx) + 1
            )

            setSessionGrossTotal(
                ctx,
                getSessionGrossTotal(ctx) + entry.priceGross.toFloat()
            )
        }
    }

    @Synchronized
    fun upsertOffer(
        ctx: Context,
        entry: RideEntry,
        alreadyCountedInSession: Boolean = false,
        previousCountedGrosze: Long = 0L
    ): Pair<RideEntry, Boolean> {
        val isScreen = entry.source == "SCREEN"
        val normalizedIncoming = if (isScreen) OfferStatus.REVIEW else OfferStatus.normalize(entry.status)

        val list = getHistory(ctx)
        val idx = list.indexOfFirst { it.id == entry.id }
        val old = if (idx >= 0) list[idx] else null
        val oldStatus = old?.normalizedStatus

        val finalStatus = when {
            isScreen -> OfferStatus.REVIEW
            oldStatus == OfferStatus.ACCEPTED -> OfferStatus.ACCEPTED
            normalizedIncoming == OfferStatus.ACCEPTED -> OfferStatus.ACCEPTED
            oldStatus == OfferStatus.REJECTED && normalizedIncoming == OfferStatus.UNDECIDED -> OfferStatus.REJECTED
            else -> normalizedIncoming
        }

        val finalAcceptedTs = when {
            finalStatus == OfferStatus.ACCEPTED && !isScreen && old != null && old.acceptedTimestamp > 0L -> old.acceptedTimestamp
            finalStatus == OfferStatus.ACCEPTED && !isScreen && entry.acceptedTimestamp > 0L -> entry.acceptedTimestamp
            finalStatus == OfferStatus.ACCEPTED && !isScreen -> System.currentTimeMillis()
            else -> 0L
        }

        val finalPickupKm = if (entry.pickupKm > 0.0) entry.pickupKm else (old?.pickupKm ?: 0.0)
        val finalTripKm = if (entry.tripKm > 0.0) entry.tripKm else (old?.tripKm ?: 0.0)
        val finalGrosze = if (entry.priceGrosze > 0L) entry.priceGrosze else (old?.priceGrosze ?: 0L)
        val finalPricePln = groszeToPln(finalGrosze)
        val finalDest = if (entry.destination.isNotBlank() && entry.destination != "Kraków") {
            entry.destination
        } else {
            old?.destination ?: entry.destination.ifBlank { "Kraków" }
        }
        val finalPickupAddr = if (entry.pickupAddress.isNotBlank()) {
            entry.pickupAddress
        } else {
            old?.pickupAddress ?: ""
        }

        val rateC = if (finalTripKm > 0.0) finalPricePln / finalTripKm else 0.0
        val rateP = if (finalPickupKm > 0.0 && (finalTripKm + finalPickupKm) > 0.0) {
            finalPricePln / (finalTripKm + finalPickupKm)
        } else {
            0.0
        }

        val resultEntry = RideEntry(
            id = entry.id,
            timestamp = if (old != null && old.timestamp > 0L) old.timestamp else entry.timestamp,
            acceptedTimestamp = finalAcceptedTs,
            priceGrosze = finalGrosze,
            tripKm = finalTripKm,
            pickupKm = finalPickupKm,
            offerMin = if (entry.offerMin > 0) entry.offerMin else (old?.offerMin ?: 1),
            status = finalStatus,
            destination = finalDest,
            pickupAddress = finalPickupAddr,
            rateCourse = rateC,
            rateWithPickup = rateP,
            source = entry.source
        )

        if (RadarOptions.historyEnabled(ctx)) {
            if (idx >= 0) {
                list[idx] = resultEntry
            } else {
                list.add(0, resultEntry)
            }
            saveHistory(ctx, list)
        }

        var nowCounted = alreadyCountedInSession
        if (finalStatus == OfferStatus.ACCEPTED && !isScreen && isSessionRunning(ctx)) {
            if (!alreadyCountedInSession) {
                setSessionAcceptedCount(ctx, getSessionAcceptedCount(ctx) + 1)
                setSessionGrossTotal(ctx, getSessionGrossTotal(ctx) + resultEntry.priceGross.toFloat())
                nowCounted = true
            } else if (previousCountedGrosze != resultEntry.priceGrosze) {
                val diffPln = groszeToPln(resultEntry.priceGrosze - previousCountedGrosze).toFloat()
                setSessionGrossTotal(ctx, (getSessionGrossTotal(ctx) + diffPln).coerceAtLeast(0f))
            }
        }

        return Pair(resultEntry, nowCounted)
    }

    @Synchronized
    fun deleteHistoryItem(ctx: Context, id: String) {
        val list = getHistory(ctx).filterNot { it.id == id }
        saveHistory(ctx, list)
    }

    fun isInRange(entry: RideEntry, fromInclusive: Long?, toExclusive: Long?): Boolean {
        val t = entry.effectiveTimestamp
        if (fromInclusive != null && t < fromInclusive) return false
        if (toExclusive != null && t >= toExclusive) return false
        return true
    }

    fun filterHistory(ctx: Context, fromInclusive: Long?, toExclusive: Long?): List<RideEntry> {
        return getHistory(ctx).filter { isInRange(it, fromInclusive, toExclusive) }
    }

    fun calculateSummary(entries: List<RideEntry>): HistorySummary {
        var acceptedCount = 0
        var sumGrosze = 0L
        for (item in entries) {
            if (item.normalizedStatus == OfferStatus.ACCEPTED && item.source != "SCREEN" && item.priceGrosze > 0L) {
                acceptedCount++
                sumGrosze += item.priceGrosze
            }
        }
        return HistorySummary(
            totalFilteredCount = entries.size,
            acceptedCount = acceptedCount,
            acceptedSumGrosze = sumGrosze
        )
    }

    @Synchronized
    fun deleteHistoryInRange(ctx: Context, fromInclusive: Long, toExclusive: Long): Int {
        val all = getHistory(ctx)
        val remaining = ArrayList<RideEntry>(all.size)
        var deletedCount = 0
        for (item in all) {
            if (isInRange(item, fromInclusive, toExclusive)) {
                deletedCount++
            } else {
                remaining.add(item)
            }
        }
        if (deletedCount > 0) {
            saveHistory(ctx, remaining)
        }
        return deletedCount
    }

    @Synchronized
    fun clearAllHistory(ctx: Context): Int {
        val count = getHistory(ctx).size
        saveHistory(ctx, emptyList())
        return count
    }
}

class MainActivity : AppCompatActivity(), LocationListener {

    private lateinit var contentFrame: FrameLayout
    private lateinit var bottomNav: LinearLayout
    private var currentTab = "start"

    private var locationManager: LocationManager? = null
    private var lastLocation: Location? = null
    private val uiHandler = Handler(Looper.getMainLooper())

    private var paySelectedDateKey: String = OfflineAnalytics.dayKeyFromMillis(System.currentTimeMillis())
    private val mainHandler = Handler(Looper.getMainLooper())
    private var filterFromCal: Calendar? = null
    private var filterToCal: Calendar? = null

    // Zakres statystyk / rozliczeń (domyślnie bieżący okres partnera 14 dni lub bieżący tydzień)
    private var statsFromKey: String = OfflineAnalytics.mondayKeyForMillis(System.currentTimeMillis())
    private var statsToKey: String = OfflineAnalytics.addDaysToKey(statsFromKey, 13)
    private var paySourceMode: String = "stats" // "stats" | "week"

    private var summaryRecognizer: TextRecognizer? = null
    private var pendingSummaryDrafts: MutableList<OfflineAnalytics.ParsedBoltSummaryDraft> = mutableListOf()
    private var lastSummaryRawText: String = ""

    private fun getSummaryRecognizer(): TextRecognizer? {
        if (summaryRecognizer == null) {
            summaryRecognizer = try {
                TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
            } catch (_: Exception) {
                null
            }
        }
        return summaryRecognizer
    }

    private val pickSummaryScreensLauncher = registerForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        if (uris.isNotEmpty()) {
            runOfflineSummaryScreenshotsOcr(uris)
        }
    }

    private var webFilePathCallback: ValueCallback<Array<Uri>>? = null
    private var activeWebView: WebView? = null
    private var pendingBackupContent: String? = null
    private var pendingBackupFileName: String = "scanbolt-kopia.json"

    private val createBackupDocLauncher = registerForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        val content = pendingBackupContent
        val fallbackName = pendingBackupFileName
        pendingBackupContent = null
        if (uri == null || content == null) return@registerForActivityResult
        try {
            contentResolver.openOutputStream(uri)?.use { out ->
                out.write(content.toByteArray(Charsets.UTF_8))
                out.flush()
            }
            Toast.makeText(
                this,
                "Zapisano kopię w wybranym miejscu ($fallbackName).",
                Toast.LENGTH_LONG
            ).show()
        } catch (e: Exception) {
            Toast.makeText(
                this,
                "Nie udało się zapisać kopii: ${e.message}",
                Toast.LENGTH_LONG
            ).show()
        }
    }


    private val pickWebFileLauncher = registerForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        val cb = webFilePathCallback
        webFilePathCallback = null
        if (cb != null) {
            cb.onReceiveValue(if (uris.isNotEmpty()) uris.toTypedArray() else null)
        }
    }

    private val tickerRunnable = object : Runnable {
        override fun run() {
            if (RadarStorage.isSessionRunning(this@MainActivity) && currentTab == "start") {
                refreshCurrentTab()
            }
            uiHandler.postDelayed(this, 1000L)
        }
    }

    private val pickCsvLauncher = registerForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        if (uris.isNotEmpty()) {
            val added = OfflineAnalytics.importCsvFilesOffline(this, uris)
            Toast.makeText(this, "Zaimportowano kursów (CSV offline): $added", Toast.LENGTH_LONG).show()
            if (currentTab == "rozliczenia") refreshCurrentTab()
        }
    }

    private val exportBackupLauncher = registerForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) {
            try {
                contentResolver.openOutputStream(uri)?.use { out ->
                    val ok = OfflineAnalytics.exportBackupJson(this, out)
                    Toast.makeText(
                        this,
                        if (ok) "Zapisano kopię zapasową JSON (offline)." else "Nie udało się zapisać kopii.",
                        Toast.LENGTH_LONG
                    ).show()
                }
            } catch (e: Exception) {
                Toast.makeText(this, "Błąd eksportu: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private val importBackupLauncher = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            val (ok, msg) = OfflineAnalytics.importBackupJson(this, uri)
            Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
            if (ok) refreshCurrentTab()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val crashFile = java.io.File(filesDir, "crash.txt")
        if (crashFile.exists()) {
            val tv = TextView(this).apply {
                text = crashFile.readText()
                setTextIsSelectable(true)
                setPadding(24, 24, 24, 24)
            }
            setContentView(ScrollView(this).apply { addView(tv) })
            crashFile.delete()
            return
        }
        try {
            locationManager = getSystemService(Context.LOCATION_SERVICE) as? LocationManager

            val root = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setBackgroundColor(Color.parseColor("#080E1A"))
                layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            }

            contentFrame = FrameLayout(this).apply {
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
            }

            bottomNav = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                background = roundedBox("#0D1526", 28f, "#1E2D4A")
                setPadding(dp(6), dp(10), dp(6), dp(10))
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                    setMargins(dp(10), dp(4), dp(10), dp(12))
                }
            }

            root.addView(contentFrame)
            root.addView(bottomNav)
            setContentView(root)

            switchTab("start")
            if (RadarStorage.isSessionRunning(this)) startGps()
        } catch (e: Exception) {
            Toast.makeText(this, "Błąd startu: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    override fun onResume() {
        super.onResume()
        try {
            uiHandler.removeCallbacks(tickerRunnable)
            uiHandler.post(tickerRunnable)
            if (::contentFrame.isInitialized) refreshCurrentTab()
        } catch (_: Exception) {}
    }

    override fun onPause() {
        super.onPause()
        uiHandler.removeCallbacks(tickerRunnable)
    }

    override fun onDestroy() {
        super.onDestroy()
        uiHandler.removeCallbacks(tickerRunnable)
        stopGps()
        try { activeWebView?.destroy(); activeWebView = null } catch (_: Exception) {}
        try { summaryRecognizer?.close() } catch (_: Exception) {}
    }

    private fun startGps() {
        try {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), 101)
                return
            }
            lastLocation = null
            if (locationManager?.isProviderEnabled(LocationManager.GPS_PROVIDER) == true) {
                locationManager?.requestLocationUpdates(LocationManager.GPS_PROVIDER, 2000L, 4f, this)
            }
            if (locationManager?.isProviderEnabled(LocationManager.NETWORK_PROVIDER) == true) {
                locationManager?.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 3000L, 8f, this)
            }
        } catch (_: Exception) {}
    }

    private fun stopGps() {
        try {
            locationManager?.removeUpdates(this)
            lastLocation = null
        } catch (_: Exception) {}
    }

    override fun onLocationChanged(location: Location) {
        if (!RadarStorage.isSessionRunning(this)) return
        val prev = lastLocation
        if (prev != null) {
            val delta = prev.distanceTo(location)
            if (delta in 3.0f..500.0f) {
                // licznik km działa w usłudze (RideScannerService)
            }
        }
        lastLocation = location
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 101 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            if (RadarStorage.isSessionRunning(this)) startGps()
        }
    }

    private fun switchTab(tab: String) {
        val showSettlements = RadarOptions.settlementsTabEnabled(this)
        val targetTab = if (tab == "rozliczenia" && !showSettlements) "start" else tab
        currentTab = targetTab
        val tabs = buildList {
            add("start" to "⚡\nStart")
            add("historia" to "🕒\nHistoria")
            if (showSettlements) {
                add("rozliczenia" to "💰\nRozliczenia")
            }
            add("progi" to "☰\nProgi PRO")
            add("ustawienia" to "⚙️\nUstawienia")
        }
        bottomNav.removeAllViews()
        tabs.forEach { (key, label) ->
            val active = currentTab == key
            bottomNav.addView(TextView(this).apply {
                text = label
                gravity = Gravity.CENTER
                textSize = 10.5f
                setTextColor(if (active) Color.parseColor("#38B6FF") else Color.parseColor("#8A99B5"))
                typeface = if (active) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                setOnClickListener { switchTab(key) }
            })
        }
        refreshCurrentTab()
    }

    private fun refreshCurrentTab() {
        if (!::contentFrame.isInitialized) return
        contentFrame.removeAllViews()
        if (currentTab != "rozliczenia" && activeWebView != null) {
            try { activeWebView?.destroy(); activeWebView = null } catch (_: Exception) {}
        }
        val view = when (currentTab) {
            "start" -> buildStartAndStatsView()
            "historia" -> buildHistoryView()
            "rozliczenia" -> buildHtmlSettlementsWebView()
            "progi" -> buildThresholdsView()
            else -> buildSettingsView()
        }
        contentFrame.addView(view)
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun buildHtmlSettlementsWebView(): View {
        val wrapper = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#0B1423"))
            layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        }

        val infoBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Color.parseColor("#101A30"))
            setPadding(dp(12), dp(6), dp(12), dp(6))
        }
        infoBar.addView(TextView(this).apply {
            text = "Rozliczenia (moduł HTML w aplikacji • bez Chrome)"
            textSize = 11.5f
            setTextColor(Color.parseColor("#65ECC5"))
            typeface = Typeface.DEFAULT_BOLD
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        })
        infoBar.addView(Button(this).apply {
            text = "Odśwież"
            textSize = 11f
            setTextColor(Color.WHITE)
            background = roundedBox("#17263B", 12f, "#65ECC5")
            setPadding(dp(10), dp(2), dp(10), dp(2))
            setOnClickListener { activeWebView?.reload() }
        })
        wrapper.addView(infoBar)

        val wv = WebView(this).apply {
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
            setBackgroundColor(Color.parseColor("#0B1423"))
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                databaseEnabled = true
                allowFileAccess = true
                allowContentAccess = true
                @Suppress("DEPRECATION")
                allowFileAccessFromFileURLs = true
                @Suppress("DEPRECATION")
                allowUniversalAccessFromFileURLs = true
                mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                useWideViewPort = true
                loadWithOverviewMode = true
                builtInZoomControls = false
                displayZoomControls = false
            }
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
                    if (url != null && (url.startsWith("file:///android_asset/") || url.startsWith("data:") || url.startsWith("blob:"))) {
                        return false
                    }
                    return false
                }
                override fun onPageFinished(view: WebView?, url: String?) {
                    super.onPageFinished(view, url)
                    val jsCode = """
                        (function() {
                            if (window.__scanBoltBackupHookV2) return;
                            window.__scanBoltBackupHookV2 = true;
                            function readBlobSync(blobUrl) {
                                try {
                                    const xhr = new XMLHttpRequest();
                                    xhr.open('GET', blobUrl, false);
                                    xhr.send(null);
                                    if (xhr.status === 200 || xhr.status === 0) {
                                        return xhr.responseText || '';
                                    }
                                } catch (e) {}
                                return '';
                            }
                            const origAnchorClick = HTMLAnchorElement.prototype.click;
                            HTMLAnchorElement.prototype.click = function() {
                                try {
                                    const href = this.getAttribute('href') || this.href || '';
                                    if (href.startsWith('blob:') && window.ScanBoltBackupBridge && window.ScanBoltBackupBridge.saveTextFile) {
                                        const dlName = this.getAttribute('download') || this.download || 'scanbolt-kopia.json';
                                        const txt = readBlobSync(href);
                                        window.ScanBoltBackupBridge.saveTextFile(dlName, txt);
                                        return;
                                    }
                                } catch (e) {}
                                return origAnchorClick.apply(this, arguments);
                            };
                        })();
                    """.trimIndent()
                    view?.evaluateJavascript(jsCode, null)
                }
            }
        addJavascriptInterface(object {
            @android.webkit.JavascriptInterface
            fun saveTextFile(fileName: String, textContent: String) {
                runOnUiThread {
                    saveBackupTextOffline(fileName, textContent)
                }
            }
        }, "ScanBoltBackupBridge")
            webChromeClient = object : WebChromeClient() {
                override fun onShowFileChooser(
                    webView: WebView?,
                    filePathCallback: ValueCallback<Array<Uri>>?,
                    fileChooserParams: FileChooserParams?
                ): Boolean {
                    webFilePathCallback?.onReceiveValue(null)
                    webFilePathCallback = filePathCallback
                    val acceptTypes = fileChooserParams?.acceptTypes ?: emptyArray()
                    val mime = when {
                        acceptTypes.any { it.contains("image") } -> "image/*"
                        acceptTypes.any { it.contains("json") } -> "application/json"
                        else -> "*/*"
                    }
                    return try {
                        pickWebFileLauncher.launch(mime)
                        true
                    } catch (_: Exception) {
                        webFilePathCallback = null
                        false
                    }
                }
            }
            setDownloadListener { url, _, contentDisposition, mimeType, _ ->
                try {
                    val fileName = if (!contentDisposition.isNullOrBlank() && contentDisposition.contains("filename=")) {
                        contentDisposition.substringAfter("filename=").trim().trim('"').ifEmpty { "kursradar-kopia.json" }
                    } else {
                        "kursradar-kopia.json"
                    }
                    val dlDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                    val targetDir = File(dlDir, "KursRadar").apply { mkdirs() }
                    val outFile = File(targetDir, fileName)

                    if (url.startsWith("data:")) {
                        val base64Part = url.substringAfter("base64,", "")
                        if (base64Part.isNotEmpty()) {
                            val bytes = android.util.Base64.decode(base64Part, android.util.Base64.DEFAULT)
                            FileOutputStream(outFile).use { it.write(bytes) }
                            Toast.makeText(this@MainActivity, "Zapisano do Pobrane/KursRadar/$fileName", Toast.LENGTH_LONG).show()
                        }
                    } else if (url.startsWith("blob:")) {
                        activeWebView?.evaluateJavascript(
                            """(function(){
                                const links = Array.from(document.querySelectorAll('a[href^="blob:"]'));
                                const target = links.find(a => a.href === '$url') || links[links.length - 1];
                                const dlName = (target && target.getAttribute('download')) || '$fileName';
                                if (!target) { window.ScanBoltBackupBridge.saveTextFile(dlName, ''); return; }
                                fetch(target.href).then(r => r.text()).then(t => {
                                    window.ScanBoltBackupBridge.saveTextFile(dlName, t);
                                }).catch(() => {
                                    window.ScanBoltBackupBridge.saveTextFile(dlName, '');
                                });
                            })();""",
                            null
                        )
                    } else {
                        try {
                            val i = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                            if (i.resolveActivity(packageManager) != null) {
                                startActivity(i)
                            } else {
                                saveBackupTextOffline(fileName, url)
                            }
                        } catch (_: Exception) {
                            saveBackupTextOffline(fileName, url)
                        }
                    }
                } catch (e: Exception) {
                    Toast.makeText(this@MainActivity, "Błąd zapisu pliku: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }

        activeWebView = wv
        wv.loadUrl("file:///android_asset/rozliczenia_v15.html")
        wrapper.addView(wv)
        return wrapper
    }

    private fun saveBackupTextOffline(rawFileName: String, content: String) {
        try {
            val cleanName = rawFileName.replace(Regex("""[^A-Za-z0-9._-]"""), "_")
                .ifBlank { "scanbolt-kopia.json" }
            val finalName = if (cleanName.endsWith(".json", ignoreCase = true)) cleanName else "$cleanName.json"
            pendingBackupContent = content
            pendingBackupFileName = finalName
            createBackupDocLauncher.launch(finalName)
        } catch (e: Exception) {
            Toast.makeText(
                this,
                "Nie udało się otworzyć wyboru folderu: ${e.message}",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    private fun buildStartAndStatsView(): View {
        val scroll = ScrollView(this)
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(20), dp(16), dp(28))
        }

        val running = RadarStorage.isSessionRunning(this)
        val startMs = RadarStorage.getSessionStartTime(this)
        val stopMs = if (running) System.currentTimeMillis() else RadarStorage.getSessionStopTime(this)

        val sdfDate = SimpleDateFormat("dd.MM HH:mm", Locale.getDefault())
        val sdfHour = SimpleDateFormat("HH:mm", Locale.getDefault())

        val topRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val titleCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        titleCol.addView(TextView(this).apply {
            text = if (running) "Odczyt ekranu aktywny" else "Sesja zakończona"
            textSize = 25f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        })
        titleCol.addView(TextView(this).apply {
            text = if (startMs > 0) "Taxi • ${sdfDate.format(Date(startMs))} do ${sdfHour.format(Date(stopMs))}" else "Taxi • Kliknij START, aby rozpocząć zmianę"
            textSize = 13f
            setTextColor(Color.parseColor("#8A99B5"))
        })

        val badge = TextView(this).apply {
            text = if (running) "● AKTYWNA" else "✓ ZAKOŃCZONA"
            textSize = 12f
            setTextColor(if (running) Color.parseColor("#3DDC84") else Color.parseColor("#4CE0B3"))
            background = roundedBox("#0C261E", 22f, "#2E7D32")
            setPadding(dp(14), dp(10), dp(14), dp(10))
        }
        topRow.addView(titleCol)
        topRow.addView(badge)
        container.addView(topRow)

        val btnStartStop = Button(this).apply {
            text = if (running) "⏹ STOP (Wyłącz nakładkę i zatrzymaj GPS)" else "▶ START (Włącz odczyt ekranu i licznik km GPS)"
            textSize = 15f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(if (running) Color.WHITE else Color.parseColor("#041E14"))
            background = roundedBox(if (running) "#D32F2F" else "#2CE574", 20f, if (running) "#FF6659" else "#65ECC5")
            setPadding(dp(16), dp(18), dp(16), dp(18))
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                topMargin = dp(18)
                bottomMargin = dp(16)
            }
            setOnClickListener {
                if (!running) {
                    if (!Settings.canDrawOverlays(this@MainActivity)) {
                        Toast.makeText(this@MainActivity, "Włącz uprawnienie Nakładki ekranowej!", Toast.LENGTH_LONG).show()
                        try {
                            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                        } catch (_: Exception) {}
                        return@setOnClickListener
                    }
                    val now = System.currentTimeMillis()
                    RadarStorage.setSessionStartTime(this@MainActivity, now)
                    RadarStorage.setSessionStopTime(this@MainActivity, now)
                    RadarStorage.setGpsDistanceMeters(this@MainActivity, 0f)
                    RadarStorage.setSessionAcceptedCount(this@MainActivity, 0)
                    RadarStorage.setSessionGrossTotal(this@MainActivity, 0f)
                    RadarStorage.setSessionRunning(this@MainActivity, true)
                    startGps()
                    if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this@MainActivity, "android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
                        ActivityCompat.requestPermissions(this@MainActivity, arrayOf("android.permission.POST_NOTIFICATIONS"), 102)
                    }
                    Toast.makeText(this@MainActivity, "START! Nakładka i licznik GPS włączone.", Toast.LENGTH_SHORT).show()
                } else {
                    RadarStorage.setSessionStopTime(this@MainActivity, System.currentTimeMillis())
                    RadarStorage.setSessionRunning(this@MainActivity, false)
                    stopGps()
                    Toast.makeText(this@MainActivity, "STOP! Odczyt wyłączony. Podsumowanie poniżej.", Toast.LENGTH_SHORT).show()
                }
                refreshCurrentTab()
            }
        }
        container.addView(btnStartStop)

        val gross = RadarStorage.getSessionGrossTotal(this).toDouble()
        val acceptedCount = RadarStorage.getSessionAcceptedCount(this)
        val gpsKm = RadarStorage.getGpsDistanceMeters(this) / 1000.0
        val avgKm = if (gpsKm > 0.05) gross / gpsKm else 0.0

        val sec = if (startMs > 0 && stopMs >= startMs) ((stopMs - startMs) / 1000L) else 0L
        val timeStr = String.format(Locale.US, "%02d:%02d:%02d", sec / 3600, (sec % 3600) / 60, sec % 60)

        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = roundedBox("#0A2229", 28f, "#26A69A")
            setPadding(dp(20), dp(26), dp(20), dp(26))
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = dp(16)
            }
        }
        hero.addView(TextView(this).apply {
            text = "SUMA PRZYJĘTYCH OFERT • SESJA"
            textSize = 12f
            setTextColor(Color.parseColor("#A5B8D1"))
            gravity = Gravity.CENTER
        })
        hero.addView(TextView(this).apply {
            text = formatMoney(gross)
            textSize = 42f
            setTextColor(Color.parseColor("#2CE574"))
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(0, dp(6), 0, dp(6))
        })
        hero.addView(TextView(this).apply {
            text = if (running) "Liczenie km GPS i oczekiwanie na oferty..." else "Statystyki zakończonej sesji"
            textSize = 13f
            setTextColor(Color.parseColor("#C2D1E5"))
            gravity = Gravity.CENTER
        })
        container.addView(hero)

        container.addView(twoCols(statTile("Czas pracy", timeStr, "#FFFFFF"), statTile("Dystans GPS", String.format(Locale("pl", "PL"), "%.2f km", gpsKm), "#38B6FF")))
        container.addView(twoCols(statTile("Przyjęte kursy", "$acceptedCount", "#3DDC84"), statTile("Średnio za km (GPS)", String.format(Locale("pl", "PL"), "%.2f zł/km", avgKm), "#3DDC84")))

        val bottomBtns = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                topMargin = dp(10)
            }
        }
        bottomBtns.addView(Button(this).apply {
            text = "Historia"
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            background = roundedBox("#0099FF", 24f)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { rightMargin = dp(8) }
            setOnClickListener { switchTab("historia") }
        })
        bottomBtns.addView(Button(this).apply {
            text = "Udostępnij"
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            background = roundedBox("#0C1626", 24f, "#3DD5B0")
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = dp(8) }
            setOnClickListener {
                val txt = String.format(Locale("pl", "PL"), "Podsumowanie sesji:\nPrzyjęte kursy: %d\nSuma przyjętych ofert: %s\nPrzejechane km (GPS): %.2f km\nCzas: %s", acceptedCount, formatMoney(gross), gpsKm, timeStr)
                startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, txt) }, "Udostępnij"))
            }
        })
        container.addView(bottomBtns)

        scroll.addView(container)
        return scroll
    }

    private fun buildSettlementsView(): View {
        val scroll = ScrollView(this)
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(14), dp(14), dp(28))
        }

        val sharePct = RadarOptions.driverSharePercent(this)
        val calcMode = RadarOptions.calcMode(this)
        val periodSummary = OfflineAnalytics.calculatePeriodSummary(this, statsFromKey, statsToKey, sharePct, calcMode)
        val pay = periodSummary.pay

        // Pasek trybu liczenia (według pliku CSV / według screenów Bolta) + udział 45%-55%
        val topModeCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = roundedBox("#101827", 20f, "#24344E")
            setPadding(dp(14), dp(12), dp(14), dp(12))
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = dp(10)
            }
        }
        topModeCard.addView(TextView(this).apply {
            text = if (calcMode == "csv") {
                "Sposób liczenia: według pliku CSV / historii"
            } else {
                "Sposób liczenia: według screenów / wpisów Bolta"
            }
            textSize = 15f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        })
        topModeCard.addView(TextView(this).apply {
            text = if (calcMode == "csv") {
                "Dzień = zmiana od pierwszego kursu (także po północy). Kwoty = Twój udział (${String.format(Locale("pl", "PL"), "%.1f%%", sharePct)}) z faktur / historii."
            } else {
                "Dzień = doba z podsumowań Bolta. Podział udziału kierowcy: ${String.format(Locale("pl", "PL"), "%.1f%%", sharePct)} (napiwki 100% kierowcy, odliczenie gotówki)."
            }
            textSize = 12f
            setTextColor(Color.parseColor("#9BA9C2"))
            setPadding(0, dp(4), 0, dp(8))
        })

        val modeSwitchRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        modeSwitchRow.addView(Button(this).apply {
            text = if (calcMode == "csv") "✓ Według CSV" else "Według CSV"
            textSize = 11.5f
            setTextColor(if (calcMode == "csv") Color.parseColor("#041E14") else Color.WHITE)
            background = roundedBox(if (calcMode == "csv") "#65ECC5" else "#162338", 14f, "#65ECC5")
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { rightMargin = dp(4) }
            setOnClickListener {
                RadarOptions.setCalcMode(this@MainActivity, "csv")
                refreshCurrentTab()
            }
        })
        modeSwitchRow.addView(Button(this).apply {
            text = if (calcMode == "bolt") "✓ Screeny Bolta" else "Screeny Bolta"
            textSize = 11.5f
            setTextColor(if (calcMode == "bolt") Color.parseColor("#041E14") else Color.WHITE)
            background = roundedBox(if (calcMode == "bolt") "#65ECC5" else "#162338", 14f, "#65ECC5")
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = dp(4) }
            setOnClickListener {
                RadarOptions.setCalcMode(this@MainActivity, "bolt")
                refreshCurrentTab()
            }
        })
        topModeCard.addView(modeSwitchRow)
        container.addView(topModeCard)

        // 1. Karta "Moje zarobki" oraz "Rozliczenie wypłaty" (na samej górze, dokładnie jak na zrzutach)
        val earnCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = roundedBox("#0A2229", 24f, "#26A69A")
            setPadding(dp(16), dp(14), dp(16), dp(14))
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = dp(12)
            }
        }
        earnCard.addView(TextView(this).apply {
            text = "Moje zarobki"
            textSize = 20f
            setTextColor(Color.parseColor("#65ECC5"))
            typeface = Typeface.DEFAULT_BOLD
        })
        earnCard.addView(TextView(this).apply {
            text = "${periodSummary.label} • zakres statystyk"
            textSize = 12f
            setTextColor(Color.parseColor("#9BA9C2"))
            setPadding(0, 0, 0, dp(8))
        })
        earnCard.addView(TextView(this).apply {
            text = "Moja część: ${formatMoney(pay.driverShare)}   + Napiwki: ${formatMoney(pay.tips)}"
            textSize = 15f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        })
        earnCard.addView(TextView(this).apply {
            text = "Razem przed gotówką:\n${formatMoney(pay.earned)}"
            textSize = 18f
            setTextColor(Color.parseColor("#2CE574"))
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(8), 0, dp(4))
        })
        earnCard.addView(TextView(this).apply {
            text = "Odebrana gotówka:   − ${formatMoney(pay.cash)}"
            textSize = 14f
            setTextColor(Color.parseColor("#D5E3F7"))
        })
        earnCard.addView(TextView(this).apply {
            text = if (pay.payout >= 0.0) {
                "Do ręki po odjęciu gotówki:\n${formatMoney(pay.payout)}"
            } else {
                "Do oddania partnerowi:\n${formatMoney(abs(pay.payout))}"
            }
            textSize = 22f
            setTextColor(if (pay.payout >= 0.0) Color.parseColor("#65ECC5") else Color.parseColor("#FF8A8A"))
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(8), 0, dp(4))
        })
        if (periodSummary.weekDiscrepancyNote != null) {
            earnCard.addView(TextView(this).apply {
                text = periodSummary.weekDiscrepancyNote
                textSize = 12f
                setTextColor(Color.parseColor("#FFE45E"))
                setPadding(0, dp(4), 0, 0)
            })
        }
        container.addView(earnCard)

        // Karta "Rozliczenie wypłaty" (szczegóły podstawy, udziału 45%-55%, napiwków i gotówki)
        val payDetailCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = roundedBox("#101827", 22f, "#24344E")
            setPadding(dp(16), dp(14), dp(16), dp(14))
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = dp(12)
            }
        }
        payDetailCard.addView(TextView(this).apply {
            text = "Rozliczenie wypłaty"
            textSize = 18f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 0, 0, dp(8))
        })
        payDetailCard.addView(TextView(this).apply {
            text = "Cała podstawa (saldo Bolta bez napiwków): ${formatMoney(pay.basis)}"
            textSize = 13f
            setTextColor(Color.parseColor("#D5E3F7"))
            setPadding(0, dp(2), 0, dp(4))
        })
        payDetailCard.addView(TextView(this).apply {
            text = "Twoja część podstawy (${String.format(Locale("pl", "PL"), "%.1f%%", sharePct)}): ${formatMoney(pay.driverShare)}"
            textSize = 14f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(2), 0, dp(4))
        })
        payDetailCard.addView(TextView(this).apply {
            text = "Napiwki w 100%: + ${formatMoney(pay.tips)}"
            textSize = 13f
            setTextColor(Color.parseColor("#65ECC5"))
            setPadding(0, dp(2), 0, dp(4))
        })
        payDetailCard.addView(TextView(this).apply {
            text = "Odebrana gotówka: − ${formatMoney(pay.cash)}"
            textSize = 13f
            setTextColor(Color.parseColor("#FF8A8A"))
            setPadding(0, dp(2), 0, dp(8))
        })
        payDetailCard.addView(TextView(this).apply {
            text = "Do wypłaty: ${formatMoney(pay.payout)}"
            textSize = 20f
            setTextColor(Color.parseColor("#2CE574"))
            typeface = Typeface.DEFAULT_BOLD
        })

        // Szybka regulacja udziału 45%-55%
        val shareRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                topMargin = dp(10)
            }
        }
        fun addShareStep(lbl: String, delta: Float) {
            shareRow.addView(Button(this).apply {
                text = lbl
                textSize = 11.5f
                setTextColor(Color.WHITE)
                background = roundedBox("#1B2942", 14f, "#38B6FF")
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { rightMargin = dp(3) }
                setOnClickListener {
                    RadarOptions.setDriverSharePercent(this@MainActivity, RadarOptions.driverSharePercent(this@MainActivity) + delta)
                    refreshCurrentTab()
                }
            })
        }
        addShareStep("-1%", -1.0f)
        addShareStep("-0,5%", -0.5f)
        addShareStep("50%", 50.0f - sharePct)
        addShareStep("+0,5%", 0.5f)
        addShareStep("+1%", 1.0f)
        payDetailCard.addView(shareRow)
        container.addView(payDetailCard)

        // 2. Karta "Statystyki" z wyborem zakresu Od / Do, skrótami i "Podsumowanie okresu"
        val statsCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = roundedBox("#101827", 22f, "#24344E")
            setPadding(dp(16), dp(14), dp(16), dp(14))
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = dp(12)
            }
        }
        statsCard.addView(TextView(this).apply {
            text = "Statystyki"
            textSize = 20f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        })
        statsCard.addView(TextView(this).apply {
            text = "Wszystkie wyniki poniżej dotyczą wybranego zakresu. Daty obejmują całe dni, łącznie z ostatnim."
            textSize = 12f
            setTextColor(Color.parseColor("#9BA9C2"))
            setPadding(0, dp(4), 0, dp(10))
        })

        val fromToRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = dp(8)
            }
        }
        val btnFrom = Button(this).apply {
            text = "Od: ${OfflineAnalytics.formatShortDate(statsFromKey)}"
            textSize = 12f
            setTextColor(Color.WHITE)
            background = roundedBox("#162338", 14f, "#32486E")
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { rightMargin = dp(4) }
            setOnClickListener {
                val c = Calendar.getInstance().apply { timeInMillis = OfflineAnalytics.parseDateKeyToMillis(statsFromKey, false) }
                pickDate(c) { picked ->
                    statsFromKey = OfflineAnalytics.dayKeyFromMillis(picked.timeInMillis)
                    if (OfflineAnalytics.parseDateKeyToMillis(statsToKey, false) < OfflineAnalytics.parseDateKeyToMillis(statsFromKey, false)) {
                        statsToKey = statsFromKey
                    }
                    refreshCurrentTab()
                }
            }
        }
        val btnTo = Button(this).apply {
            text = "Do: ${OfflineAnalytics.formatShortDate(statsToKey)}"
            textSize = 12f
            setTextColor(Color.WHITE)
            background = roundedBox("#162338", 14f, "#32486E")
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = dp(4) }
            setOnClickListener {
                val c = Calendar.getInstance().apply { timeInMillis = OfflineAnalytics.parseDateKeyToMillis(statsToKey, false) }
                pickDate(c) { picked ->
                    statsToKey = OfflineAnalytics.dayKeyFromMillis(picked.timeInMillis)
                    if (OfflineAnalytics.parseDateKeyToMillis(statsFromKey, false) > OfflineAnalytics.parseDateKeyToMillis(statsToKey, false)) {
                        statsFromKey = statsToKey
                    }
                    refreshCurrentTab()
                }
            }
        }
        fromToRow.addView(btnFrom)
        fromToRow.addView(btnTo)
        statsCard.addView(fromToRow)

        val quickRow1 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = dp(6)
            }
        }
        fun addRangeShortcut(parent: LinearLayout, lbl: String, onPick: () -> Unit) {
            parent.addView(Button(this).apply {
                text = lbl
                textSize = 11f
                setTextColor(Color.parseColor("#D5E3F7"))
                background = roundedBox("#162338", 14f, "#2E4266")
                setPadding(dp(4), dp(4), dp(4), dp(4))
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { rightMargin = dp(3) }
                setOnClickListener { onPick() }
            })
        }
        addRangeShortcut(quickRow1, "Ten tydzień") {
            val mon = OfflineAnalytics.mondayKeyForMillis(System.currentTimeMillis())
            statsFromKey = mon
            statsToKey = OfflineAnalytics.addDaysToKey(mon, 6)
            refreshCurrentTab()
        }
        addRangeShortcut(quickRow1, "Ten miesiąc") {
            val c = Calendar.getInstance()
            statsFromKey = String.format(Locale.US, "%04d-%02d-01", c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1)
            val lastD = c.getActualMaximum(Calendar.DAY_OF_MONTH)
            statsToKey = String.format(Locale.US, "%04d-%02d-%02d", c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, lastD)
            refreshCurrentTab()
        }
        addRangeShortcut(quickRow1, "Okres partnera") {
            val anchor = OfflineAnalytics.partnerCycleAnchorMonday(this@MainActivity)
            val periods = OfflineAnalytics.get14DayPeriods(anchor, 8)
            val nowK = OfflineAnalytics.dayKeyFromMillis(System.currentTimeMillis())
            val curP = periods.firstOrNull { nowK >= it.first && nowK <= it.second } ?: periods.firstOrNull()
            if (curP != null) {
                statsFromKey = curP.first
                statsToKey = curP.second
            }
            refreshCurrentTab()
        }
        statsCard.addView(quickRow1)

        val quickRow2 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = dp(8)
            }
        }
        addRangeShortcut(quickRow2, "Cała historia") {
            statsFromKey = "2020-01-01"
            statsToKey = "2030-12-31"
            refreshCurrentTab()
        }
        addRangeShortcut(quickRow2, "← Poprzedni") {
            statsFromKey = OfflineAnalytics.addDaysToKey(statsFromKey, -7)
            statsToKey = OfflineAnalytics.addDaysToKey(statsToKey, -7)
            refreshCurrentTab()
        }
        addRangeShortcut(quickRow2, "Następny →") {
            statsFromKey = OfflineAnalytics.addDaysToKey(statsFromKey, 7)
            statsToKey = OfflineAnalytics.addDaysToKey(statsToKey, 7)
            refreshCurrentTab()
        }
        statsCard.addView(quickRow2)

        // Wybór okresu partnera (14 dni) oraz ustawienie początku cyklu partnera
        val anchorMon = OfflineAnalytics.partnerCycleAnchorMonday(this)
        val periods14 = OfflineAnalytics.get14DayPeriods(anchorMon, 6)
        if (periods14.isNotEmpty()) {
            statsCard.addView(TextView(this).apply {
                text = "Wybierz okres partnera (14 dni):"
                textSize = 12f
                setTextColor(Color.parseColor("#9BA9C2"))
                setPadding(0, dp(4), 0, dp(4))
            })
            val pRow = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                    bottomMargin = dp(6)
                }
            }
            for (pItem in periods14.take(2)) {
                val pLabel = "${OfflineAnalytics.formatShortDate(pItem.first)} – ${OfflineAnalytics.formatShortDate(pItem.second)}"
                pRow.addView(Button(this).apply {
                    text = pLabel
                    textSize = 10.5f
                    setTextColor(Color.WHITE)
                    background = roundedBox("#162338", 12f, "#38B6FF")
                    layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { rightMargin = dp(4) }
                    setOnClickListener {
                        statsFromKey = pItem.first
                        statsToKey = pItem.second
                        refreshCurrentTab()
                    }
                })
            }
            statsCard.addView(pRow)
        }

        statsCard.addView(Button(this).apply {
            text = "▶ Ustaw początek cyklu partnera (obecnie: ${OfflineAnalytics.formatShortDate(anchorMon)})"
            textSize = 11.5f
            setTextColor(Color.parseColor("#C2D1E5"))
            background = roundedBox("#141E30", 12f, "#2E4266")
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = dp(10)
            }
            setOnClickListener {
                val c = Calendar.getInstance().apply { timeInMillis = OfflineAnalytics.parseDateKeyToMillis(anchorMon, false) }
                pickDate(c) { picked ->
                    val mon = OfflineAnalytics.mondayKeyForMillis(picked.timeInMillis)
                    OfflineAnalytics.setPartnerCycleAnchorMonday(this@MainActivity, mon)
                    Toast.makeText(this@MainActivity, "Ustawiono poniedziałek cyklu: ${OfflineAnalytics.formatShortDate(mon)}", Toast.LENGTH_SHORT).show()
                    refreshCurrentTab()
                }
            }
        })

        // Podsumowanie okresu (kafle + metryki godzinowe i zmianowe)
        statsCard.addView(TextView(this).apply {
            text = "Podsumowanie okresu"
            textSize = 17f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(2), 0, dp(8))
        })
        statsCard.addView(twoCols(
            statTile("Kursy", "${periodSummary.tripsCount}", "#FFFFFF"),
            statTile("Dni jazdy", "${periodSummary.activeDriveDays}", "#FFFFFF")
        ))
        statsCard.addView(twoCols(
            statTile("Obrót", formatMoney(periodSummary.turnoverGross), "#65ECC5"),
            statTile("Część netto z faktur*", formatMoney(periodSummary.netDriverPart), "#65ECC5")
        ))

        val metricsLines = listOf(
            "Szacunkowy czas zmian (od pierwszego do ostatniego kursu)" to OfflineAnalytics.formatHoursMinutes(periodSummary.estimatedMinutes),
            "Liczba zmian" to "${periodSummary.shiftsCount}",
            "Średnio na zmianę" to OfflineAnalytics.formatHoursMinutes(periodSummary.avgShiftMinutes),
            "Średnia stawka za godzinę (wg CSV / części netto)" to "${String.format(Locale("pl", "PL"), "%.2f", periodSummary.avgHourlyCsv)} zł/h",
            "Dla porównania: ze screenów" to "${String.format(Locale("pl", "PL"), "%.2f", periodSummary.avgHourlyScreens)} zł/h"
        )
        for ((kTxt, vTxt) in metricsLines) {
            val mRow = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, dp(6), 0, dp(6))
            }
            mRow.addView(TextView(this).apply {
                text = kTxt
                textSize = 12.5f
                setTextColor(Color.parseColor("#C2D1E5"))
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.4f)
            })
            mRow.addView(TextView(this).apply {
                text = vTxt
                textSize = 13.5f
                setTextColor(if (kTxt.startsWith("Średnia stawka")) Color.parseColor("#65ECC5") else Color.WHITE)
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.END
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            })
            statsCard.addView(mRow)
        }
        container.addView(statsCard)

        // 3. Wpisanie danych dnia / tygodnia Bolta, import CSV offline, kopia JSON i przywracanie paczki
        val entryCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = roundedBox("#101827", 22f, "#24344E")
            setPadding(dp(16), dp(14), dp(16), dp(14))
        }
        entryCard.addView(TextView(this).apply {
            text = "Wpisz dane z Bolta (offline) i narzędzia"
            textSize = 16f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        })
        entryCard.addView(Button(this).apply {
            text = "📷 Skanuj screeny podsumowań z galerii (offline OCR)"
            textSize = 12.5f
            setTextColor(Color.parseColor("#041E14"))
            typeface = Typeface.DEFAULT_BOLD
            background = roundedBox("#FFE45E", 15f)
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                topMargin = dp(8)
            }
            setOnClickListener { pickSummaryScreensLauncher.launch("image/*") }
        })

        if (pendingSummaryDrafts.isNotEmpty()) {
            val reviewBox = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                background = roundedBox("#0C1829", 18f, "#FFE45E")
                setPadding(dp(12), dp(12), dp(12), dp(12))
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                    topMargin = dp(10)
                }
            }
            reviewBox.addView(TextView(this).apply {
                text = "Odczytane screeny — sprawdź i popraw jeśli źle zeskanowało (${pendingSummaryDrafts.size}):"
                textSize = 13f
                setTextColor(Color.parseColor("#FFE45E"))
                typeface = Typeface.DEFAULT_BOLD
                setPadding(0, 0, 0, dp(6))
            })

            pendingSummaryDrafts.forEachIndexed { idx, draft ->
                val itemBox = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    background = roundedBox("#121E33", 14f, "#2E4266")
                    setPadding(dp(10), dp(10), dp(10), dp(10))
                    layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                        bottomMargin = dp(8)
                    }
                }
                itemBox.addView(TextView(this).apply {
                    text = "Screen #${idx + 1} (${if (draft.isWeek) "Tydzień" else "Dzień"} • ${draft.dateKey})"
                    textSize = 12.5f
                    setTextColor(Color.WHITE)
                    typeface = Typeface.DEFAULT_BOLD
                })
                if (draft.notes.isNotEmpty()) {
                    itemBox.addView(TextView(this).apply {
                        text = "Uwagi: ${draft.notes.joinToString(" ")}"
                        textSize = 11.5f
                        setTextColor(Color.parseColor("#FFB74D"))
                        setPadding(0, dp(2), 0, dp(4))
                    })
                }
                val fDate = addInputField(itemBox, "Data (RRRR-MM-DD):", draft.dateKey).apply {
                    inputType = InputType.TYPE_CLASS_TEXT
                }
                val fTotal = addInputField(itemBox, "Zarobki / saldo Bolta (zł):", String.format(Locale.US, "%.2f", draft.total))
                val fTips = addInputField(itemBox, "Napiwki (zł):", String.format(Locale.US, "%.2f", draft.tips))
                val fCash = addInputField(itemBox, "Gotówka (zł):", String.format(Locale.US, "%.2f", draft.cash))

                var editAsWeek = draft.isWeek
                val chkWeek = CheckBox(this).apply {
                    text = "Zapisz jako screen tygodniowy (poniedziałek tygodnia)"
                    textSize = 12f
                    setTextColor(Color.parseColor("#D5E3F7"))
                    isChecked = editAsWeek
                    setPadding(0, dp(6), 0, dp(6))
                    setOnCheckedChangeListener { _, checked -> editAsWeek = checked }
                }
                itemBox.addView(chkWeek)

                itemBox.addView(Button(this).apply {
                    text = "✓ Zapisz poprawki tego screena"
                    textSize = 12f
                    setTextColor(Color.parseColor("#041E14"))
                    typeface = Typeface.DEFAULT_BOLD
                    background = roundedBox("#2CE574", 12f)
                    setOnClickListener {
                        val dk = fDate.text.toString().trim()
                        if (!Regex("""\d{4}-\d{2}-\d{2}""").matches(dk)) {
                            Toast.makeText(this@MainActivity, "Wpisz poprawną datę w formacie RRRR-MM-DD.", Toast.LENGTH_LONG).show()
                            return@setOnClickListener
                        }
                        val tV = fTotal.text.toString().trim().replace(",", ".").toDoubleOrNull() ?: 0.0
                        val tpV = fTips.text.toString().trim().replace(",", ".").toDoubleOrNull() ?: 0.0
                        val cV = fCash.text.toString().trim().replace(",", ".").toDoubleOrNull() ?: 0.0
                        if (tV < 0.0 || tpV < 0.0 || cV < 0.0 || tpV > tV) {
                            Toast.makeText(this@MainActivity, "Sprawdź kwoty (nie mogą być ujemne, napiwki nie mogą przekraczać salda).", Toast.LENGTH_LONG).show()
                            return@setOnClickListener
                        }
                        if (editAsWeek) {
                            val mon = OfflineAnalytics.mondayKeyForMillis(OfflineAnalytics.parseDateKeyToMillis(dk, false))
                            OfflineAnalytics.upsertBoltWeek(this@MainActivity, BoltWeekSummary(mon, tV, tpV, cV))
                        } else {
                            OfflineAnalytics.upsertBoltDay(this@MainActivity, BoltDaySummary(dk, tV, tpV, cV, 0.0))
                            paySelectedDateKey = dk
                        }
                        pendingSummaryDrafts.removeAt(idx)
                        Toast.makeText(this@MainActivity, "Zapisano poprawione dane screena.", Toast.LENGTH_SHORT).show()
                        refreshCurrentTab()
                    }
                })
                reviewBox.addView(itemBox)
            }

            if (lastSummaryRawText.isNotBlank()) {
                reviewBox.addView(TextView(this).apply {
                    text = "Rozpoznany tekst z OCR:\n${lastSummaryRawText.take(800)}"
                    textSize = 10.5f
                    setTextColor(Color.parseColor("#8A99B5"))
                    setTextIsSelectable(true)
                    setPadding(0, dp(4), 0, 0)
                })
            }
            entryCard.addView(reviewBox)
        }


        val etDate = addInputField(entryCard, "Data dnia (RRRR-MM-DD):", OfflineAnalytics.dayKeyFromMillis(System.currentTimeMillis())).apply {
            inputType = InputType.TYPE_CLASS_TEXT
        }
        val etBolt = addInputField(entryCard, "Twoje zarobki / saldo Bolta (zł):", "0.00")
        val etTips = addInputField(entryCard, "Napiwki (zł):", "0.00")
        val etCash = addInputField(entryCard, "Płatności gotówką (zł):", "0.00")

        entryCard.addView(TextView(this).apply {
            text = "Wklej tekst z ekranu podsumowania Bolta (opcjonalnie — rozpoznanie offline):"
            textSize = 12.5f
            setTextColor(Color.parseColor("#9BA9C2"))
            setPadding(0, dp(10), 0, dp(4))
        })
        val etRawSummary = EditText(this).apply {
            hint = "np. Twoje zarobki 420,50 zł, Napiwki 15,00 zł, Gotówka 80,00 zł..."
            setHintTextColor(Color.parseColor("#677794"))
            setTextColor(Color.WHITE)
            textSize = 12.5f
            minLines = 2
            maxLines = 5
            background = roundedBox("#162338", 14f, "#32486E")
            setPadding(dp(12), dp(8), dp(12), dp(8))
        }
        entryCard.addView(etRawSummary)

        entryCard.addView(Button(this).apply {
            text = "🔍 Rozpoznaj kwoty z tekstu podsumowania (offline)"
            textSize = 12f
            setTextColor(Color.WHITE)
            background = roundedBox("#1B2942", 14f, "#65ECC5")
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(6) }
            setOnClickListener {
                val txt = etRawSummary.text.toString()
                if (txt.isBlank()) {
                    Toast.makeText(this@MainActivity, "Wklej najpierw tekst podsumowania z Bolta.", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                val draft = OfflineAnalytics.parseBoltSummaryTextOffline(txt)
                etDate.setText(draft.dateKey)
                etBolt.setText(String.format(Locale.US, "%.2f", draft.total))
                etTips.setText(String.format(Locale.US, "%.2f", draft.tips))
                etCash.setText(String.format(Locale.US, "%.2f", draft.cash))
                val info = if (draft.notes.isEmpty()) {
                    "Rozpoznano podsumowanie (${if (draft.isWeek) "tydzień" else "dzień"} ${draft.dateKey}) — możesz teraz zapisać lub poprawić kwoty."
                } else {
                    draft.notes.joinToString(" ")
                }
                Toast.makeText(this@MainActivity, info, Toast.LENGTH_LONG).show()
            }
        })

        entryCard.addView(Button(this).apply {
            text = "✓ Zapisz dzień z Bolta"
            setTextColor(Color.parseColor("#041E14"))
            typeface = Typeface.DEFAULT_BOLD
            background = roundedBox("#2CE574", 15f)
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(10) }
            setOnClickListener {
                val dk = etDate.text.toString().trim()
                if (!Regex("""\d{4}-\d{2}-\d{2}""").matches(dk)) {
                    Toast.makeText(this@MainActivity, "Wpisz datę w formacie RRRR-MM-DD.", Toast.LENGTH_LONG).show()
                    return@setOnClickListener
                }
                val bVal = etBolt.text.toString().trim().replace(",", ".").toDoubleOrNull() ?: 0.0
                val tVal = etTips.text.toString().trim().replace(",", ".").toDoubleOrNull() ?: 0.0
                val cVal = etCash.text.toString().trim().replace(",", ".").toDoubleOrNull() ?: 0.0
                if (bVal < 0.0 || tVal < 0.0 || cVal < 0.0 || tVal > bVal) {
                    Toast.makeText(this@MainActivity, "Sprawdź kwoty (nie mogą być ujemne, napiwki nie mogą przekraczać salda).", Toast.LENGTH_LONG).show()
                    return@setOnClickListener
                }
                OfflineAnalytics.upsertBoltDay(this@MainActivity, BoltDaySummary(dk, bVal, tVal, cVal, 0.0))
                Toast.makeText(this@MainActivity, "Zapisano dane dnia $dk.", Toast.LENGTH_SHORT).show()
                refreshCurrentTab()
            }
        })

        entryCard.addView(Button(this).apply {
            text = "✍️ Zapisz jako screen tygodniowy (poniedziałek wybranego dnia)"
            setTextColor(Color.WHITE)
            background = roundedBox("#1B2942", 15f, "#38B6FF")
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(8) }
            setOnClickListener {
                val dk = etDate.text.toString().trim()
                val ms = OfflineAnalytics.parseDateKeyToMillis(dk, false)
                if (ms <= 0L) {
                    Toast.makeText(this@MainActivity, "Wpisz poprawną datę (RRRR-MM-DD).", Toast.LENGTH_LONG).show()
                    return@setOnClickListener
                }
                val mon = OfflineAnalytics.mondayKeyForMillis(ms)
                val bVal = etBolt.text.toString().trim().replace(",", ".").toDoubleOrNull() ?: 0.0
                val tVal = etTips.text.toString().trim().replace(",", ".").toDoubleOrNull() ?: 0.0
                val cVal = etCash.text.toString().trim().replace(",", ".").toDoubleOrNull() ?: 0.0
                OfflineAnalytics.upsertBoltWeek(this@MainActivity, BoltWeekSummary(mon, bVal, tVal, cVal))
                Toast.makeText(this@MainActivity, "Zapisano tydzień od ${OfflineAnalytics.formatShortDate(mon)}.", Toast.LENGTH_SHORT).show()
                refreshCurrentTab()
            }
        })

        val rowTools = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(10) }
        }
        rowTools.addView(Button(this).apply {
            text = "📄 CSV kursów"
            textSize = 11.5f
            setTextColor(Color.parseColor("#041E14"))
            typeface = Typeface.DEFAULT_BOLD
            background = roundedBox("#65ECC5", 14f)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { rightMargin = dp(4) }
            setOnClickListener { pickCsvLauncher.launch("*/*") }
        })
        rowTools.addView(Button(this).apply {
            text = "💾 Kopia JSON"
            textSize = 11.5f
            setTextColor(Color.WHITE)
            background = roundedBox("#1B2942", 14f, "#38B6FF")
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = dp(4) }
            setOnClickListener { exportBackupLauncher.launch("kursradar-kopia.json") }
        })
        entryCard.addView(rowTools)

        val rowTools2 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(8) }
        }
        rowTools2.addView(Button(this).apply {
            text = "📥 Wczytaj kopię"
            textSize = 11.5f
            setTextColor(Color.WHITE)
            background = roundedBox("#1B2942", 14f, "#38B6FF")
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { rightMargin = dp(4) }
            setOnClickListener { importBackupLauncher.launch("*/*") }
        })
        rowTools2.addView(Button(this).apply {
            text = "📦 Przywróć paczkę"
            textSize = 11.5f
            setTextColor(Color.WHITE)
            background = roundedBox("#1B2942", 14f, "#38B6FF")
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = dp(4) }
            setOnClickListener {
                val added = OfflineAnalytics.restoreBundledTrips(this@MainActivity)
                Toast.makeText(this@MainActivity, "Dodano z paczki: $added kursów", Toast.LENGTH_LONG).show()
                refreshCurrentTab()
            }
        })
        entryCard.addView(rowTools2)

        val undoInfo = OfflineAnalytics.getUndoInfo(this)
        if (undoInfo != null) {
            entryCard.addView(Button(this).apply {
                text = "↩ Cofnij ostatnie czyszczenie (${undoInfo.first})"
                textSize = 11.5f
                setTextColor(Color.parseColor("#FFE45E"))
                background = roundedBox("#262112", 14f, "#8E733B")
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(8) }
                setOnClickListener {
                    if (OfflineAnalytics.performUndo(this@MainActivity)) {
                        Toast.makeText(this@MainActivity, "Przywrócono dane sprzed czyszczenia.", Toast.LENGTH_SHORT).show()
                        refreshCurrentTab()
                    }
                }
            })
        }

        container.addView(entryCard)
        // 4. Zapisane dni i screeny tygodniowe z Bolta (z możliwością poprawy)
        val savedDaysMap = OfflineAnalytics.getBoltDays(this)
        val savedWeeksMap = OfflineAnalytics.getBoltWeeks(this)

        val savedBoltCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = roundedBox("#101827", 22f, "#24344E")
            setPadding(dp(16), dp(14), dp(16), dp(14))
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                topMargin = dp(12)
            }
        }
        savedBoltCard.addView(TextView(this).apply {
            text = "Zapisane dni i tygodnie z Bolta (edycja / poprawki)"
            textSize = 16f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 0, 0, dp(6))
        })

        if (savedWeeksMap.isNotEmpty()) {
            savedBoltCard.addView(TextView(this).apply {
                text = "Tygodnie ze screenów Bolta:"
                textSize = 13f
                setTextColor(Color.parseColor("#65ECC5"))
                typeface = Typeface.DEFAULT_BOLD
                setPadding(0, dp(4), 0, dp(4))
            })
            savedWeeksMap.keys.sortedDescending().take(10).forEach { wk ->
                val wItem = savedWeeksMap[wk] ?: return@forEach
                val wRow = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(0, dp(4), 0, dp(4))
                }
                wRow.addView(TextView(this).apply {
                    text = "${OfflineAnalytics.formatWeekRange(wk)}: saldo ${formatMoney(wItem.total)} • napiwki ${formatMoney(wItem.tips)} • gotówka ${formatMoney(wItem.cash)}"
                    textSize = 12f
                    setTextColor(Color.parseColor("#D5E3F7"))
                    layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { rightMargin = dp(6) }
                })
                wRow.addView(Button(this).apply {
                    text = "Popraw"
                    textSize = 11f
                    setTextColor(Color.parseColor("#041E14"))
                    background = roundedBox("#65ECC5", 12f)
                    setPadding(dp(8), dp(2), dp(8), dp(2))
                    setOnClickListener { openEditBoltWeekDialog(wk) }
                })
                savedBoltCard.addView(wRow)
            }
        }

        if (savedDaysMap.isNotEmpty()) {
            savedBoltCard.addView(TextView(this).apply {
                text = "Dni z Bolta (ostatnie 14):"
                textSize = 13f
                setTextColor(Color.parseColor("#65ECC5"))
                typeface = Typeface.DEFAULT_BOLD
                setPadding(0, dp(8), 0, dp(4))
            })
            savedDaysMap.keys.sortedDescending().take(14).forEach { dk ->
                val dItem = savedDaysMap[dk] ?: return@forEach
                val dRow = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(0, dp(4), 0, dp(4))
                }
                dRow.addView(TextView(this).apply {
                    text = "$dk: saldo ${formatMoney(dItem.total)} • napiwki ${formatMoney(dItem.tips)} • gotówka ${formatMoney(dItem.cash)}"
                    textSize = 12f
                    setTextColor(Color.parseColor("#D5E3F7"))
                    layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { rightMargin = dp(6) }
                })
                dRow.addView(Button(this).apply {
                    text = "Popraw"
                    textSize = 11f
                    setTextColor(Color.parseColor("#041E14"))
                    background = roundedBox("#65ECC5", 12f)
                    setPadding(dp(8), dp(2), dp(8), dp(2))
                    setOnClickListener { openEditBoltDayDialog(dk) }
                })
                savedBoltCard.addView(dRow)
            }
        } else if (savedWeeksMap.isEmpty()) {
            savedBoltCard.addView(TextView(this).apply {
                text = "Brak zapisanych dni ani tygodni z Bolta. Możesz je dodać powyżej i w każdej chwili poprawić."
                textSize = 12f
                setTextColor(Color.parseColor("#8A99B5"))
            })
        }

        container.addView(savedBoltCard)

        scroll.addView(container)
        return scroll
    }

    private fun prepareSummaryBitmapOffline(uri: Uri, highContrast: Boolean): Bitmap? {
        return try {
            val stream = contentResolver.openInputStream(uri) ?: return null
            val rawBmp = stream.use { BitmapFactory.decodeStream(it) } ?: return null
            val scale = if (rawBmp.width > 0 && rawBmp.width < 1400) {
                (1600f / rawBmp.width.toFloat()).coerceIn(1f, 3f)
            } else {
                1f
            }
            val targetW = ((rawBmp.width * scale).toInt()).coerceAtLeast(1)
            val targetH = ((rawBmp.height * scale).toInt()).coerceAtLeast(1)
            val scaled = if (scale > 1.01f) {
                Bitmap.createScaledBitmap(rawBmp, targetW, targetH, true).also {
                    if (it !== rawBmp) rawBmp.recycle()
                }
            } else {
                rawBmp
            }
            if (!highContrast) return scaled
            val out = Bitmap.createBitmap(scaled.width, scaled.height, Bitmap.Config.ARGB_8888)
            val cm = ColorMatrix().apply {
                setSaturation(0f)
                val contrast = 1.35f
                val translate = (-0.5f * contrast + 0.5f) * 255f
                postConcat(
                    ColorMatrix(
                        floatArrayOf(
                            contrast, 0f, 0f, 0f, translate,
                            0f, contrast, 0f, 0f, translate,
                            0f, 0f, contrast, 0f, translate,
                            0f, 0f, 0f, 1f, 0f
                        )
                    )
                )
            }
            val paint = Paint().apply { colorFilter = ColorMatrixColorFilter(cm) }
            Canvas(out).drawBitmap(scaled, 0f, 0f, paint)
            if (out !== scaled) scaled.recycle()
            out
        } catch (_: Exception) {
            null
        }
    }

    private fun runOfflineSummaryScreenshotsOcr(uris: List<Uri>) {
        val rec = getSummaryRecognizer()
        if (rec == null) {
            Toast.makeText(this, "Lokalny silnik OCR jest niedostępny — wpisz lub wklej kwoty ręcznie.", Toast.LENGTH_LONG).show()
            return
        }
        val drafts = ArrayList<OfflineAnalytics.ParsedBoltSummaryDraft>()
        val rawTexts = StringBuilder()
        var processed = 0

        for (uri in uris) {
            val bmp = prepareSummaryBitmapOffline(uri, highContrast = false)
            if (bmp == null) {
                processed++
                drafts.add(
                    OfflineAnalytics.ParsedBoltSummaryDraft(
                        dateKey = OfflineAnalytics.dayKeyFromMillis(System.currentTimeMillis()),
                        isWeek = false,
                        total = 0.0,
                        tips = 0.0,
                        cash = 0.0,
                        notes = listOf("Nie udało się otworzyć obrazu — wpisz wartości ręcznie.")
                    )
                )
                if (processed == uris.size) finishSummaryOcrBatch(drafts, rawTexts.toString())
                continue
            }

            val inputImg = InputImage.fromBitmap(bmp, 0)
            rec.process(inputImg)
                .addOnSuccessListener { visionText ->
                    val txt = visionText.text
                    rawTexts.append("--- SCREEN ---\n").append(txt).append("\n")
                    val parsed = OfflineAnalytics.parseBoltSummaryTextOffline(txt)
                    val notesWithCheck = parsed.notes.toMutableList()
                    if (parsed.total > 0.0 && parsed.tips > 0.0) {
                        val basisCheck = OfflineAnalytics.round2(parsed.total - parsed.tips)
                        if (basisCheck < 0.0) {
                            notesWithCheck.add("Napiwki przekraczają kwotę zarobków — sprawdź i popraw przed zapisem.")
                        }
                    }
                    drafts.add(parsed.copy(notes = notesWithCheck))
                }
                .addOnFailureListener { e ->
                    drafts.add(
                        OfflineAnalytics.ParsedBoltSummaryDraft(
                            dateKey = OfflineAnalytics.dayKeyFromMillis(System.currentTimeMillis()),
                            isWeek = false,
                            total = 0.0,
                            tips = 0.0,
                            cash = 0.0,
                            notes = listOf("Błąd odczytu OCR (${e.message ?: "nieznany"}) — popraw ręcznie.")
                        )
                    )
                }
                .addOnCompleteListener {
                    if (!bmp.isRecycled) bmp.recycle()
                    processed++
                    if (processed == uris.size) {
                        mainHandler.post { finishSummaryOcrBatch(drafts, rawTexts.toString()) }
                    }
                }
        }
    }

    private fun finishSummaryOcrBatch(
        drafts: List<OfflineAnalytics.ParsedBoltSummaryDraft>,
        combinedRawText: String
    ) {
        pendingSummaryDrafts = drafts.toMutableList()
        lastSummaryRawText = combinedRawText
        if (drafts.size == 1) {
            val d = drafts[0]
            paySelectedDateKey = d.dateKey
            if (d.isWeek) {
                val mon = OfflineAnalytics.mondayKeyForMillis(OfflineAnalytics.parseDateKeyToMillis(d.dateKey, false))
                OfflineAnalytics.upsertBoltWeek(this, BoltWeekSummary(mon, d.total, d.tips, d.cash))
                Toast.makeText(this, "Odczytano screen tygodniowy (${OfflineAnalytics.formatWeekRange(mon)}) — możesz go edytować poniżej.", Toast.LENGTH_LONG).show()
            } else {
                OfflineAnalytics.upsertBoltDay(this, BoltDaySummary(d.dateKey, d.total, d.tips, d.cash, 0.0))
                Toast.makeText(this, "Odczytano screen dzienny (${d.dateKey}) — możesz go edytować poniżej.", Toast.LENGTH_LONG).show()
            }
        } else {
            Toast.makeText(this, "Odczytano ${drafts.size} screen(y) — sprawdź i popraw każdy przed/po zapisie.", Toast.LENGTH_LONG).show()
        }
        if (currentTab == "rozliczenia") refreshCurrentTab()
    }

    private fun fromInclusiveMillis(cal: Calendar): Long {
        val c = cal.clone() as Calendar
        c.set(Calendar.SECOND, 0)
        c.set(Calendar.MILLISECOND, 0)
        return c.timeInMillis
    }

    private fun toExclusiveMillis(cal: Calendar): Long {
        val c = cal.clone() as Calendar
        c.set(Calendar.SECOND, 0)
        c.set(Calendar.MILLISECOND, 0)
        c.add(Calendar.MINUTE, 1)
        return c.timeInMillis
    }

    private fun formatRangeDisplay(fromInclusive: Long, toExclusive: Long): String {
        val sdf = SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault())
        val endDisplay = Date(maxOf(fromInclusive, toExclusive - 60_000L))
        return "${sdf.format(Date(fromInclusive))} – ${sdf.format(endDisplay)}"
    }

    private fun formatMoney(value: Double): String {
        val symbols = DecimalFormatSymbols(Locale("pl", "PL")).apply {
            groupingSeparator = ' '
            decimalSeparator = ','
        }
        val df = DecimalFormat("#,##0.00", symbols)
        return "${df.format(value)} zł"
    }

    private fun pickDate(initial: Calendar, onPicked: (Calendar) -> Unit) {
        DatePickerDialog(
            this,
            { _, year, month, dayOfMonth ->
                val res = initial.clone() as Calendar
                res.set(Calendar.YEAR, year)
                res.set(Calendar.MONTH, month)
                res.set(Calendar.DAY_OF_MONTH, dayOfMonth)
                onPicked(res)
            },
            initial.get(Calendar.YEAR),
            initial.get(Calendar.MONTH),
            initial.get(Calendar.DAY_OF_MONTH)
        ).show()
    }

    private fun pickTime(initial: Calendar, onPicked: (Calendar) -> Unit) {
        TimePickerDialog(
            this,
            { _, hourOfDay, minute ->
                val res = initial.clone() as Calendar
                res.set(Calendar.HOUR_OF_DAY, hourOfDay)
                res.set(Calendar.MINUTE, minute)
                onPicked(res)
            },
            initial.get(Calendar.HOUR_OF_DAY),
            initial.get(Calendar.MINUTE),
            true
        ).show()
    }

    private fun buildHistoryView(): View {
        val scroll = ScrollView(this)
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(16), dp(14), dp(28))
        }

        val sdfDate = SimpleDateFormat("dd.MM.yyyy", Locale.getDefault())
        val sdfTime = SimpleDateFormat("HH:mm", Locale.getDefault())
        val sdfFull = SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault())

        val draftFrom = (filterFromCal?.clone() as? Calendar) ?: Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val draftTo = (filterToCal?.clone() as? Calendar) ?: Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 23)
            set(Calendar.MINUTE, 59)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }

        val filterCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = roundedBox("#101827", 22f, "#24344E")
            setPadding(dp(14), dp(14), dp(14), dp(14))
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = dp(12)
            }
        }

        filterCard.addView(TextView(this).apply {
            text = "ZAKRES HISTORII"
            textSize = 15f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 0, 0, dp(8))
        })

        val shortcutsRow1 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = dp(6)
            }
        }
        val shortcutsRow2 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = dp(10)
            }
        }
        fun addShortcut(parentRow: LinearLayout, label: String, onClick: () -> Unit) {
            parentRow.addView(Button(this).apply {
                text = label
                textSize = 11f
                setTextColor(Color.parseColor("#C2D1E5"))
                background = roundedBox("#162338", 14f, "#2E4266")
                setPadding(dp(6), dp(4), dp(6), dp(4))
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                    rightMargin = dp(4)
                }
                setOnClickListener { onClick() }
            })
        }
        addShortcut(shortcutsRow1, "Dzisiaj") {
            val f = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            }
            val t = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, 23); set(Calendar.MINUTE, 59); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            }
            filterFromCal = f
            filterToCal = t
            refreshCurrentTab()
        }
        addShortcut(shortcutsRow1, "Wczoraj") {
            val f = Calendar.getInstance().apply {
                add(Calendar.DAY_OF_MONTH, -1)
                set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            }
            val t = Calendar.getInstance().apply {
                add(Calendar.DAY_OF_MONTH, -1)
                set(Calendar.HOUR_OF_DAY, 23); set(Calendar.MINUTE, 59); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            }
            filterFromCal = f
            filterToCal = t
            refreshCurrentTab()
        }
        addShortcut(shortcutsRow2, "Ten tydzień") {
            val f = Calendar.getInstance().apply {
                firstDayOfWeek = Calendar.MONDAY
                set(Calendar.DAY_OF_WEEK, Calendar.MONDAY)
                set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            }
            val t = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, 23); set(Calendar.MINUTE, 59); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            }
            filterFromCal = f
            filterToCal = t
            refreshCurrentTab()
        }
        addShortcut(shortcutsRow2, "Ten miesiąc") {
            val f = Calendar.getInstance().apply {
                set(Calendar.DAY_OF_MONTH, 1)
                set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            }
            val t = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, 23); set(Calendar.MINUTE, 59); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            }
            filterFromCal = f
            filterToCal = t
            refreshCurrentTab()
        }
        filterCard.addView(shortcutsRow1)
        filterCard.addView(shortcutsRow2)

        val fromLabels = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fromLabels.addView(TextView(this).apply {
            text = "Data od:"
            textSize = 12f
            setTextColor(Color.parseColor("#8A99B5"))
            typeface = Typeface.DEFAULT_BOLD
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.3f)
        })
        fromLabels.addView(TextView(this).apply {
            text = "Godzina od:"
            textSize = 12f
            setTextColor(Color.parseColor("#8A99B5"))
            typeface = Typeface.DEFAULT_BOLD
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        })
        filterCard.addView(fromLabels)

        val fromRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                topMargin = dp(4)
                bottomMargin = dp(8)
            }
        }
        val btnFromDate = Button(this).apply {
            text = "📅 ${sdfDate.format(draftFrom.time)}"
            textSize = 12f
            setTextColor(Color.WHITE)
            background = roundedBox("#162338", 14f, "#32486E")
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.3f).apply { rightMargin = dp(6) }
        }
        val btnFromTime = Button(this).apply {
            text = "🕒 ${sdfTime.format(draftFrom.time)}"
            textSize = 12f
            setTextColor(Color.WHITE)
            background = roundedBox("#162338", 14f, "#32486E")
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        btnFromDate.setOnClickListener {
            pickDate(draftFrom) { chosen ->
                draftFrom.set(Calendar.YEAR, chosen.get(Calendar.YEAR))
                draftFrom.set(Calendar.MONTH, chosen.get(Calendar.MONTH))
                draftFrom.set(Calendar.DAY_OF_MONTH, chosen.get(Calendar.DAY_OF_MONTH))
                btnFromDate.text = "📅 ${sdfDate.format(draftFrom.time)}"
            }
        }
        btnFromTime.setOnClickListener {
            pickTime(draftFrom) { chosen ->
                draftFrom.set(Calendar.HOUR_OF_DAY, chosen.get(Calendar.HOUR_OF_DAY))
                draftFrom.set(Calendar.MINUTE, chosen.get(Calendar.MINUTE))
                btnFromTime.text = "🕒 ${sdfTime.format(draftFrom.time)}"
            }
        }
        fromRow.addView(btnFromDate)
        fromRow.addView(btnFromTime)
        filterCard.addView(fromRow)

        val toLabels = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        toLabels.addView(TextView(this).apply {
            text = "Data do:"
            textSize = 12f
            setTextColor(Color.parseColor("#8A99B5"))
            typeface = Typeface.DEFAULT_BOLD
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.3f)
        })
        toLabels.addView(TextView(this).apply {
            text = "Godzina do:"
            textSize = 12f
            setTextColor(Color.parseColor("#8A99B5"))
            typeface = Typeface.DEFAULT_BOLD
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        })
        filterCard.addView(toLabels)

        val toRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                topMargin = dp(4)
                bottomMargin = dp(10)
            }
        }
        val btnToDate = Button(this).apply {
            text = "📅 ${sdfDate.format(draftTo.time)}"
            textSize = 12f
            setTextColor(Color.WHITE)
            background = roundedBox("#162338", 14f, "#32486E")
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.3f).apply { rightMargin = dp(6) }
        }
        val btnToTime = Button(this).apply {
            text = "🕒 ${sdfTime.format(draftTo.time)}"
            textSize = 12f
            setTextColor(Color.WHITE)
            background = roundedBox("#162338", 14f, "#32486E")
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        btnToDate.setOnClickListener {
            pickDate(draftTo) { chosen ->
                draftTo.set(Calendar.YEAR, chosen.get(Calendar.YEAR))
                draftTo.set(Calendar.MONTH, chosen.get(Calendar.MONTH))
                draftTo.set(Calendar.DAY_OF_MONTH, chosen.get(Calendar.DAY_OF_MONTH))
                btnToDate.text = "📅 ${sdfDate.format(draftTo.time)}"
            }
        }
        btnToTime.setOnClickListener {
            pickTime(draftTo) { chosen ->
                draftTo.set(Calendar.HOUR_OF_DAY, chosen.get(Calendar.HOUR_OF_DAY))
                draftTo.set(Calendar.MINUTE, chosen.get(Calendar.MINUTE))
                btnToTime.text = "🕒 ${sdfTime.format(draftTo.time)}"
            }
        }
        toRow.addView(btnToDate)
        toRow.addView(btnToTime)
        filterCard.addView(toRow)

        val actionRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }
        actionRow.addView(Button(this).apply {
            text = "Zastosuj"
            setTextColor(Color.parseColor("#041E14"))
            typeface = Typeface.DEFAULT_BOLD
            background = roundedBox("#2CE574", 16f)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { rightMargin = dp(6) }
            setOnClickListener {
                val fromInc = fromInclusiveMillis(draftFrom)
                val toExc = toExclusiveMillis(draftTo)
                if (toExc <= fromInc) {
                    Toast.makeText(
                        this@MainActivity,
                        "Nieprawidłowy zakres: data i godzina końcowa nie mogą być wcześniejsze od początkowej.",
                        Toast.LENGTH_LONG
                    ).show()
                    return@setOnClickListener
                }
                filterFromCal = (draftFrom.clone() as Calendar).apply {
                    set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
                }
                filterToCal = (draftTo.clone() as Calendar).apply {
                    set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
                }
                refreshCurrentTab()
            }
        })
        actionRow.addView(Button(this).apply {
            text = "Wszystko"
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            background = roundedBox(if (filterFromCal == null && filterToCal == null) "#0099FF" else "#1B2942", 16f, "#38B6FF")
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = dp(6) }
            setOnClickListener {
                filterFromCal = null
                filterToCal = null
                refreshCurrentTab()
            }
        })
        filterCard.addView(actionRow)
        container.addView(filterCard)

        val activeFromInc = filterFromCal?.let { fromInclusiveMillis(it) }
        val activeToExc = filterToCal?.let { toExclusiveMillis(it) }
        val filteredList = RadarStorage.filterHistory(this, activeFromInc, activeToExc)
        val summary = RadarStorage.calculateSummary(filteredList)

        val periodLabel = if (activeFromInc != null && activeToExc != null) {
            formatRangeDisplay(activeFromInc, activeToExc)
        } else {
            "Wszystko"
        }

        val summaryCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = roundedBox("#0A2229", 22f, "#26A69A")
            setPadding(dp(16), dp(14), dp(16), dp(14))
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = dp(12)
            }
        }
        summaryCard.addView(TextView(this).apply {
            text = "Wybrany okres: $periodLabel"
            textSize = 13f
            setTextColor(Color.parseColor("#A5B8D1"))
        })
        summaryCard.addView(TextView(this).apply {
            text = "Przyjęte kursy: ${summary.acceptedCount}"
            textSize = 15f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(4), 0, dp(2))
        })
        summaryCard.addView(TextView(this).apply {
            text = "Suma przyjętych ofert: ${formatMoney(summary.acceptedSumPln)}"
            textSize = 19f
            setTextColor(Color.parseColor("#2CE574"))
            typeface = Typeface.DEFAULT_BOLD
        })
        summaryCard.addView(TextView(this).apply {
            text = "Kwoty z ofert zapisanych jako przyjęte (bez screenów)"
            textSize = 11f
            setTextColor(Color.parseColor("#8A99B5"))
            setPadding(0, dp(2), 0, 0)
        })
        container.addView(summaryCard)

        container.addView(Button(this).apply {
            text = "Usuń historię"
            textSize = 13f
            setTextColor(Color.parseColor("#FF8A8A"))
            typeface = Typeface.DEFAULT_BOLD
            background = roundedBox("#24131B", 16f, "#6E2E40")
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = dp(14)
            }
            setOnClickListener { openDeleteHistoryDialog() }
        })

        container.addView(TextView(this).apply {
            text = "Wszystkie zapisane kursy (${filteredList.size})"
            textSize = 16f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 0, 0, dp(10))
        })

        if (filteredList.isEmpty()) {
            container.addView(TextView(this).apply {
                text = "Brak kursów w wybranym okresie"
                textSize = 14f
                setTextColor(Color.parseColor("#8A99B5"))
                setPadding(dp(8), dp(20), dp(8), dp(20))
            })
        }

        filteredList.take(250).forEach { item ->
            val rateTrip = if (item.rateCourse > 0.0) item.rateCourse else if (item.tripKm > 0) item.priceGross / item.tripKm else 0.0
            val rateTotal = if (item.rateWithPickup > 0.0) item.rateWithPickup else if (item.totalKm > 0) item.priceGross / item.totalKm else rateTrip
            val st = item.normalizedStatus
            val isScreen = item.source == "SCREEN" || st == OfferStatus.REVIEW

            val borderColor = when {
                isScreen -> "#2F6C9A"
                st == OfferStatus.ACCEPTED -> "#2E7D32"
                st == OfferStatus.REJECTED -> "#6E2E40"
                else -> "#24344E"
            }

            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                background = roundedBox("#101827", 22f, borderColor)
                setPadding(dp(15), dp(14), dp(15), dp(14))
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                    bottomMargin = dp(10)
                }
            }

            val row1 = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            val srcTag = when (item.source) {
                "SCREEN" -> "Screen"
                "CSV", "CSV_BUNDLE", "CASH_BUNDLE" -> "CSV"
                else -> "Bolt"
            }
            val timeInfo = if (!isScreen && st == OfferStatus.ACCEPTED && item.acceptedTimestamp > 0L && item.acceptedTimestamp != item.timestamp) {
                "$srcTag • Przyjęto: ${sdfFull.format(Date(item.acceptedTimestamp))} (wykryto ${sdfTime.format(Date(item.timestamp))})"
            } else {
                "$srcTag • ${sdfFull.format(Date(item.effectiveTimestamp))}"
            }
            row1.addView(TextView(this).apply {
                text = timeInfo
                textSize = 12f
                setTextColor(Color.parseColor("#9BA9C2"))
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            })

            val statusLabel = OfferStatus.labelPl(st, item.source)
            val (statusTextColor, statusBg, statusStroke) = when {
                isScreen -> arrayOf("#6AB7FF", "#10202E", "#2F6C9A")
                st == OfferStatus.ACCEPTED -> arrayOf("#4CE0B3", "#0E2923", "#2E7D32")
                st == OfferStatus.REJECTED -> arrayOf("#FF8A8A", "#2B141C", "#8E3B4E")
                else -> arrayOf("#FFD54F", "#2B2414", "#8E733B")
            }
            row1.addView(TextView(this).apply {
                text = statusLabel
                textSize = 11f
                setTextColor(Color.parseColor(statusTextColor))
                background = roundedBox(statusBg, 16f, statusStroke)
                setPadding(dp(10), dp(4), dp(10), dp(4))
            })
            card.addView(row1)

            val row2 = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, dp(8), 0, dp(4))
            }
            row2.addView(TextView(this).apply {
                text = formatMoney(item.priceGross)
                textSize = 25f
                setTextColor(Color.WHITE)
                typeface = Typeface.DEFAULT_BOLD
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            })
            if (rateTrip > 0.0) {
                val greenCut = RadarStorage.getGreenKmRate(this@MainActivity).toDouble()
                val yellowCut = RadarStorage.getYellowKmRate(this@MainActivity).toDouble()
                val rateColorHex = when {
                    rateTrip >= greenCut -> "#3DDC84"
                    rateTrip >= yellowCut -> "#FFD54F"
                    else -> "#FF6B6B"
                }
                row2.addView(TextView(this).apply {
                    text = String.format(Locale("pl", "PL"), "%.2f zł/km", rateTrip)
                    textSize = 20f
                    setTextColor(Color.parseColor(rateColorHex))
                    typeface = Typeface.DEFAULT_BOLD
                })
            }
            card.addView(row2)

            val row3 = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            row3.addView(TextView(this).apply {
                val pGreenCut = RadarStorage.getPickupGreenKmRate(this@MainActivity).toDouble()
                val pYellowCut = RadarStorage.getPickupYellowKmRate(this@MainActivity).toDouble()
                val detailColorHex = if (item.tripKm > 0.0 && item.pickupKm > 0.05 && rateTotal > 0.0) {
                    when {
                        rateTotal >= pGreenCut -> "#3DDC84"
                        rateTotal >= pYellowCut -> "#FFD54F"
                        else -> "#FF6B6B"
                    }
                } else if (item.tripKm > 0.0 && rateTrip > 0.0) {
                    val gCut = RadarStorage.getGreenKmRate(this@MainActivity).toDouble()
                    val yCut = RadarStorage.getYellowKmRate(this@MainActivity).toDouble()
                    when {
                        rateTrip >= gCut -> "#3DDC84"
                        rateTrip >= yCut -> "#FFD54F"
                        else -> "#FF6B6B"
                    }
                } else {
                    "#8A99B5"
                }
                text = if (item.tripKm > 0.0) {
                    if (item.pickupKm > 0.05) {
                        String.format(
                            Locale("pl", "PL"),
                            "Kurs: %.1f km (%.2f zł/km) • Dojazd: %.1f km (z dojazdem: %.2f zł/km)",
                            item.tripKm, rateTrip, item.pickupKm, rateTotal
                        )
                    } else {
                        String.format(Locale("pl", "PL"), "Kurs: %.1f km • brak danych dojazdu", item.tripKm)
                    }
                } else {
                    "Wpis rozliczeniowy / import"
                }
                textSize = 12f
                setTextColor(Color.parseColor(detailColorHex))
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            })
            row3.addView(Button(this).apply {
                text = "Edytuj"
                textSize = 11f
                setTextColor(Color.parseColor("#65ECC5"))
                background = roundedBox("#14262B", 14f, "#2E7D32")
                setPadding(dp(10), dp(2), dp(10), dp(2))
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                    rightMargin = dp(6)
                }
                setOnClickListener {
                    openEditHistoryEntryDialog(item)
                }
            })
            row3.addView(Button(this).apply {
                text = "Usuń"
                textSize = 11f
                setTextColor(Color.parseColor("#FF8A8A"))
                background = roundedBox("#28151E", 14f, "#5C2B38")
                setPadding(dp(10), dp(2), dp(10), dp(2))
                setOnClickListener {
                    OfflineAnalytics.snapshotUndo(this@MainActivity, "usunięcie wpisu")
                    RadarStorage.deleteHistoryItem(this@MainActivity, item.id)
                    refreshCurrentTab()
                }
            })
            card.addView(row3)

            if (item.pickupAddress.isNotBlank()) {
                card.addView(TextView(this).apply {
                    text = "Odbiór: ${item.pickupAddress}"
                    textSize = 12f
                    setTextColor(Color.parseColor("#9BA9C2"))
                    setPadding(0, dp(6), 0, 0)
                })
            }
            card.addView(TextView(this).apply {
                text = "Cel: ${item.destination}"
                textSize = 13f
                setTextColor(Color.parseColor("#8A99B5"))
                setPadding(0, dp(4), 0, 0)
            })

            container.addView(card)
        }

        if (filteredList.size > 250) {
            container.addView(TextView(this).apply {
                text = "Wyświetlono 250 najnowszych pozycji z ${filteredList.size}. Zawęź zakres dat, aby przeglądać starsze."
                textSize = 12f
                setTextColor(Color.parseColor("#8A99B5"))
                setPadding(0, dp(4), 0, dp(8))
            })
        }

        scroll.addView(container)
        return scroll
    }

    private fun openDeleteHistoryDialog() {
        val options = arrayOf(
            "Usuń z wybranego zakresu",
            "Usuń całą historię"
        )
        AlertDialog.Builder(this)
            .setTitle("Usuń historię")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> openDeleteRangeDialog()
                    1 -> openConfirmDeleteAllDialog()
                }
            }
            .setNegativeButton("Anuluj", null)
            .show()
    }

    private fun openDeleteRangeDialog() {
        val sdfDate = SimpleDateFormat("dd.MM.yyyy", Locale.getDefault())
        val sdfTime = SimpleDateFormat("HH:mm", Locale.getDefault())

        val delFrom = (filterFromCal?.clone() as? Calendar) ?: Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val delTo = (filterToCal?.clone() as? Calendar) ?: Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 23)
            set(Calendar.MINUTE, 59)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(14), dp(20), dp(8))
        }

        box.addView(TextView(this).apply { text = "Data od:"; textSize = 12f; typeface = Typeface.DEFAULT_BOLD })
        val bFromDate = Button(this).apply { text = sdfDate.format(delFrom.time) }
        box.addView(bFromDate)

        box.addView(TextView(this).apply { text = "Godzina od:"; textSize = 12f; typeface = Typeface.DEFAULT_BOLD; setPadding(0, dp(6), 0, 0) })
        val bFromTime = Button(this).apply { text = sdfTime.format(delFrom.time) }
        box.addView(bFromTime)

        box.addView(TextView(this).apply { text = "Data do:"; textSize = 12f; typeface = Typeface.DEFAULT_BOLD; setPadding(0, dp(8), 0, 0) })
        val bToDate = Button(this).apply { text = sdfDate.format(delTo.time) }
        box.addView(bToDate)

        box.addView(TextView(this).apply { text = "Godzina do:"; textSize = 12f; typeface = Typeface.DEFAULT_BOLD; setPadding(0, dp(6), 0, 0) })
        val bToTime = Button(this).apply { text = sdfTime.format(delTo.time) }
        box.addView(bToTime)

        bFromDate.setOnClickListener {
            pickDate(delFrom) { c ->
                delFrom.set(Calendar.YEAR, c.get(Calendar.YEAR))
                delFrom.set(Calendar.MONTH, c.get(Calendar.MONTH))
                delFrom.set(Calendar.DAY_OF_MONTH, c.get(Calendar.DAY_OF_MONTH))
                bFromDate.text = sdfDate.format(delFrom.time)
            }
        }
        bFromTime.setOnClickListener {
            pickTime(delFrom) { c ->
                delFrom.set(Calendar.HOUR_OF_DAY, c.get(Calendar.HOUR_OF_DAY))
                delFrom.set(Calendar.MINUTE, c.get(Calendar.MINUTE))
                bFromTime.text = sdfTime.format(delFrom.time)
            }
        }
        bToDate.setOnClickListener {
            pickDate(delTo) { c ->
                delTo.set(Calendar.YEAR, c.get(Calendar.YEAR))
                delTo.set(Calendar.MONTH, c.get(Calendar.MONTH))
                delTo.set(Calendar.DAY_OF_MONTH, c.get(Calendar.DAY_OF_MONTH))
                bToDate.text = sdfDate.format(delTo.time)
            }
        }
        bToTime.setOnClickListener {
            pickTime(delTo) { c ->
                delTo.set(Calendar.HOUR_OF_DAY, c.get(Calendar.HOUR_OF_DAY))
                delTo.set(Calendar.MINUTE, c.get(Calendar.MINUTE))
                bToTime.text = sdfTime.format(delTo.time)
            }
        }

        AlertDialog.Builder(this)
            .setTitle("Usuń z wybranego zakresu")
            .setView(box)
            .setNegativeButton("Anuluj", null)
            .setPositiveButton("Dalej") { _, _ ->
                val fromInc = fromInclusiveMillis(delFrom)
                val toExc = toExclusiveMillis(delTo)
                if (toExc <= fromInc) {
                    Toast.makeText(
                        this,
                        "Nieprawidłowy zakres: data i godzina końcowa nie mogą być wcześniejsze od początkowej.",
                        Toast.LENGTH_LONG
                    ).show()
                    return@setPositiveButton
                }
                val matching = RadarStorage.filterHistory(this, fromInc, toExc)
                openConfirmDeleteRangeDialog(fromInc, toExc, matching)
            }
            .show()
    }

    private fun openConfirmDeleteRangeDialog(fromInc: Long, toExc: Long, matching: List<RideEntry>) {
        val count = matching.size
        val rangeText = formatRangeDisplay(fromInc, toExc)
        val msg = "Usunąć $count wpisów historii z okresu\n$rangeText?\nTej operacji nie można cofnąć."
        AlertDialog.Builder(this)
            .setTitle("Potwierdzenie usunięcia")
            .setMessage(msg)
            .setNegativeButton("Anuluj", null)
            .setPositiveButton("Usuń") { _, _ ->
                OfflineAnalytics.snapshotUndo(this, "usunięcie zakresu historii")
                matching.firstOrNull()?.let { latest ->
                    val sig = String.format(Locale.US, "%d|%.1f", latest.priceGrosze, latest.tripKm)
                    RadarStorage.suppressOfferSignature(this, sig)
                }
                val deleted = RadarStorage.deleteHistoryInRange(this, fromInc, toExc)
                Toast.makeText(this, "Usunięto wpisów: $deleted", Toast.LENGTH_SHORT).show()
                refreshCurrentTab()
            }
            .show()
    }

    private fun openConfirmDeleteAllDialog() {
        val total = RadarStorage.getHistory(this).size
        val msg = "Usunąć całą historię — łącznie $total wpisów?\nTej operacji nie można cofnąć."
        AlertDialog.Builder(this)
            .setTitle("Potwierdzenie usunięcia")
            .setMessage(msg)
            .setNegativeButton("Anuluj", null)
            .setPositiveButton("Usuń") { _, _ ->
                OfflineAnalytics.snapshotUndo(this, "usunięcie całej historii")
                RadarStorage.getHistory(this).firstOrNull()?.let { latest ->
                    val sig = String.format(Locale.US, "%d|%.1f", latest.priceGrosze, latest.tripKm)
                    RadarStorage.suppressOfferSignature(this, sig)
                }
                val deleted = RadarStorage.clearAllHistory(this)
                Toast.makeText(this, "Usunięto całą historię ($deleted wpisów).", Toast.LENGTH_SHORT).show()
                refreshCurrentTab()
            }
            .show()
    }

    private fun openEditBoltDayDialog(initialKey: String) {
        val existingMap = OfflineAnalytics.getBoltDays(this)
        val cur = existingMap[initialKey] ?: BoltDaySummary(initialKey, 0.0, 0.0, 0.0, 0.0)

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(14), dp(20), dp(8))
        }
        val etDate = addInputField(box, "Data dnia (RRRR-MM-DD):", cur.dateKey).apply {
            inputType = InputType.TYPE_CLASS_TEXT
        }
        val etTotal = addInputField(box, "Twoje zarobki / saldo Bolta (zł):", cur.total.toString())
        val etTips = addInputField(box, "Napiwki (zł):", cur.tips.toString())
        val etCash = addInputField(box, "Płatności gotówką (zł):", cur.cash.toString())

        AlertDialog.Builder(this)
            .setTitle("Popraw dane dnia z Bolta")
            .setView(box)
            .setNegativeButton("Anuluj", null)
            .setPositiveButton("✓ Zapisz i oblicz wypłatę") { _, _ ->
                val dk = etDate.text.toString().trim()
                if (!Regex("""\d{4}-\d{2}-\d{2}""").matches(dk)) {
                    Toast.makeText(this, "Wpisz poprawną datę w formacie RRRR-MM-DD.", Toast.LENGTH_LONG).show()
                    return@setPositiveButton
                }
                val tVal = etTotal.text.toString().trim().replace(",", ".").toDoubleOrNull() ?: 0.0
                val tpVal = etTips.text.toString().trim().replace(",", ".").toDoubleOrNull() ?: 0.0
                val csVal = etCash.text.toString().trim().replace(",", ".").toDoubleOrNull() ?: 0.0
                if (tVal < 0.0 || tpVal < 0.0 || csVal < 0.0 || tpVal > tVal) {
                    Toast.makeText(this, "Sprawdź kwoty (nie mogą być ujemne, napiwki nie mogą przekraczać zarobków).", Toast.LENGTH_LONG).show()
                    return@setPositiveButton
                }
                if (dk != cur.dateKey) {
                    OfflineAnalytics.deleteBoltDay(this, cur.dateKey)
                }
                OfflineAnalytics.upsertBoltDay(this, BoltDaySummary(dk, tVal, tpVal, csVal, cur.camp))
                paySelectedDateKey = dk
                Toast.makeText(this, "Zapisano poprawki dla dnia $dk.", Toast.LENGTH_SHORT).show()
                refreshCurrentTab()
            }
            .show()
    }

    private fun openEditBoltWeekDialog(weekKey: String) {
        val mon = OfflineAnalytics.mondayKeyForMillis(OfflineAnalytics.parseDateKeyToMillis(weekKey, false))
        val cur = OfflineAnalytics.getBoltWeeks(this)[mon] ?: BoltWeekSummary(mon, 0.0, 0.0, 0.0)

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(14), dp(20), dp(8))
        }
        val etTotal = addInputField(box, "Zarobki tygodniowe z Bolta (zł):", cur.total.toString())
        val etTips = addInputField(box, "Napiwki tygodniowe (zł):", cur.tips.toString())
        val etCash = addInputField(box, "Gotówka tygodniowa (zł):", cur.cash.toString())

        AlertDialog.Builder(this)
            .setTitle("Popraw screen tygodniowy (${OfflineAnalytics.formatWeekRange(mon)})")
            .setView(box)
            .setNegativeButton("Anuluj", null)
            .setPositiveButton("✓ Zapisz i oblicz wypłatę") { _, _ ->
                val tVal = etTotal.text.toString().trim().replace(",", ".").toDoubleOrNull() ?: 0.0
                val tpVal = etTips.text.toString().trim().replace(",", ".").toDoubleOrNull() ?: 0.0
                val csVal = etCash.text.toString().trim().replace(",", ".").toDoubleOrNull() ?: 0.0
                if (tVal < 0.0 || tpVal < 0.0 || csVal < 0.0 || tpVal > tVal) {
                    Toast.makeText(this, "Sprawdź kwoty (nie mogą być ujemne, napiwki nie mogą przekraczać zarobków).", Toast.LENGTH_LONG).show()
                    return@setPositiveButton
                }
                OfflineAnalytics.upsertBoltWeek(this, BoltWeekSummary(mon, tVal, tpVal, csVal))
                Toast.makeText(this, "Zapisano poprawki dla tygodnia ${OfflineAnalytics.formatWeekRange(mon)}.", Toast.LENGTH_SHORT).show()
                refreshCurrentTab()
            }
            .show()
    }

    private fun openEditHistoryEntryDialog(item: RideEntry) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(14), dp(20), dp(8))
        }
        val etPrice = addInputField(box, "Kwota (zł):", String.format(Locale.US, "%.2f", item.priceGross))
        val etTripKm = addInputField(box, "Dystans kursu (km):", String.format(Locale.US, "%.1f", item.tripKm))
        val etPickupKm = addInputField(box, "Dystans dojazdu (km):", String.format(Locale.US, "%.1f", item.pickupKm))
        val etDest = addInputField(box, "Cel:", item.destination).apply {
            inputType = InputType.TYPE_CLASS_TEXT
        }

        val statuses = arrayOf(
            OfferStatus.ACCEPTED to "Zaakceptowany",
            OfferStatus.REJECTED to "Odrzucony",
            OfferStatus.UNDECIDED to "Bez decyzji",
            OfferStatus.REVIEW to "Ze screena — do oceny"
        )
        var selectedStatus = item.normalizedStatus
        val rg = RadioGroup(this).apply {
            orientation = RadioGroup.VERTICAL
            setPadding(0, dp(10), 0, 0)
        }
        statuses.forEach { (code, label) ->
            val rb = RadioButton(this).apply {
                text = label
                setTextColor(Color.WHITE)
                isChecked = (code == selectedStatus)
                setOnClickListener { selectedStatus = code }
            }
            rg.addView(rb)
        }
        box.addView(rg)

        AlertDialog.Builder(this)
            .setTitle("Edytuj wpis z historii")
            .setView(box)
            .setNegativeButton("Anuluj", null)
            .setPositiveButton("Zapisz") { _, _ ->
                val pVal = etPrice.text.toString().trim().replace(",", ".").toDoubleOrNull()
                if (pVal == null || !pVal.isFinite() || pVal < 0.0) {
                    Toast.makeText(this, "Wpisz poprawną kwotę (zł).", Toast.LENGTH_LONG).show()
                    return@setPositiveButton
                }
                val tKm = etTripKm.text.toString().trim().replace(",", ".").toDoubleOrNull() ?: item.tripKm
                val pKm = etPickupKm.text.toString().trim().replace(",", ".").toDoubleOrNull() ?: item.pickupKm
                val destVal = etDest.text.toString().trim().ifEmpty { item.destination }
                val newGrosze = plnToGrosze(pVal)
                val newPricePln = groszeToPln(newGrosze)
                val newRateC = if (tKm > 0.0) newPricePln / tKm else 0.0
                val newRateP = if (pKm > 0.0 && (tKm + pKm) > 0.0) newPricePln / (tKm + pKm) else 0.0

                val updated = item.copy(
                    priceGrosze = newGrosze,
                    tripKm = tKm.coerceAtLeast(0.0),
                    pickupKm = pKm.coerceAtLeast(0.0),
                    destination = destVal,
                    status = selectedStatus,
                    rateCourse = newRateC,
                    rateWithPickup = newRateP
                )
                val list = RadarStorage.getHistory(this)
                val idx = list.indexOfFirst { it.id == item.id }
                if (idx >= 0) {
                    list[idx] = updated
                    RadarStorage.saveHistory(this, list)
                }
                Toast.makeText(this, "Zapisano poprawki wpisu.", Toast.LENGTH_SHORT).show()
                refreshCurrentTab()
            }
            .show()
    }

    private fun buildThresholdsView(): View {
        val scroll = ScrollView(this)

        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(20), dp(16), dp(28))
        }

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = roundedBox("#101827", 24f, "#24344E")
            setPadding(dp(18), dp(18), dp(18), dp(18))
        }

        fun addHeading(label: String) {
            card.addView(TextView(this@MainActivity).apply {
                text = label
                textSize = 18f
                setTextColor(Color.WHITE)
                typeface = Typeface.DEFAULT_BOLD
                setPadding(0, dp(14), 0, dp(8))
            })
        }

        addHeading("Sam kurs — lewa stawka")

        val tripGreen = addInputField(
            card,
            "Zielony od (zł/km):",
            RadarStorage.getGreenKmRate(this).toString()
        )

        val tripYellow = addInputField(
            card,
            "Żółty od (zł/km):",
            RadarStorage.getYellowKmRate(this).toString()
        )

        addHeading("Z dolotem — prawa stawka")

        val pickupGreen = addInputField(
            card,
            "Zielony od (zł/km):",
            RadarStorage.getPickupGreenKmRate(this).toString()
        )

        val pickupYellow = addInputField(
            card,
            "Żółty od (zł/km):",
            RadarStorage.getPickupYellowKmRate(this).toString()
        )

        card.addView(TextView(this).apply {
            text = "Poniżej progu żółtego stawka będzie czerwona."
            textSize = 13f
            setTextColor(Color.parseColor("#8A99B5"))
            setPadding(0, dp(14), 0, dp(8))
        })

        card.addView(Button(this).apply {
            text = "Zapisz progi obu stawek"
            setTextColor(Color.parseColor("#041E14"))
            typeface = Typeface.DEFAULT_BOLD
            background = roundedBox("#2CE574", 18f)

            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                topMargin = dp(16)
            }

            setOnClickListener {
                fun readValue(field: EditText): Float? =
                    field.text.toString()
                        .trim()
                        .replace(",", ".")
                        .toFloatOrNull()

                val tg = readValue(tripGreen)
                val ty = readValue(tripYellow)
                val pg = readValue(pickupGreen)
                val py = readValue(pickupYellow)

                if (
                    tg == null || ty == null ||
                    pg == null || py == null
                ) {
                    Toast.makeText(
                        this@MainActivity,
                        "Wpisz poprawne liczby we wszystkich polach.",
                        Toast.LENGTH_LONG
                    ).show()
                    return@setOnClickListener
                }

                if (
                    !tg.isFinite() || !ty.isFinite() ||
                    !pg.isFinite() || !py.isFinite() ||
                    tg <= 0f || ty <= 0f ||
                    pg <= 0f || py <= 0f ||
                    tg <= ty || pg <= py
                ) {
                    Toast.makeText(
                        this@MainActivity,
                        "Progi muszą być dodatnie. Zielony musi być wyższy od żółtego.",
                        Toast.LENGTH_LONG
                    ).show()
                    return@setOnClickListener
                }

                RadarStorage.saveRateThresholds(
                    this@MainActivity,
                    tg,
                    ty,
                    pg,
                    py
                )

                Toast.makeText(
                    this@MainActivity,
                    "Zapisano osobne progi obu stawek.",
                    Toast.LENGTH_SHORT
                ).show()
            }
        })

        container.addView(card)
        scroll.addView(container)
        return scroll
    }

    private fun buildSettingsView(): View {
        val scroll = ScrollView(this)
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(20), dp(16), dp(28))
        }

        val readingCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = roundedBox("#101827", 24f, "#24344E")
            setPadding(dp(18), dp(18), dp(18), dp(18))

            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = dp(16)
            }
        }

        readingCard.addView(TextView(this).apply {
            text = "Odczyt ekranu i historia"
            textSize = 18f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        })

        readingCard.addView(CheckBox(this).apply {
            text = "Zapisuj historię"
            textSize = 15f
            setTextColor(Color.WHITE)
            isChecked = RadarOptions.historyEnabled(this@MainActivity)

            setOnCheckedChangeListener { _, checked ->
                RadarOptions.setHistoryEnabled(this@MainActivity, checked)
            }
        })

        readingCard.addView(CheckBox(this).apply {
            text = "Pokaż zakładkę Rozliczenia"
            textSize = 15f
            setTextColor(Color.WHITE)
            isChecked = RadarOptions.settlementsTabEnabled(this@MainActivity)

            setOnCheckedChangeListener { _, checked ->
                RadarOptions.setSettlementsTabEnabled(this@MainActivity, checked)
                switchTab(if (!checked && currentTab == "rozliczenia") "start" else currentTab)
            }
        })

        readingCard.addView(TextView(this).apply {
            text = "Wyłączenie zatrzymuje zapis nowych wpisów. " +
                "Nie usuwa dotychczasowej historii."
            textSize = 12f
            setTextColor(Color.parseColor("#9BA9C2"))
            setPadding(0, 0, 0, dp(12))
        })

        val fastId = View.generateViewId()
        val normalId = View.generateViewId()

        val readingModes = RadioGroup(this).apply {
            orientation = RadioGroup.VERTICAL
        }

        readingModes.addView(RadioButton(this).apply {
            id = fastId
            text = "Szybszy odczyt + weryfikacja"
            textSize = 15f
            setTextColor(Color.WHITE)
        })

        readingModes.addView(RadioButton(this).apply {
            id = normalId
            text = "Standardowy odczyt"
            textSize = 15f
            setTextColor(Color.WHITE)
        })

        readingModes.check(
            if (RadarOptions.fastReadEnabled(this)) fastId else normalId
        )

        readingModes.setOnCheckedChangeListener { _, id ->
            RadarOptions.setFastReadEnabled(
                this@MainActivity,
                id == fastId
            )
        }

        readingCard.addView(readingModes)

        readingCard.addView(TextView(this).apply {
            text = "Szybszy odczyt + weryfikacja: najpierw szybki wynik wstępny, " +
                "następnie odczyt w pełnej rozdzielczości sprawdzający cenę i dystanse.\n" +
                "Standardowy odczyt: od początku pełna rozdzielczość; " +
                "nowa oferta jest pokazywana po potwierdzeniu odczytu.\n" +
                "Oba tryby odczytują screeny widoczne w innych aplikacjach."
            textSize = 12f
            setTextColor(Color.parseColor("#9BA9C2"))
            setPadding(0, dp(8), 0, 0)
        })

        container.addView(readingCard)

        val modeCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = roundedBox("#101827", 24f, "#24344E")
            setPadding(dp(18), dp(18), dp(18), dp(18))
        }
        modeCard.addView(TextView(this).apply {
            text = "Wygląd wyskakującego okienka"
            textSize = 18f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        })

        val chkDual = CheckBox(this).apply {
            text = "Pokazuj dwie kwoty obok siebie:\nLewa: zł/km za sam kurs | Prawa: zł/km z dojazdem"
            setTextColor(Color.WHITE)
            textSize = 14f
            isChecked = RadarStorage.isDualRateEnabled(this@MainActivity)
            setPadding(0, dp(10), 0, dp(12))
            setOnCheckedChangeListener { _, checked ->
                RadarStorage.setDualRateEnabled(this@MainActivity, checked)
                Toast.makeText(this@MainActivity, if (checked) "Włączono widok dwóch stawek obok siebie" else "Włączono widok jednej stawki", Toast.LENGTH_SHORT).show()
            }
        }
        modeCard.addView(chkDual)

        val currentScale = RadarStorage.getOverlayScale(this)
        modeCard.addView(TextView(this).apply {
            text = "Skalowanie wielkości okienka (aktualnie: ${(currentScale * 100).toInt()}%):"
            textSize = 14f
            setTextColor(Color.parseColor("#3DDC84"))
            setPadding(0, dp(4), 0, dp(10))
        })

        val scales = listOf(
            0.80f to "Małe (80%)",
            1.00f to "Standardowe (100%)",
            1.20f to "Powiększone (120%)",
            1.40f to "Duże (140%)"
        )
        scales.forEach { (sc, label) ->
            val sel = abs(currentScale - sc) < 0.05f
            modeCard.addView(Button(this).apply {
                text = if (sel) "✓ $label" else label
                setTextColor(if (sel) Color.parseColor("#041E14") else Color.WHITE)
                background = roundedBox(if (sel) "#2CE574" else "#1B2942", 16f, if (sel) "#2CE574" else "#32486E")
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(8) }
                setOnClickListener {
                    RadarStorage.setOverlayScale(this@MainActivity, sc)
                    refreshCurrentTab()
                }
            })
        }
        container.addView(modeCard)

        val permCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = roundedBox("#101827", 24f, "#24344E")
            setPadding(dp(18), dp(18), dp(18), dp(18))
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(16) }
        }
        permCard.addView(TextView(this).apply {
            text = "Uprawnienia (Nakładka, Odczyt ekranu, GPS)"
            textSize = 17f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 0, 0, dp(10))
        })
        permCard.addView(Button(this).apply {
            text = "1. Zezwól na wyświetlanie nad innymi aplikacjami"
            setTextColor(Color.WHITE)
            background = roundedBox("#1B2942", 16f, "#38B6FF")
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(8) }
            setOnClickListener {
                try {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                } catch (_: Exception) {}
            }
        })
        permCard.addView(Button(this).apply {
            text = "2. Włącz Usługę Odczytu Ekranu (Ułatwienia dostępu)"
            setTextColor(Color.WHITE)
            background = roundedBox("#1B2942", 16f, "#38B6FF")
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(8) }
            setOnClickListener {
                try {
                    startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                } catch (_: Exception) {}
            }
        })
        permCard.addView(Button(this).apply {
            text = "3. Zezwól na dostęp do GPS (Licznik km)"
            setTextColor(Color.WHITE)
            background = roundedBox("#1B2942", 16f, "#38B6FF")
            setOnClickListener {
                ActivityCompat.requestPermissions(this@MainActivity, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), 101)
            }
        })
        val btnBg = Button(this).apply {
            text = "Lokalizacja: ustaw Zawsze zezwalaj (potrzebne w tle)"
            setTextColor(Color.WHITE)
            background = roundedBox("#1B2942", 16f, "#38B6FF")
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(16) }
            setOnClickListener {
                try {
                    startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
                } catch (_: Exception) {}
            }
        }
        container.addView(permCard)
        container.addView(btnBg)

        val dbgPrefs = this@MainActivity.getSharedPreferences("KursRadarDebug", Context.MODE_PRIVATE)
        val dbgCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = roundedBox("#101827", 24f, "#24344E")
            setPadding(dp(18), dp(18), dp(18), dp(18))
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(16) }
        }
        dbgCard.addView(TextView(this).apply {
            text = "Diagnostyka odczytu i OCR"
            textSize = 15f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        })
        dbgCard.addView(TextView(this).apply {
            text = dbgPrefs.getString("ocr_performance", "Brak pomiaru OCR") ?: "Brak pomiaru OCR"
            textSize = 12f
            setTextColor(Color.parseColor("#C2D1E5"))
            setTextIsSelectable(true)
            setPadding(0, dp(8), 0, dp(8))
        })
        dbgCard.addView(TextView(this).apply {
            text = dbgPrefs.getString("last_text", "(jeszcze nic nie odczytano)") ?: ""
            textSize = 11f
            setTextColor(Color.parseColor("#8A99B5"))
            setTextIsSelectable(true)
        })
        container.addView(dbgCard)

        scroll.addView(container)
        return scroll
    }

    private fun twoCols(left: View, right: View): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(12) }
            left.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { rightMargin = dp(6) }
            right.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = dp(6) }
            addView(left)
            addView(right)
        }
    }

    private fun statTile(label: String, value: String, colorHex: String): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = roundedBox("#101929", 22f, "#22324C")
            setPadding(dp(16), dp(16), dp(16), dp(16))
            addView(TextView(this@MainActivity).apply { text = label; textSize = 13f; setTextColor(Color.parseColor("#99AABB")) })
            addView(TextView(this@MainActivity).apply {
                text = value; textSize = 21f; setTextColor(Color.parseColor(colorHex)); typeface = Typeface.DEFAULT_BOLD; setPadding(0, dp(6), 0, 0)
            })
        }
    }

    private fun addInputField(parent: LinearLayout, label: String, initVal: String): EditText {
        parent.addView(TextView(this).apply { text = label; textSize = 13f; setTextColor(Color.parseColor("#99AABB")); setPadding(0, dp(10), 0, dp(4)) })
        val et = EditText(this).apply {
            setText(initVal); setTextColor(Color.WHITE); inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            background = roundedBox("#162338", 14f, "#32486E"); setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        parent.addView(et)
        return et
    }

    private fun roundedBox(fillHex: String, radiusDp: Float, strokeHex: String? = null): GradientDrawable {
        return GradientDrawable().apply {
            setColor(Color.parseColor(fillHex))
            cornerRadius = dp(radiusDp.toInt()).toFloat()
            if (strokeHex != null) setStroke(dp(1), Color.parseColor(strokeHex))
        }
    }

    private fun dp(v: Int): Int = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics).toInt()
}
