package com.example.kalkulatorkursow

import android.content.Context

object RadarOptions {
    private const val PREFS = "KursRadarOptions"

    private fun prefs(ctx: Context) =
        ctx.applicationContext.getSharedPreferences(
            PREFS,
            Context.MODE_PRIVATE
        )

    fun historyEnabled(ctx: Context): Boolean =
        prefs(ctx).getBoolean("history_enabled", true)

    fun setHistoryEnabled(ctx: Context, enabled: Boolean) {
        prefs(ctx).edit()
            .putBoolean("history_enabled", enabled)
            .apply()
    }

    fun fastReadEnabled(ctx: Context): Boolean =
        prefs(ctx).getBoolean("fast_read_enabled", true)

    fun setFastReadEnabled(ctx: Context, enabled: Boolean) {
        prefs(ctx).edit()
            .putBoolean("fast_read_enabled", enabled)
            .apply()
    }
}
