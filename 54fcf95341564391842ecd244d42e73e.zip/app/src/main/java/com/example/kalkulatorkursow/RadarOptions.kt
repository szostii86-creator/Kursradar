package com.example.kalkulatorkursow

import android.content.Context

object RadarOptions {
    private const val PREFS = "KursRadarOptions"

    private fun prefs(ctx: Context) =
        ctx.applicationContext.getSharedPreferences(
            PREFS,
            Context.MODE_PRIVATE
        )

    fun historyEnabled(ctx: Context): Boolean =
        prefs(ctx).getBoolean("history_enabled", true)

    fun setHistoryEnabled(ctx: Context, enabled: Boolean) {
        prefs(ctx).edit()
            .putBoolean("history_enabled", enabled)
            .apply()
    }

    fun fastReadEnabled(ctx: Context): Boolean =
        prefs(ctx).getBoolean("fast_read_enabled", true)

    fun setFastReadEnabled(ctx: Context, enabled: Boolean) {
        prefs(ctx).edit()
            .putBoolean("fast_read_enabled", enabled)
            .apply()
    }

    fun driverSharePercent(ctx: Context): Float {
        val v = prefs(ctx).getFloat("driver_share_percent", 50.0f)
        if (!v.isFinite() || v < 45.0f || v > 55.0f) return 50.0f
        return v
    }

    fun setDriverSharePercent(ctx: Context, percent: Float) {
        val clamped = if (!percent.isFinite()) 50.0f else percent.coerceIn(45.0f, 55.0f)
        prefs(ctx).edit()
            .putFloat("driver_share_percent", clamped)
            .apply()
    }

    fun settlementsTabEnabled(ctx: Context): Boolean =
        prefs(ctx).getBoolean("settlements_tab_enabled", false)

    fun setSettlementsTabEnabled(ctx: Context, enabled: Boolean) {
        prefs(ctx).edit()
            .putBoolean("settlements_tab_enabled", enabled)
            .apply()
    }

    fun tripTimeEnabled(ctx: Context): Boolean =
        prefs(ctx).getBoolean("trip_time_enabled", true)

    fun setTripTimeEnabled(ctx: Context, enabled: Boolean) {
        prefs(ctx).edit()
            .putBoolean("trip_time_enabled", enabled)
            .apply()
    }

    fun calcMode(ctx: Context): String {
        val m = prefs(ctx).getString("calc_mode", "bolt") ?: "bolt"
        return if (m == "csv") "csv" else "bolt"
    }

    fun setCalcMode(ctx: Context, mode: String) {
        val clean = if (mode == "csv") "csv" else "bolt"
        prefs(ctx).edit()
            .putString("calc_mode", clean)
            .apply()
    }
}
