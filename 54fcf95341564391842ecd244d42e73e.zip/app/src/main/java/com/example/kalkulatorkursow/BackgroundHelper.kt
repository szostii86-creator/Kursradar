package com.example.kalkulatorkursow

import android.annotation.SuppressLint
import android.app.ActivityManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object BackgroundHelper {

    fun isIgnoringBatteryOptimizations(ctx: Context): Boolean {
        val pm = ctx.getSystemService(Context.POWER_SERVICE) as? PowerManager ?: return false
        return pm.isIgnoringBatteryOptimizations(ctx.packageName)
    }

    @SuppressLint("BatteryLife")
    fun requestIgnoreBatteryOptimizations(ctx: Context) {
        try {
            ctx.startActivity(
                Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                    .setData(Uri.parse("package:${ctx.packageName}"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (_: Exception) {
            openAppDetails(ctx)
        }
    }

    fun openAppDetails(ctx: Context) {
        try {
            ctx.startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                    .setData(Uri.parse("package:${ctx.packageName}"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (_: Exception) {
        }
    }

    fun manufacturerHint(): String {
        val m = Build.MANUFACTURER.lowercase(Locale.ROOT)
        return when {
            m.contains("xiaomi") || m.contains("redmi") || m.contains("poco") ->
                "Xiaomi / HyperOS: 1) Autostart w tle -> włącz. 2) Oszczędzanie baterii -> Bez ograniczeń. 3) Zablokuj aplikację kłódką w ostatnich."
            m.contains("samsung") ->
                "Samsung: 1) Bateria aplikacji -> Bez ograniczeń. 2) Wyłącz usypianie nieużywanych aplikacji. 3) Dodaj do Nigdy nie usypiane."
            m.contains("realme") || m.contains("oppo") || m.contains("oneplus") ->
                "Realme: 1) Użycie baterii -> Zezwalaj na aktywność w tle. 2) Zezwalaj na autostart. 3) Wyłącz Wstrzymaj aktywność."
            else -> "Ustaw baterię aplikacji na Bez ograniczeń i włącz autostart, jeśli telefon ma taką opcję."
        }
    }

    fun openOemSettings(ctx: Context) {
        val m = Build.MANUFACTURER.lowercase(Locale.ROOT)
        val candidates = mutableListOf<ComponentName>()
        if (m.contains("xiaomi") || m.contains("redmi") || m.contains("poco")) {
            candidates += ComponentName("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity")
        }
        if (m.contains("realme") || m.contains("oppo")) {
            candidates += ComponentName("com.coloros.safecenter", "com.coloros.safecenter.permission.startup.StartupAppListActivity")
            candidates += ComponentName("com.oplus.battery", "com.oplus.powermanager.fuelgaue.PowerUsageModelActivity")
        }
        for (c in candidates) {
            try {
                ctx.startActivity(Intent().setComponent(c).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                return
            } catch (_: Exception) {
            }
        }
        openAppDetails(ctx)
    }

    fun saveLastExitReasons(ctx: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return
        try {
            val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val list = am.getHistoricalProcessExitReasons(ctx.packageName, 0, 5)
            val fmt = SimpleDateFormat("dd.MM HH:mm:ss", Locale.getDefault())
            val text = list.joinToString("\n") {
                "${fmt.format(Date(it.timestamp))} | ${reasonName(it.reason)} | ${it.description ?: "-"}"
            }.ifBlank { "brak danych o zakończeniach" }
            ctx.getSharedPreferences("KursRadarDebug", Context.MODE_PRIVATE)
                .edit().putString("last_exit_reasons", text).apply()
        } catch (_: Exception) {
        }
    }

    private fun reasonName(r: Int): String = when (r) {
        1 -> "EXIT_SELF"
        2 -> "SIGNALED (zabity przez system/OEM)"
        3 -> "LOW_MEMORY"
        4 -> "CRASH"
        5 -> "CRASH_NATIVE"
        6 -> "ANR"
        7 -> "INIT_FAILURE"
        8 -> "PERMISSION_CHANGE"
        9 -> "EXCESSIVE_RESOURCE_USAGE"
        10 -> "USER_REQUESTED"
        11 -> "USER_STOPPED"
        12 -> "DEPENDENCY_DIED"
        13 -> "OTHER"
        else -> "KOD_$r"
    }
}
