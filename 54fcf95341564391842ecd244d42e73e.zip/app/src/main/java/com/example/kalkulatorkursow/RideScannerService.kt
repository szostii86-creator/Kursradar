package com.example.kalkulatorkursow

import android.Manifest
import android.accessibilityservice.AccessibilityService
import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.pm.ServiceInfo
import android.os.Build
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.provider.Settings
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale
import java.util.UUID
import java.util.concurrent.Executors
import kotlin.math.abs

class RideScannerService : AccessibilityService() {

    companion object {
        @Volatile
        var isConnected: Boolean = false

        @Volatile
        var lastTickElapsedMs: Long = 0L

        @Volatile
        private var instance: RideScannerService? = null

        fun pingFromWatchdog() {
            val svc = instance ?: return
            val now = SystemClock.elapsedRealtime()
            if (now - lastTickElapsedMs > 2500L) {
                try {
                    svc.mainHandler.removeCallbacks(svc.tick)
                    svc.mainHandler.post(svc.tick)
                } catch (_: Exception) {
                }
            }
        }
    }

    private val testScreenow = false
    private var screenshotCooldownUntilMs = 0L
    private var lastWorkServiceEnsureMs = 0L

    private val channelId = "kursradar_session"
    private var notifChannelCreated = false
    private var notifShown = false
    private var lastNotifUpdateMs = 0L
    private var wakeLock: PowerManager.WakeLock? = null
    private var lastWakeRenewMs = 0L
    private var lastFgTryMs = 0L
    private var fgActive = false

    private var windowManager: WindowManager? = null
    private var overlayRoot: LinearLayout? = null
    private lateinit var tvStatusHeader: TextView
    private lateinit var tvRateCourseLeft: TextView
    private lateinit var tvLabelCourseLeft: TextView
    private lateinit var rightRateColumn: LinearLayout
    private lateinit var tvRateWithPickupRight: TextView
    private lateinit var tvLabelWithPickupRight: TextView
    private lateinit var tvOfferLine: TextView
    private lateinit var tvDistanceLine: TextView
    private lateinit var tvDestLine: TextView
    private lateinit var tvResizeHandle: TextView
    private lateinit var bgBox: GradientDrawable

    private val overlayParams = WindowManager.LayoutParams(
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
        PixelFormat.TRANSLUCENT
    ).apply {
        gravity = Gravity.TOP or Gravity.START
        x = 30
        y = 140
    }

    private var isAttached = false
    private var recognizer: TextRecognizer? = null
    private val executor = Executors.newSingleThreadExecutor()
    private val netExecutor = Executors.newSingleThreadExecutor()
    private val mainHandler = Handler(Looper.getMainLooper())

    private enum class ScanStage {
        WAITING,
        QUICK_SCAN,
        FULL_VERIFY,
        VERIFIED
    }

    @Volatile
    private var isScanning = false
    private var scanStartedAtMs = 0L
    private var lastScanMs = 0L
    private var cachedHomeLauncherPkg: String? = null
    private var homeLauncherResolved = false

    // Stan sesji odczytu (rozdzielony między LIVE_BOLT a EXTERNAL_SCREEN)
    private var currentOffer: RideEntry? = null
    private var currentSessionId: String? = null
    private var currentOfferFirstSeenMs: Long = 0L
    private var currentOfferLastSeenMs: Long = 0L
    private var currentOfferAccepted: Boolean = false
    private var currentOfferCountedInSession: Boolean = false
    private var currentOfferCountedGrosze: Long = 0L
    private var currentOfferVerified: Boolean = false
    private var scanStage: ScanStage = ScanStage.WAITING
    private var pendingFullVerify: Boolean = false
    private var activeFastModeSetting: Boolean = true

    private var currentScheduled = false
    private var currentPickupAddr: Pair<String, String>? = null

    private var parsedScheduled = false
    private var parsedPickupAddr: Pair<String, String>? = null
    private var candidateKey = ""
    private var missingScans = 0

    private var pendingOffer: RideEntry? = null
    private var pendingSessionId: String? = null
    private var pendingOfferCounted: Boolean = false
    private var pendingOfferCountedGrosze: Long = 0L
    private var decisionDeadline = 0L

    private var universalExternalSource = false
    private var universalSourcePackage: String? = null
    private var universalImageCandidate = ""
    private val universalSavedImages = linkedSetOf<String>()

    private var lastDebugError = "brak"

    private var locationManager: LocationManager? = null
    private var locationActive = false
    private var lastLoc: Location? = null
    private var countLast: Location? = null
    private val geoCache = HashMap<String, DoubleArray>()
    private var pickupKey = ""
    private var pickupState = ""
    private var pickupFromGps = false
    private var lastPickupTryMs = 0L

    private var currentStopAddrs: List<Pair<String, String>> = emptyList()
    private var currentStopCount: Int = 0
    private var tripTimeKey = ""
    private var tripTimeState = ""
    private var tripDurationMin = -1
    private var returnDurationMin = 0

    private val acceptLabelRegex = Regex(
        pattern = """\b(?:akceptuj(?:ę|e)?|przyjm(?:ij|uję|uje))\b""",
        option = RegexOption.IGNORE_CASE
    )
    private val rejectLabelRegex = Regex(
        pattern = """\b(?:odrzuć|odrzuc|odrzućcie|odmów|odmow|pomiń|pomin)\b""",
        option = RegexOption.IGNORE_CASE
    )

    private val locListener = object : LocationListener {
        override fun onLocationChanged(location: Location) {
            lastLoc = location
            if (!RadarStorage.isSessionRunning(this@RideScannerService)) return
            if (location.hasAccuracy() && location.accuracy > 35f) return
            val prev = countLast
            if (prev != null) {
                val d = prev.distanceTo(location)
                val dtSec = ((location.time - prev.time) / 1000.0).coerceAtLeast(1.0)
                val speedMps = d / dtSec
                if (d >= 3.0f && d <= 15_000f && speedMps <= 55.6) {
                    RadarStorage.addGpsDistanceMeters(this@RideScannerService, d)
                }
            }
            countLast = location
        }
    }

    private val tick = object : Runnable {
        override fun run() {
            lastTickElapsedMs = SystemClock.elapsedRealtime()
            try {
                if (RadarStorage.isSessionRunning(this@RideScannerService)) {
                    if (WorkSessionService.isRunning) {
                        stopLocation()
                        clearNotification()
                    } else {
                        val now = SystemClock.elapsedRealtime()
                        if (now - lastWorkServiceEnsureMs > 10_000L) {
                            lastWorkServiceEnsureMs = now
                            WorkSessionService.start(this@RideScannerService)
                        }
                        startLocation()
                        updateNotification()
                    }
                    requestScan()
                } else {
                    stopLocation()
                    clearNotification()
                    resetAll()
                }
            } catch (e: Exception) {
                lastDebugError = e.message ?: "tick error"
            }
            mainHandler.postDelayed(this, 350L)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        isConnected = true
        instance = this
        lastTickElapsedMs = SystemClock.elapsedRealtime()
        BackgroundHelper.saveLastExitReasons(this)
        try {
            recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
            windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
            locationManager = getSystemService(LOCATION_SERVICE) as? LocationManager
            createOverlay()
            if (RadarStorage.isSessionRunning(this) && !WorkSessionService.isRunning) {
                WorkSessionService.start(this)
            }
            mainHandler.removeCallbacks(tick)
            mainHandler.post(tick)
        } catch (e: Exception) {
            lastDebugError = e.message ?: "onServiceConnected error"
        }
    }

    @SuppressLint("WakelockTimeout")
    private fun acquireWakeLock() {
        try {
            val now = SystemClock.elapsedRealtime()
            if (wakeLock?.isHeld == true && now - lastWakeRenewMs < 5 * 60_000L) return
            if (wakeLock == null) {
                val pm = getSystemService(POWER_SERVICE) as? PowerManager
                wakeLock = pm?.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "ScanBolt::SessionWakeLock")
                    ?.apply { setReferenceCounted(false) }
            }
            wakeLock?.acquire(10 * 60_000L)
            lastWakeRenewMs = now
        } catch (e: Exception) {
            lastDebugError = "wakelock: ${e.message}"
        }
    }

    private fun releaseWakeLock() {
        try {
            if (wakeLock?.isHeld == true) wakeLock?.release()
        } catch (_: Exception) {
        }
    }

    private fun tryStartForeground(n: Notification): Boolean {
        val id = 7002
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            val types = mutableListOf<Int>()
            if (hasLocationPermission()) types += ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION
            types += ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            for (t in types) {
                try {
                    startForeground(id, n, t)
                    return true
                } catch (e: Exception) {
                    lastDebugError = "startForeground type=$t: ${e.javaClass.simpleName} ${e.message}"
                }
            }
            return false
        }
        return try {
            startForeground(id, n)
            true
        } catch (e: Exception) {
            lastDebugError = "startForeground: ${e.javaClass.simpleName} ${e.message}"
            false
        }
    }

    private fun updateNotification() {
        try {
            acquireWakeLock()
            val now = SystemClock.elapsedRealtime()
            if (notifShown && now - lastNotifUpdateMs < 2000L) return
            lastNotifUpdateMs = now

            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            if (!notifChannelCreated) {
                nm.createNotificationChannel(NotificationChannel(channelId, "Praca kierowcy", NotificationManager.IMPORTANCE_LOW))
                notifChannelCreated = true
            }
            val start = RadarStorage.getSessionStartTime(this)
            val sec = ((System.currentTimeMillis() - start) / 1000L).coerceAtLeast(0L)
            val time = String.format(Locale.US, "%02d:%02d:%02d", sec / 3600, (sec % 3600) / 60, sec % 60)
            val km = RadarStorage.getGpsDistanceMeters(this) / 1000.0
            val count = RadarStorage.getSessionAcceptedCount(this)
            val text = String.format(Locale("pl", "PL"), "%s · %.2f km · %d przyjętych", time, km, count)
            val pi = PendingIntent.getActivity(
                this, 0, Intent(this, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val n = Notification.Builder(this, channelId)
                .setSmallIcon(android.R.drawable.ic_menu_compass)
                .setContentTitle("ScanBolt · praca kierowcy")
                .setContentText(text)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setShowWhen(false)
                .setContentIntent(pi)
                .build()

            if (!fgActive) {
                if (now - lastFgTryMs >= 5000L || lastFgTryMs == 0L) {
                    lastFgTryMs = now
                    fgActive = tryStartForeground(n)
                }
                if (!fgActive) nm.notify(7002, n)
                notifShown = true
            } else {
                nm.notify(7002, n)
            }
        } catch (e: Exception) {
            lastDebugError = "updateNotification: ${e.message}"
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_STICKY
    }

    private fun clearNotification() {
        releaseWakeLock()
        if (!notifShown && !fgActive) return
        try {
            stopForeground(STOP_FOREGROUND_REMOVE)
        } catch (_: Exception) {
        }
        try {
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).cancel(7002)
        } catch (_: Exception) {
        }
        notifShown = false
        fgActive = false
        lastFgTryMs = 0L
    }

    private fun hasLocationPermission(): Boolean {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
    }

    private fun startLocation() {
        if (locationActive || !hasLocationPermission()) return
        val lm = locationManager ?: return
        try {
            if (lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 2000L, 4f, locListener)
                locationActive = true
                countLast = null
            }
        } catch (_: Exception) {
        }
    }

    private fun stopLocation() {
        if (!locationActive) return
        try {
            locationManager?.removeUpdates(locListener)
        } catch (_: Exception) {
        }
        locationActive = false
        countLast = null
    }

    private fun currentLocation(): Location? {
        var best: Location? = WorkSessionService.lastKnownLocation ?: lastLoc
        if (lastLoc != null && (best == null || lastLoc!!.time > best.time)) best = lastLoc
        if (hasLocationPermission()) {
            val lm = locationManager
            if (lm != null) {
                for (prov in listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)) {
                    try {
                        val l = lm.getLastKnownLocation(prov)
                        if (l != null && (best == null || l.time > best.time)) best = l
                    } catch (_: Exception) {
                    }
                }
            }
        }
        return best
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun createOverlay() {
        val posPrefs = getSharedPreferences("KursRadarPos", Context.MODE_PRIVATE)
        overlayParams.x = posPrefs.getInt("x", 30)
        overlayParams.y = posPrefs.getInt("y", 140)

        bgBox = GradientDrawable().apply {
            setColor(Color.parseColor("#F50C1821"))
            cornerRadius = 42f
            setStroke(5, Color.parseColor("#3DDC84"))
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = bgBox
            setPadding(36, 26, 36, 26)
            visibility = View.GONE
        }
        tvStatusHeader = TextView(this).apply {
            text = "● DOBRY"
            setTextColor(Color.parseColor("#A3E635"))
            typeface = Typeface.DEFAULT_BOLD
        }
        root.addView(tvStatusHeader)

        val ratesRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 10, 0, 10)
        }
        val leftCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        tvRateCourseLeft = TextView(this).apply {
            text = "0,00 zł/km"
            setTextColor(Color.parseColor("#2CE574"))
            typeface = Typeface.DEFAULT_BOLD
        }
        tvLabelCourseLeft = TextView(this).apply {
            text = "za sam kurs"
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        }
        leftCol.addView(tvRateCourseLeft)
        leftCol.addView(tvLabelCourseLeft)
        rightRateColumn = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 0, 0, 0)
        }
        tvRateWithPickupRight = TextView(this).apply {
            text = "0,00 zł/km"
            setTextColor(Color.parseColor("#38B6FF"))
            typeface = Typeface.DEFAULT_BOLD
        }
        tvLabelWithPickupRight = TextView(this).apply {
            text = "z dolotem"
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        }
        rightRateColumn.addView(tvRateWithPickupRight)
        rightRateColumn.addView(tvLabelWithPickupRight)
        ratesRow.addView(leftCol)
        ratesRow.addView(rightRateColumn)
        root.addView(ratesRow)

        tvOfferLine = TextView(this).apply {
            setTextColor(Color.parseColor("#D5E3F7"))
            typeface = Typeface.DEFAULT_BOLD
        }
        tvDistanceLine = TextView(this).apply {
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        }
        tvDestLine = TextView(this).apply {
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        }
        val maxW = (resources.displayMetrics.widthPixels * 0.90f).toInt()
        tvOfferLine.maxWidth = maxW
        tvDistanceLine.maxWidth = maxW
        tvDestLine.maxWidth = maxW

        tvResizeHandle = TextView(this).apply {
            text = "━━━  ⇕  ━━━"
            textSize = 10f
            gravity = Gravity.CENTER
            setTextColor(Color.parseColor("#7D8FA8"))
            setPadding(0, 8, 0, 2)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }
        var resizeStartY = 0f
        var resizeStartScale = 1.0f
        tvResizeHandle.setOnTouchListener { _, ev ->
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> {
                    resizeStartY = ev.rawY
                    resizeStartScale = RadarStorage.getOverlayScale(this)
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dy = ev.rawY - resizeStartY
                    val nextScale = (resizeStartScale + dy / 260f).coerceIn(0.75f, 1.55f)
                    RadarStorage.setOverlayScale(this, nextScale)
                    currentOffer?.let { showOffer(it) }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    true
                }
                else -> false
            }
        }

        root.addView(tvOfferLine)
        root.addView(tvDistanceLine)
        root.addView(tvDestLine)
        root.addView(tvResizeHandle)

        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        root.setOnTouchListener { _, ev ->
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = overlayParams.x
                    startY = overlayParams.y
                    touchX = ev.rawX
                    touchY = ev.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    overlayParams.x = startX + (ev.rawX - touchX).toInt()
                    overlayParams.y = startY + (ev.rawY - touchY).toInt()
                    if (isAttached) {
                        try {
                            windowManager?.updateViewLayout(root, overlayParams)
                        } catch (_: Exception) {
                        }
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    posPrefs.edit().putInt("x", overlayParams.x).putInt("y", overlayParams.y).apply()
                    true
                }
                else -> false
            }
        }
        overlayRoot = root
    }

    private fun ensureAttached() {
        val root = overlayRoot ?: return
        if (isAttached) return
        if (!Settings.canDrawOverlays(this)) return
        try {
            windowManager?.addView(root, overlayParams)
            isAttached = true
        } catch (_: Exception) {
        }
    }

    private fun hideOverlay() {
        overlayRoot?.visibility = View.GONE
    }

    private fun resetAll() {
        hideOverlay()
        currentOffer = null
        currentSessionId = null
        currentOfferFirstSeenMs = 0L
        currentOfferLastSeenMs = 0L
        currentOfferAccepted = false
        currentOfferCountedInSession = false
        currentOfferCountedGrosze = 0L
        currentOfferVerified = false
        scanStage = ScanStage.WAITING
        pendingFullVerify = false
        pendingOffer = null
        pendingSessionId = null
        pendingOfferCounted = false
        pendingOfferCountedGrosze = 0L
        missingScans = 0
        candidateKey = ""
        universalImageCandidate = ""
        pickupState = ""
    }

    private fun universalVisiblePackage(): String? {
        return try {
            rootInActiveWindow?.packageName?.toString()
        } catch (_: Exception) {
            null
        }
    }

    private fun universalIsDriver(pkg: String?): Boolean {
        return pkg == "ee.mtakso.driver" || (pkg != null && pkg.startsWith("ee.mtakso.driver."))
    }

    private fun universalImageKey(offer: RideEntry): String {
        return listOf(
            offer.priceGrosze.toString(),
            String.format(Locale.US, "%.1f", offer.tripKm),
            String.format(Locale.US, "%.1f", offer.pickupKm),
            offer.destination.trim().lowercase(Locale.ROOT)
        ).joinToString("|")
    }

    private fun isLikelySameOfferDespiteInitialOcrError(old: RideEntry, incoming: RideEntry): Boolean {
        val distClose = abs(old.tripKm - incoming.tripKm) <= 0.3
        val destSame = old.destination.trim().equals(incoming.destination.trim(), ignoreCase = true)
        val priceClose = abs(old.priceGrosze - incoming.priceGrosze) <= 5000L
        return (distClose && destSame) || (distClose && priceClose)
    }

    private fun universalPrepareBitmap(
        original: Bitmap,
        scaleDown: Boolean
    ): Bitmap {
        val targetWidth = 720
        if (!scaleDown || original.width <= targetWidth) {
            return original
        }
        val targetHeight = (
            original.height.toLong() * targetWidth / original.width
        ).toInt().coerceAtLeast(1)

        return Bitmap.createScaledBitmap(
            original,
            targetWidth,
            targetHeight,
            true
        )
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        if (!RadarStorage.isSessionRunning(this)) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg == packageName) return

        if (event.eventType == AccessibilityEvent.TYPE_VIEW_CLICKED && universalIsDriver(pkg)) {
            try {
                handleClick(event)
            } catch (_: Exception) {
            }
        }
        requestScan()
    }

    private fun handleClick(event: AccessibilityEvent) {
        if (universalExternalSource) return
        if (!universalIsDriver(event.packageName?.toString())) return
        if (currentOffer?.source == "SCREEN") return

        val offer = currentOffer ?: pendingOffer ?: return
        val sessionId = currentSessionId ?: pendingSessionId ?: offer.id

        val sb = StringBuilder()
        for (t in event.text) sb.append(t).append(' ')
        val src = event.source
        if (src != null) {
            src.text?.let { sb.append(it).append(' ') }
            src.contentDescription?.let { sb.append(it).append(' ') }
            if (src.childCount in 1..4) collectNodeText(src, sb, 0)
        }
        val clickedText = sb.toString()

        if (acceptLabelRegex.containsMatchIn(clickedText)) {
            record(offer.copy(id = sessionId), OfferStatus.ACCEPTED)
        } else if (rejectLabelRegex.containsMatchIn(clickedText)) {
            record(offer.copy(id = sessionId), OfferStatus.REJECTED)
        }
    }

    private fun record(offer: RideEntry, status: String) {
        if (universalExternalSource || offer.source == "SCREEN") return
        if (testScreenow) return

        val now = System.currentTimeMillis()
        val normStatus = OfferStatus.normalize(status)
        val targetId = offer.id.ifBlank { currentSessionId ?: pendingSessionId ?: UUID.randomUUID().toString() }
        val isCurrent = (currentSessionId != null && currentSessionId == targetId)
        val isPending = (pendingSessionId != null && pendingSessionId == targetId)

        val wasCounted = when {
            isCurrent -> currentOfferCountedInSession
            isPending -> pendingOfferCounted
            else -> false
        }
        val prevGrosze = when {
            isCurrent -> currentOfferCountedGrosze
            isPending -> pendingOfferCountedGrosze
            else -> 0L
        }

        if (normStatus == OfferStatus.ACCEPTED && isCurrent) {
            currentOfferAccepted = true
        }

        val entryToSave = offer.copy(
            id = targetId,
            timestamp = if (isCurrent && currentOfferFirstSeenMs > 0L) currentOfferFirstSeenMs else offer.timestamp,
            acceptedTimestamp = if (normStatus == OfferStatus.ACCEPTED) now else offer.acceptedTimestamp,
            status = normStatus,
            source = "RADAR"
        )

        val (savedEntry, nowCounted) = RadarStorage.upsertOffer(
            this,
            entryToSave,
            alreadyCountedInSession = wasCounted,
            previousCountedGrosze = prevGrosze
        )

        if (isCurrent) {
            currentOffer = savedEntry
            currentOfferCountedInSession = nowCounted
            if (nowCounted) currentOfferCountedGrosze = savedEntry.priceGrosze
        }
        if (isPending) {
            if (normStatus == OfferStatus.ACCEPTED || normStatus == OfferStatus.REJECTED) {
                pendingOffer = null
                pendingSessionId = null
                pendingOfferCounted = false
                pendingOfferCountedGrosze = 0L
            } else {
                pendingOfferCounted = nowCounted
                if (nowCounted) pendingOfferCountedGrosze = savedEntry.priceGrosze
            }
        }
    }

    private fun collectNodeText(node: AccessibilityNodeInfo?, sb: StringBuilder, depth: Int) {
        if (node == null || depth > 40 || sb.length > 8000) return
        val t = node.text?.toString()
        if (!t.isNullOrBlank()) {
            sb.append(t).append('\n')
        } else {
            val d = node.contentDescription?.toString()
            if (!d.isNullOrBlank()) sb.append(d).append('\n')
        }
        for (i in 0 until node.childCount) {
            collectNodeText(node.getChild(i), sb, depth + 1)
        }
    }

    private fun saveDiagnostics(
        modeLabel: String,
        stageLabel: String,
        sourcePkg: String,
        captureMs: Long,
        prepMs: Long,
        ocrMs: Long,
        totalMs: Long,
        width: Int,
        height: Int,
        verifiedChanged: String,
        snippetText: String?
    ) {
        val perfText = buildString {
            appendLine("Tryb: $modeLabel | Etap: $stageLabel")
            appendLine("Źródło: $sourcePkg | Rozdzielczość OCR: ${width}x${height}")
            appendLine("Zrzut: ${captureMs} ms | Przygotowanie: ${prepMs} ms | OCR: ${ocrMs} ms")
            appendLine("Od startu odczytu do wyniku: ${totalMs} ms")
            appendLine("Zmiana po weryfikacji: $verifiedChanged | Błąd: $lastDebugError")
        }.trim()

        val editor = getSharedPreferences("KursRadarDebug", Context.MODE_PRIVATE).edit()
            .putString("ocr_performance", perfText)

        if (!snippetText.isNullOrBlank() && (snippetText.contains("zł") || snippetText.contains("km"))) {
            editor.putString("last_text", "[$stageLabel | $sourcePkg]\n" + snippetText.take(1500))
        }
        editor.apply()
    }

    private fun resolveHomeLauncherPackage(): String? {
        if (homeLauncherResolved) return cachedHomeLauncherPkg
        homeLauncherResolved = true
        cachedHomeLauncherPkg = try {
            val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
            packageManager.resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName
        } catch (_: Exception) {
            null
        }
        return cachedHomeLauncherPkg
    }

    private fun isIgnoredSystemPackage(pkg: String): Boolean {
        val homePkg = resolveHomeLauncherPackage()
        if (!homePkg.isNullOrBlank() && pkg == homePkg) return true
        return pkg == "com.miui.home" ||
            pkg == "com.android.systemui" ||
            pkg == "com.miui.securitycenter" ||
            pkg == "com.android.settings" ||
            pkg == "com.oppo.launcher" ||
            pkg == "com.sec.android.app.launcher" ||
            pkg == "com.google.android.apps.nexuslauncher" ||
            pkg == "com.android.launcher3"
    }

    private fun requestScan() {
        if (!RadarStorage.isSessionRunning(this)) return

        // Nie skanujemy przy wygaszonym ekranie — oszczędza baterię i chroni przed ubiciem przez HyperOS
        val pm = getSystemService(POWER_SERVICE) as? PowerManager
        if (pm != null && !pm.isInteractive) return

        val rec = recognizer ?: return
        val now = SystemClock.elapsedRealtime()
        val fastSetting = RadarOptions.fastReadEnabled(this)

        // Zmiana trybu w ustawieniach resetuje bieżącą sesję weryfikacji, by nie mieszać wyników
        if (fastSetting != activeFastModeSetting) {
            activeFastModeSetting = fastSetting
            resetAll()
        }

        val root = try {
            rootInActiveWindow
        } catch (_: Exception) {
            null
        }

        val pkg = root?.packageName?.toString()

        // Wykluczamy własny ekran, pulpit i pakiety systemowe (koniec z mieleniem OCR na pulpicie i errorCode=3)
        if (pkg.isNullOrBlank() || pkg == packageName || isIgnoredSystemPackage(pkg)) {
            resetAll()
            universalExternalSource = false
            universalSourcePackage = null
            return
        }

        val external = !universalIsDriver(pkg)

        // Jeżeli jest zaplanowana pełna weryfikacja FULL_VERIFY, ma ona priorytet i krótszy odstęp
        val isVerifyStep = fastSetting && pendingFullVerify && currentOffer != null && !currentOfferVerified
        val intervalMs = when {
            isVerifyStep -> 250L
            external -> 650L
            fastSetting -> 350L
            else -> 600L
        }

        // Bezpiecznik: jeśli system zgubił callback takeScreenshot i isScanning wisi > 3 s, samoczynnie odblokowujemy skaner
        if (isScanning && scanStartedAtMs > 0L && now - scanStartedAtMs > 3000L) {
            isScanning = false
            scanStartedAtMs = 0L
            lastDebugError = "auto-reset isScanning (>3s)"
        }

        // Nie uruchamiamy dwóch zadań OCR równolegle i respektujemy cooldown po errorCode=3
        if (isScanning || now - lastScanMs < intervalMs || now < screenshotCooldownUntilMs) return

        if (universalSourcePackage != pkg) {
            resetAll()
            universalSourcePackage = pkg
        }

        universalExternalSource = external
        lastScanMs = now

        // W prawdziwej aplikacji kierowcy Bolt próbujemy najpierw bezpośredniego odczytu NODE
        if (!external) {
            try {
                val sb = StringBuilder()
                collectNodeText(root, sb, 0)
                val text = sb.toString()

                if (text.length > 20 && parseBoltOffer(text) != null) {
                    scanStage = ScanStage.VERIFIED
                    currentOfferVerified = true
                    pendingFullVerify = false
                    saveDiagnostics(
                        modeLabel = if (fastSetting) "Szybszy + weryfikacja" else "Standardowy",
                        stageLabel = "NODE",
                        sourcePkg = pkg,
                        captureMs = 0L,
                        prepMs = 0L,
                        ocrMs = 0L,
                        totalMs = SystemClock.elapsedRealtime() - now,
                        width = 0,
                        height = 0,
                        verifiedChanged = "nie dotyczy (NODE)",
                        snippetText = text
                    )
                    handleText(text, "NODE", isQuickStage = false, isVerifyStage = false)
                    return
                }
            } catch (_: Exception) {
            }
        }

        var blank: Rect? = null
        val overlay = overlayRoot
        if (
            isAttached &&
            overlay != null &&
            overlay.visibility == View.VISIBLE &&
            overlay.width > 0
        ) {
            val loc = IntArray(2)
            overlay.getLocationOnScreen(loc)
            blank = Rect(
                loc[0] - 12,
                loc[1] - 12,
                loc[0] + overlay.width + 12,
                loc[1] + overlay.height + 12
            )
        }

        val mask = blank
        val capturePackage = pkg
        val captureExternal = external
        val captureFastSetting = fastSetting
        val captureDoQuickScale = captureFastSetting && !isVerifyStep && currentOffer == null
        val captureIsVerifyStep = isVerifyStep
        val captureSessionIdAtStart = currentSessionId
        val scanStartMs = SystemClock.elapsedRealtime()

        scanStage = when {
            captureIsVerifyStep -> ScanStage.FULL_VERIFY
            captureDoQuickScale -> ScanStage.QUICK_SCAN
            else -> ScanStage.FULL_VERIFY
        }

        isScanning = true
        scanStartedAtMs = now

        try {
            takeScreenshot(
                Display.DEFAULT_DISPLAY,
                executor,
                object : TakeScreenshotCallback {
                    override fun onSuccess(screenshot: ScreenshotResult) {
                        var ownedBitmap: Bitmap? = null
                        val captureDoneMs = SystemClock.elapsedRealtime()
                        val captureDuration = captureDoneMs - scanStartMs

                        try {
                            val buffer = screenshot.hardwareBuffer
                            val hardwareBitmap = try {
                                Bitmap.wrapHardwareBuffer(buffer, screenshot.colorSpace)
                            } catch (e: Exception) {
                                buffer.close()
                                throw e
                            }

                            if (hardwareBitmap == null) {
                                buffer.close()
                                isScanning = false
                                return
                            }

                            val copy = try {
                                hardwareBitmap.copy(Bitmap.Config.ARGB_8888, true)
                            } finally {
                                hardwareBitmap.recycle()
                                buffer.close()
                            }

                            if (copy == null) {
                                isScanning = false
                                return
                            }

                            ownedBitmap = copy

                            if (mask != null) {
                                val paint = Paint().apply { color = Color.BLACK }
                                Canvas(copy).drawRect(mask, paint)
                            }

                            val image = universalPrepareBitmap(copy, scaleDown = captureDoQuickScale)
                            ownedBitmap = image
                            if (image !== copy) {
                                copy.recycle()
                            }

                            val prepDoneMs = SystemClock.elapsedRealtime()
                            val prepDuration = prepDoneMs - captureDoneMs
                            val imgW = image.width
                            val imgH = image.height
                            val ocrStartMs = SystemClock.elapsedRealtime()

                            rec.process(InputImage.fromBitmap(image, 0))
                                .addOnSuccessListener { result ->
                                    val ocrEndMs = SystemClock.elapsedRealtime()
                                    val ocrDuration = ocrEndMs - ocrStartMs
                                    val totalDuration = ocrEndMs - scanStartMs

                                    mainHandler.post {
                                        val sessionStillActive = RadarStorage.isSessionRunning(this@RideScannerService)
                                        val samePackage = universalVisiblePackage() == capturePackage
                                        val sameMode = RadarOptions.fastReadEnabled(this@RideScannerService) == captureFastSetting
                                        val sameVerifySession = !captureIsVerifyStep || (currentSessionId == captureSessionIdAtStart)

                                        if (!sessionStillActive || !samePackage || !sameMode || !sameVerifySession) {
                                            return@post
                                        }

                                        universalExternalSource = captureExternal
                                        val stageName = when {
                                            captureDoQuickScale -> "QUICK_SCAN"
                                            captureIsVerifyStep -> "FULL_VERIFY"
                                            else -> "STANDARD"
                                        }

                                        val prevPrice = currentOffer?.priceGrosze
                                        val prevTrip = currentOffer?.tripKm

                                        if (captureExternal) {
                                            universalHandleImage(
                                                raw = result.text,
                                                fastSetting = captureFastSetting,
                                                isQuickStage = captureDoQuickScale,
                                                isVerifyStage = captureIsVerifyStep
                                            )
                                        } else {
                                            handleText(
                                                raw = result.text,
                                                src = "OCR",
                                                isQuickStage = captureDoQuickScale,
                                                isVerifyStage = captureIsVerifyStep
                                            )
                                        }

                                        val changedInfo = if (captureIsVerifyStep && prevPrice != null && currentOffer != null) {
                                            val pChanged = prevPrice != currentOffer!!.priceGrosze
                                            val dChanged = prevTrip != null && abs(prevTrip - currentOffer!!.tripKm) > 0.05
                                            when {
                                                pChanged || dChanged -> "tak (skorygowano po pełnym OCR)"
                                                else -> "nie (potwierdzono)"
                                            }
                                        } else {
                                            "—"
                                        }

                                        saveDiagnostics(
                                            modeLabel = if (captureFastSetting) "Szybszy + weryfikacja" else "Standardowy",
                                            stageLabel = stageName,
                                            sourcePkg = capturePackage,
                                            captureMs = captureDuration,
                                            prepMs = prepDuration,
                                            ocrMs = ocrDuration,
                                            totalMs = totalDuration,
                                            width = imgW,
                                            height = imgH,
                                            verifiedChanged = changedInfo,
                                            snippetText = result.text
                                        )
                                    }
                                }
                                .addOnFailureListener { e ->
                                    lastDebugError = e.message ?: "OCR failure"
                                }
                                .addOnCompleteListener {
                                    if (!image.isRecycled) {
                                        image.recycle()
                                    }
                                    isScanning = false
                                }

                            ownedBitmap = null
                        } catch (e: Exception) {
                            lastDebugError = e.message ?: "screenshot processing error"
                            ownedBitmap?.let {
                                if (!it.isRecycled) it.recycle()
                            }
                            isScanning = false
                        }
                    }

                    override fun onFailure(errorCode: Int) {
                        lastDebugError = "takeScreenshot errorCode=$errorCode"
                        if (errorCode == 3) {
                            screenshotCooldownUntilMs = SystemClock.elapsedRealtime() + 650L
                        }
                        isScanning = false
                    }
                }
            )
        } catch (e: Exception) {
            lastDebugError = e.message ?: "takeScreenshot exception"
            isScanning = false
        }
    }

    private fun universalHandleImage(
        raw: String,
        fastSetting: Boolean,
        isQuickStage: Boolean,
        isVerifyStage: Boolean
    ) {
        pendingOffer = null
        pendingSessionId = null

        val parsed = parseBoltOffer(raw)
        if (parsed == null) {
            universalImageCandidate = ""
            missingScans++
            if (isVerifyStage) {
                // Brak poprawnego pełnego odczytu — ponowimy próbę, nie uznajemy wstępnego za zweryfikowany
                pendingFullVerify = true
            }
            if (missingScans >= 3) {
                hideOverlay()
                currentOffer = null
                currentSessionId = null
                pendingFullVerify = false
                currentOfferVerified = false
                scanStage = ScanStage.WAITING
            }
            return
        }

        missingScans = 0
        val now = System.currentTimeMillis()
        val key = universalImageKey(parsed)
        val cur = currentOffer
        val curId = currentSessionId

        // Tryb standardowy: potwierdzenie z dwóch kolejnych zgodnych odczytów w pełnej rozdzielczości
        if (!fastSetting) {
            val sameAsCur = cur != null && universalImageKey(cur) == key
            if (!sameAsCur && universalImageCandidate != key) {
                universalImageCandidate = key
                return
            }
            universalImageCandidate = ""

            if (sameAsCur && cur != null && curId != null) {
                currentOfferLastSeenMs = now
                val updated = cur.copy(
                    pickupKm = if (parsed.pickupKm > 0.0) parsed.pickupKm else cur.pickupKm,
                    tripKm = if (parsed.tripKm > 0.0) parsed.tripKm else cur.tripKm,
                    destination = if (parsed.destination != "Kraków" && parsed.destination != "Nie odczytano celu") parsed.destination else cur.destination,
                    pickupAddress = if (parsed.pickupAddress.isNotBlank()) parsed.pickupAddress else cur.pickupAddress,
                    status = OfferStatus.REVIEW,
                    source = "SCREEN"
                )
                currentOffer = updated
                currentOfferVerified = true
                scanStage = ScanStage.VERIFIED
                showOffer(updated)
                return
            }

            // Nowy zweryfikowany screen w trybie standardowym
            val newId = UUID.randomUUID().toString()
            currentSessionId = newId
            currentOfferFirstSeenMs = now
            currentOfferLastSeenMs = now
            currentOfferAccepted = false
            currentOfferVerified = true
            pendingFullVerify = false
            scanStage = ScanStage.VERIFIED
            currentScheduled = parsedScheduled
            currentPickupAddr = parsedPickupAddr
            pickupFromGps = false
            pickupKey = ""
            pickupState = ""
            tripTimeKey = ""
            tripTimeState = ""
            tripDurationMin = -1
            returnDurationMin = 0

            val review = parsed.copy(
                id = newId,
                timestamp = now,
                acceptedTimestamp = 0L,
                status = OfferStatus.REVIEW,
                source = "SCREEN"
            )
            currentOffer = review
            showOffer(review)
            saveScreenReviewOnce(review, key)
            return
        }

        // Tryb szybszy + weryfikacja:
        // Etap 2 (FULL_VERIFY) lub kolejny pełny odczyt dla istniejącej sesji
        if (cur != null && curId != null) {
            val exactSame = universalImageKey(cur) == key
            val likelySameAfterQuickOcr = !currentOfferVerified && isLikelySameOfferDespiteInitialOcrError(cur, parsed)

            if (exactSame || likelySameAfterQuickOcr) {
                currentOfferLastSeenMs = now
                val verifiedEntry = cur.copy(
                    id = curId,
                    timestamp = currentOfferFirstSeenMs,
                    priceGrosze = parsed.priceGrosze,
                    tripKm = parsed.tripKm,
                    pickupKm = if (parsed.pickupKm > 0.0) parsed.pickupKm else cur.pickupKm,
                    offerMin = parsed.offerMin,
                    destination = if (parsed.destination != "Kraków" && parsed.destination != "Nie odczytano celu") parsed.destination else cur.destination,
                    pickupAddress = if (parsed.pickupAddress.isNotBlank()) parsed.pickupAddress else cur.pickupAddress,
                    status = OfferStatus.REVIEW,
                    source = "SCREEN"
                )
                val wasAlreadyVerified = currentOfferVerified
                currentOffer = verifiedEntry
                currentOfferVerified = true
                pendingFullVerify = false
                scanStage = ScanStage.VERIFIED
                showOffer(verifiedEntry)

                // Dopiero po pełnej weryfikacji zapisujemy screen „Do oceny” (i tylko raz dla tej sesji)
                if (!wasAlreadyVerified) {
                    saveScreenReviewOnce(verifiedEntry, universalImageKey(verifiedEntry))
                } else {
                    RadarStorage.upsertOffer(this, verifiedEntry)
                }
                return
            }
        }

        // Nowa oferta ze screena — Etap 1 (QUICK_SCAN): pokazujemy wstępnie „Weryfikuję…”, nie zapisujemy jeszcze w historii
        val newId = UUID.randomUUID().toString()
        currentSessionId = newId
        currentOfferFirstSeenMs = now
        currentOfferLastSeenMs = now
        currentOfferAccepted = false
        currentOfferVerified = false
        pendingFullVerify = isQuickStage
        scanStage = if (isQuickStage) ScanStage.QUICK_SCAN else ScanStage.VERIFIED
        currentScheduled = parsedScheduled
        currentPickupAddr = parsedPickupAddr
        val fullAddrs = extractAddresses(raw)
        currentStopAddrs = if (fullAddrs.size > 2) fullAddrs.subList(1, fullAddrs.size - 1).take(3) else emptyList()
        currentStopCount = parsed.stopCount
        pickupFromGps = false
        pickupKey = ""
        pickupState = ""
        currentStopAddrs = emptyList()
        currentStopCount = 0
        tripTimeKey = ""
        tripTimeState = ""
        tripDurationMin = -1
        returnDurationMin = 0

        val initialReview = parsed.copy(
            id = newId,
            timestamp = now,
            acceptedTimestamp = 0L,
            status = OfferStatus.REVIEW,
            source = "SCREEN"
        )
        currentOffer = initialReview
        showOffer(initialReview)

        if (!isQuickStage) {
            currentOfferVerified = true
            saveScreenReviewOnce(initialReview, key)
        }
    }

    private fun saveScreenReviewOnce(review: RideEntry, key: String) {
        if (!RadarOptions.historyEnabled(this)) return
        if (RadarStorage.isOfferSignatureSuppressed(this, shortSignatureOf(review))) return
        if (universalSavedImages.add(key)) {
            RadarStorage.recordDecision(this, review)
            if (universalSavedImages.size > 200) {
                val iterator = universalSavedImages.iterator()
                if (iterator.hasNext()) {
                    iterator.next()
                    iterator.remove()
                }
            }
        }
    }

    private fun keyOf(o: RideEntry): String {
        return String.format(Locale.US, "%d|%.1f|%s", o.priceGrosze, o.tripKm, o.destination.take(24))
    }

    private fun shortSignatureOf(o: RideEntry): String {
        return String.format(Locale.US, "%d|%.1f", o.priceGrosze, o.tripKm)
    }

    private fun handleText(
        raw: String,
        src: String,
        isQuickStage: Boolean = false,
        isVerifyStage: Boolean = false
    ) {
        val now = System.currentTimeMillis()
        val fastSetting = RadarOptions.fastReadEnabled(this)
        val offer = parseBoltOffer(raw)

        if (offer == null) {
            if (isVerifyStage && currentOffer != null && !currentOfferVerified) {
                pendingFullVerify = true
            }
            onNoOffer(raw)
            return
        }

        if (RadarStorage.isOfferSignatureSuppressed(this, shortSignatureOf(offer))) {
            return
        }

        missingScans = 0
        val key = keyOf(offer)
        val cur = currentOffer
        val curId = currentSessionId

        // Aktualizacja bieżącej sesji oferty z Bolta (w tym weryfikacja FULL_VERIFY po QUICK_SCAN)
        if (cur != null && curId != null && (now - currentOfferLastSeenMs) < 45_000L) {
            val exactSame = keyOf(cur) == key
            val likelySameAfterQuick = !currentOfferVerified && isLikelySameOfferDespiteInitialOcrError(cur, offer)

            if (exactSame || likelySameAfterQuick) {
                candidateKey = ""
                currentOfferLastSeenMs = now
                val merged = cur.copy(
                    id = curId,
                    timestamp = currentOfferFirstSeenMs,
                    priceGrosze = offer.priceGrosze,
                    tripKm = offer.tripKm,
                    pickupKm = if (offer.pickupKm > 0.0) offer.pickupKm else cur.pickupKm,
                    offerMin = offer.offerMin,
                    destination = if (offer.destination != "Kraków" && offer.destination != "Nie odczytano celu") offer.destination else cur.destination,
                    pickupAddress = if (offer.pickupAddress.isNotBlank()) offer.pickupAddress else cur.pickupAddress,
                    stopCount = if (offer.stopCount > 0) offer.stopCount else cur.stopCount,
                    status = if (currentOfferAccepted) OfferStatus.ACCEPTED else cur.status,
                    source = "RADAR"
                )
                if (!isQuickStage) {
                    currentOfferVerified = true
                    pendingFullVerify = false
                    scanStage = ScanStage.VERIFIED
                }

                val (saved, nowCounted) = RadarStorage.upsertOffer(
                    this,
                    merged,
                    alreadyCountedInSession = currentOfferCountedInSession,
                    previousCountedGrosze = currentOfferCountedGrosze
                )
                currentOffer = saved
                currentOfferCountedInSession = nowCounted
                if (nowCounted) currentOfferCountedGrosze = saved.priceGrosze

                showOffer(saved)

                if (pickupState == "nogps" || pickupState == "error") {
                    if (now - lastPickupTryMs > 5000L) {
                        pickupKey = ""
                        requestPickup(saved)
                    }
                } else if (pickupFromGps) {
                    requestPickup(saved)
                }
                return
            }
        }

        // W trybie standardowym wymagamy potwierdzenia nowego odczytu OCR (w trybie szybszym lub NODE przechodzimy od razu)
        if (!fastSetting && src != "NODE" && key != candidateKey) {
            candidateKey = key
            return
        }

        candidateKey = ""
        pendingOffer = null
        pendingSessionId = null

        val newSessionId = UUID.randomUUID().toString()
        currentSessionId = newSessionId
        currentOfferFirstSeenMs = now
        currentOfferLastSeenMs = now
        currentOfferAccepted = false
        currentOfferCountedInSession = false
        currentOfferCountedGrosze = 0L
        currentOfferVerified = !isQuickStage
        pendingFullVerify = isQuickStage
        scanStage = if (isQuickStage) ScanStage.QUICK_SCAN else ScanStage.VERIFIED

        currentScheduled = parsedScheduled
        currentPickupAddr = parsedPickupAddr
        pickupFromGps = false
        pickupKey = ""
        pickupState = ""
        tripTimeKey = ""
        tripTimeState = ""
        tripDurationMin = -1
        returnDurationMin = 0

        val initialEntry = offer.copy(
            id = newSessionId,
            timestamp = now,
            acceptedTimestamp = 0L,
            status = OfferStatus.UNDECIDED,
            source = "RADAR"
        )
        val (saved, _) = RadarStorage.upsertOffer(this, initialEntry)
        currentOffer = saved
        showOffer(saved)
    }

    private fun onNoOffer(raw: String?) {
        missingScans++
        candidateKey = ""

        val p = pendingOffer
        val pId = pendingSessionId
        if (p != null && pId != null) {
            if (raw != null && looksLikeActiveTrip(raw)) {
                record(p.copy(id = pId), OfferStatus.ACCEPTED)
                pendingOffer = null
                pendingSessionId = null
                return
            } else if (System.currentTimeMillis() > decisionDeadline) {
                record(p.copy(id = pId), OfferStatus.UNDECIDED)
                pendingOffer = null
                pendingSessionId = null
            }
        }

        val offer = currentOffer
        val sessionId = currentSessionId
        if (offer != null && sessionId != null && missingScans >= 3) {
            hideOverlay()
            if (!currentOfferAccepted && !currentScheduled && !universalExternalSource && offer.source != "SCREEN") {
                pendingOffer = offer
                pendingSessionId = sessionId
                pendingOfferCounted = currentOfferCountedInSession
                pendingOfferCountedGrosze = currentOfferCountedGrosze
                decisionDeadline = System.currentTimeMillis() + 8000L
            }
            currentOffer = null
            currentSessionId = null
            pendingFullVerify = false
            currentOfferVerified = false
            scanStage = ScanStage.WAITING
        }

        if (currentOffer == null && missingScans >= 3) {
            hideOverlay()
        }
    }

    private fun looksLikeActiveTrip(raw: String): Boolean {
        val l = raw.lowercase(Locale.getDefault())
        val markers = listOf(
            "dojazd do", "jedziesz do", "jedź do", "odbierz pasażera", "odbiór pasażera",
            "jestem na miejscu", "na miejscu", "rozpocznij kurs", "rozpocznij przejazd",
            "nawiguj", "napisz do pasażera", "zadzwoń do pasażera", "anuluj przejazd", "anuluj kurs"
        )
        return markers.any { l.contains(it) }
    }

    private fun extractAddresses(raw: String): List<Pair<String, String>> {
        val result = ArrayList<Pair<String, String>>()
        val normalizedNear = raw.replace(Regex("""\s*\n\s*(?=\d{2}-\d{3}|Polska\b)""", RegexOption.IGNORE_CASE), ", ")
        val nearRegex = Regex("""Niedaleko\s+([^,\n]+),\s*([^\n\d,]+)""", RegexOption.IGNORE_CASE)
        for (m in nearRegex.findAll(normalizedNear)) {
            val st = m.groupValues[1].trim()
            val ctRaw = m.groupValues[2].trim()
            val ct = ctRaw.substringBefore("\n").trim()
            if (st.isNotEmpty() && ct.isNotEmpty()) {
                val pair = Pair(st, ct)
                if (result.lastOrNull() != pair) {
                    result.add(pair)
                }
            }
        }
        if (result.isNotEmpty()) return result

        val streetCityRegex = Regex(
            """([A-ZĄĆĘŁŃÓŚŹŻ][A-Za-zĄĆĘŁŃÓŚŹŻąćęłńóśźż0-9.\-\s]{2,40}?),\s*([A-ZĄĆĘŁŃÓŚŹŻ][A-Za-zĄĆĘŁŃÓŚŹŻąćęłńóśźż\-\s]{2,25})(?=\s*(?:\d{2}-\d{3}|,|\n|$))"""
        )
        for (m in streetCityRegex.findAll(raw)) {
            val st = m.groupValues[1].trim()
            val ct = m.groupValues[2].trim()
            val lowSt = st.lowercase(Locale.getDefault())
            val lowCt = ct.lowercase(Locale.getDefault())
            if (lowSt.contains("min") || lowSt.contains("km") || lowSt.contains("zł") || lowSt.contains("netto") || lowSt.contains("podatk")) {
                continue
            }
            if (lowCt == "polska") continue
            result.add(Pair(st, ct))
        }
        return result
    }

    private fun parseBoltOffer(raw: String): RideEntry? {
        if (!acceptLabelRegex.containsMatchIn(raw)) {
            return null
        }

        val lower = raw.lowercase(Locale.getDefault())
        parsedScheduled = lower.contains("zarezerwowan") || lower.contains("zamów")

        val priceRegex = Regex("""(\d{1,4}(?:[.,]\d{1,2})?)\s*(?:zł|PLN|zl)(?!\s*/)""", RegexOption.IGNORE_CASE)
        val price = priceRegex.findAll(raw)
            .mapNotNull { it.groupValues[1].replace(",", ".").toDoubleOrNull() }
            .firstOrNull { it in 5.0..800.0 } ?: return null

        val pairRegex = Regex("""(\d+)\s*min[^\d]{0,8}(\d+(?:[.,]\d+)?)\s*km""", RegexOption.IGNORE_CASE)
        val pairs = pairRegex.findAll(raw).map {
            Pair(it.groupValues[1].toIntOrNull() ?: 0, it.groupValues[2].replace(",", ".").toDoubleOrNull() ?: 0.0)
        }.toList()

        var pickupKm = 0.0
        var tripKm = 0.0
        var minutes = 0
        if (pairs.size >= 2) {
            pickupKm = pairs[0].second
            tripKm = pairs[1].second
            minutes = pairs[0].first + pairs[1].first
        } else {
            val kmRegex = Regex("""(\d+(?:[.,]\d+)?)\s*km""", RegexOption.IGNORE_CASE)
            val kms = kmRegex.findAll(raw)
                .mapNotNull { it.groupValues[1].replace(",", ".").toDoubleOrNull() }
                .filter { it in 0.1..400.0 }.toList()
            if (kms.isEmpty()) return null
            if (kms.size >= 2 && !parsedScheduled) {
                pickupKm = kms[0]
                tripKm = kms[1]
            } else {
                tripKm = kms[0]
            }
            val minRegex = Regex("""(\d+)\s*min\b""", RegexOption.IGNORE_CASE)
            minutes = minRegex.findAll(raw).mapNotNull { it.groupValues[1].toIntOrNull() }
                .filter { it in 1..240 }.take(2).sum()
        }
        if (tripKm <= 0.0) return null

        val addrs = extractAddresses(raw)
        parsedPickupAddr = if (addrs.isNotEmpty()) addrs.first() else null
        val pickupAddrText = if (addrs.isNotEmpty()) addrs.first().first + ", " + addrs.first().second else ""
        val stopsCount = if (addrs.size >= 2) (addrs.size - 2).coerceAtLeast(0) else 0
        val dest = if (addrs.size >= 2) {
            val lastAddr = addrs.last()
            lastAddr.first + ", " + lastAddr.second
        } else {
            "Nie odczytano celu"
        }

        return RideEntry(
            id = UUID.randomUUID().toString(),
            timestamp = System.currentTimeMillis(),
            acceptedTimestamp = 0L,
            priceGrosze = plnToGrosze(price),
            tripKm = tripKm,
            pickupKm = pickupKm,
            offerMin = minutes.coerceAtLeast(1),
            status = OfferStatus.UNDECIDED,
            destination = dest,
            pickupAddress = pickupAddrText,
            stopCount = stopsCount
        )
    }

    private fun httpGet(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 6000
        c.readTimeout = 6000
        c.setRequestProperty("User-Agent", "KursRadar/1.0 (personal app)")
        try {
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    private fun geocode(street: String, city: String): DoubleArray? {
        val ck = street + "|" + city
        val cached = geoCache[ck]
        if (cached != null) return cached
        val q = URLEncoder.encode(street + ", " + city + ", Polska", "UTF-8")
        val arr = JSONArray(httpGet("https://nominatim.openstreetmap.org/search?format=json&limit=1&q=" + q))
        if (arr.length() == 0) return null
        val o = arr.getJSONObject(0)
        val pt = doubleArrayOf(o.getString("lat").toDouble(), o.getString("lon").toDouble())
        if (geoCache.size >= 200) geoCache.clear()
        geoCache[ck] = pt
        return pt
    }

    private fun routeKm(lat: Double, lon: Double, street: String, city: String): Double {
        val pt = geocode(street, city) ?: return -1.0
        val url = "https://router.project-osrm.org/route/v1/driving/" + lon + "," + lat + ";" + pt[1] + "," + pt[0] + "?overview=false"
        val js = JSONObject(httpGet(url))
        val routes = js.getJSONArray("routes")
        if (routes.length() == 0) return -1.0
        return routes.getJSONObject(0).getDouble("distance") / 1000.0
    }

    private fun routeDurationMin(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Int {
        val url = "https://router.project-osrm.org/route/v1/driving/" +
            lon1 + "," + lat1 + ";" + lon2 + "," + lat2 + "?overview=false"
        val js = JSONObject(httpGet(url))
        val routes = js.getJSONArray("routes")
        if (routes.length() == 0) return -1
        val sec = routes.getJSONObject(0).getDouble("duration")
        if (!sec.isFinite() || sec <= 0.0) return -1
        return kotlin.math.max(1, kotlin.math.round(sec / 60.0).toInt())
    }

    private fun approxDistKm(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val res = FloatArray(1)
        Location.distanceBetween(lat1, lon1, lat2, lon2, res)
        return res[0].toDouble() / 1000.0
    }

    private fun splitDestAddress(rawDest: String): Pair<String, String> {
        val clean = rawDest.trim()
        val parts = clean.split(",").map { it.trim() }.filter { it.isNotEmpty() }
        return if (parts.size >= 2) {
            parts[0] to parts[1]
        } else {
            clean to "Kraków"
        }
    }

    private fun requestTripAndReturnTime(offer: RideEntry) {
        if (!RadarOptions.tripTimeEnabled(this)) return
        val destRaw = offer.destination.trim()
        if (destRaw.isEmpty() || destRaw.equals("Nieznany", true) || destRaw.equals("Nie odczytano celu", true) || destRaw.equals("Kraków", true)) return

        val pickupAddr = currentPickupAddr
        val loc = currentLocation()
        val startKey = when {
            pickupAddr != null -> pickupAddr.first + "|" + pickupAddr.second
            loc != null -> "${Math.round(loc.latitude * 300.0)},${Math.round(loc.longitude * 300.0)}"
            else -> return
        }
        val key = "$startKey->$destRaw"
        if (key == tripTimeKey) return
        tripTimeKey = key
        tripTimeState = "calc"

        val offerKey = keyOf(offer)
        val offerSessionId = currentSessionId ?: offer.id
        val fallbackLat = loc?.latitude
        val fallbackLon = loc?.longitude
        val intermediateStops = currentStopAddrs.toList()

        // Bramy powrotu wokół centrum Krakowa (8 kierunków / 9 węzłów)
        val krakowGates = arrayOf(
            doubleArrayOf(50.0755, 19.9510), // al. 29 Listopada / Wita Stwosza (Północ: Zielonki)
            doubleArrayOf(50.0658, 19.9597), // Rondo Mogilskie (Wschód-północ: Wzgórza Krzesławickie, Huta)
            doubleArrayOf(50.0568, 19.9600), // Rondo Grzegórzeckie (Wschód-południe: Rybitwy, Złocień)
            doubleArrayOf(50.0472, 19.9547), // Plac Bohaterów Getta / Starowiślna (Płd-wschód: Wieliczka, Bieżanów)
            doubleArrayOf(50.0355, 19.9412), // Rondo Matecznego (Południe: Borek, Swoszowice)
            doubleArrayOf(50.0479, 19.9325), // Most Grunwaldzki (Płd-zachód: Tyniec, Skawina, Ruczaj)
            doubleArrayOf(50.0544, 19.9277), // Jubilat (Zachód: Wola Justowska, Kryspinów)
            doubleArrayOf(50.0695, 19.9245), // Plac Inwalidów (Zachód/Płn-zachód: Balice, Bronowice)
            doubleArrayOf(50.0748, 19.9348)  // Nowy Kleparz (Płn-zachód: Modlniczka, Prądnik Biały)
        )
        val rynekLat = 50.0619
        val rynekLon = 19.9368

        netExecutor.execute {
            var courseMin = -1
            var retMin = 0
            try {
                val startPt = if (pickupAddr != null) {
                    geocode(pickupAddr.first, pickupAddr.second)
                } else if (fallbackLat != null && fallbackLon != null) {
                    doubleArrayOf(fallbackLat, fallbackLon)
                } else {
                    null
                }
                val (dStreet, dCity) = splitDestAddress(destRaw)
                val destPt = geocode(dStreet, dCity)

                if (startPt != null && destPt != null) {
                    val waypoints = ArrayList<DoubleArray>(intermediateStops.size + 2)
                    waypoints.add(startPt)
                    for (stAddr in intermediateStops) {
                        val sp = geocode(stAddr.first, stAddr.second)
                        if (sp != null) waypoints.add(sp)
                    }
                    waypoints.add(destPt)

                    var sumLegMin = 0
                    var allLegsOk = true
                    for (idx in 0 until waypoints.size - 1) {
                        val a = waypoints[idx]
                        val b = waypoints[idx + 1]
                        val leg = routeDurationMin(a[0], a[1], b[0], b[1])
                        if (leg > 0) {
                            sumLegMin += leg
                        } else {
                            allLegsOk = false
                        }
                    }
                    if (allLegsOk && sumLegMin > 0) {
                        courseMin = sumLegMin
                    } else {
                        courseMin = routeDurationMin(startPt[0], startPt[1], destPt[0], destPt[1])
                    }

                    // Powrót liczymy zawsze z ostatniego punktu (celu końcowego)
                    val distFromRynek = approxDistKm(destPt[0], destPt[1], rynekLat, rynekLon)
                    if (distFromRynek > 4.2) {
                        var bestGate = krakowGates[0]
                        var bestDist = Double.MAX_VALUE
                        for (g in krakowGates) {
                            val d = approxDistKm(destPt[0], destPt[1], g[0], g[1])
                            if (d < bestDist) {
                                bestDist = d
                                bestGate = g
                            }
                        }
                        if (bestDist > 1.2) {
                            val r = routeDurationMin(destPt[0], destPt[1], bestGate[0], bestGate[1])
                            if (r > 0) retMin = r
                        }
                    }
                }
            } catch (_: Exception) {
            }
            mainHandler.post {
                val cur = currentOffer
                if (
                    cur != null &&
                    currentSessionId == offerSessionId &&
                    keyOf(cur) == offerKey
                ) {
                    if (courseMin > 0) {
                        tripDurationMin = courseMin
                        returnDurationMin = retMin
                        tripTimeState = "ok"
                    } else {
                        tripDurationMin = -1
                        returnDurationMin = 0
                        tripTimeState = "error"
                    }
                    showOffer(cur)
                }
            }
        }
    }

    private fun requestPickup(offer: RideEntry) {
        if (universalExternalSource || offer.source == "SCREEN") return

        if (offer.pickupKm > 0.0 && !pickupFromGps) {
            pickupState = "ok"
            return
        }
        val addr = currentPickupAddr
        if (addr == null) {
            pickupState = "noaddr"
            return
        }
        val loc = currentLocation()
        if (loc == null) {
            pickupState = "nogps"
            return
        }
        val key = addr.first + "|" + addr.second + "|" + Math.round(loc.latitude * 300.0) + "," + Math.round(loc.longitude * 300.0)
        if (key == pickupKey) return
        pickupKey = key
        lastPickupTryMs = System.currentTimeMillis()
        if (offer.pickupKm <= 0.0) pickupState = "calc"
        val lat = loc.latitude
        val lon = loc.longitude
        val offerKey = keyOf(offer)
        val offerSessionId = currentSessionId ?: offer.id

        netExecutor.execute {
            var km = -1.0
            try {
                km = routeKm(lat, lon, addr.first, addr.second)
            } catch (_: Exception) {
            }
            mainHandler.post {
                val cur = currentOffer
                if (
                    cur != null &&
                    !universalExternalSource &&
                    cur.source != "SCREEN" &&
                    currentSessionId == offerSessionId &&
                    keyOf(cur) == offerKey
                ) {
                    if (km > 0.0) {
                        pickupState = "ok"
                        pickupFromGps = true
                        val upd = cur.copy(id = offerSessionId, pickupKm = km)
                        val (saved, nowCounted) = RadarStorage.upsertOffer(
                            this,
                            upd,
                            alreadyCountedInSession = currentOfferCountedInSession,
                            previousCountedGrosze = currentOfferCountedGrosze
                        )
                        currentOffer = saved
                        currentOfferCountedInSession = nowCounted
                        if (nowCounted) currentOfferCountedGrosze = saved.priceGrosze
                        showOffer(saved)
                    } else if (cur.pickupKm <= 0.0) {
                        pickupState = "error"
                        showOffer(cur)
                    }
                }
            }
        }
    }

    private fun showOffer(offer: RideEntry) {
        val root = overlayRoot ?: return
        currentOffer = offer

        val scale = RadarStorage.getOverlayScale(this)
        val dual = RadarStorage.isDualRateEnabled(this)
        val pl = Locale("pl", "PL")

        if (
            !offer.priceGross.isFinite() ||
            !offer.tripKm.isFinite() ||
            offer.priceGross <= 0.0 ||
            offer.tripKm <= 0.0
        ) {
            root.visibility = View.GONE
            return
        }

        val pickupKnown =
            offer.pickupKm.isFinite() && offer.pickupKm > 0.0

        val rateCourse = offer.priceGross / offer.tripKm

        val rateWithPickup: Double? = if (pickupKnown) {
            offer.priceGross / (offer.tripKm + offer.pickupKm)
        } else {
            null
        }

        val greenColor = Color.parseColor("#2CE574")
        val yellowColor = Color.parseColor("#FFD54F")
        val redColor = Color.parseColor("#FF5252")
        val unknownColor = Color.parseColor("#8A99B5")

        fun rateColor(
            rate: Double,
            greenThreshold: Float,
            yellowThreshold: Float
        ): Int = when {
            rate >= greenThreshold -> greenColor
            rate >= yellowThreshold -> yellowColor
            else -> redColor
        }

        val tripColor = rateColor(
            rateCourse,
            RadarStorage.getGreenKmRate(this),
            RadarStorage.getYellowKmRate(this)
        )

        val pickupColor = if (rateWithPickup != null) {
            rateColor(
                rateWithPickup,
                RadarStorage.getPickupGreenKmRate(this),
                RadarStorage.getPickupYellowKmRate(this)
            )
        } else {
            unknownColor
        }

        val frameColor = if (dual) pickupColor else tripColor

        val statusText = when {
            dual && !pickupKnown -> "• BRAK DANYCH DOJAZDU"
            frameColor == greenColor -> "• DOBRY"
            frameColor == yellowColor -> "• ŚREDNI"
            else -> "• SŁABY"
        }

        val verifySuffix = if (!currentOfferVerified && RadarOptions.fastReadEnabled(this)) {
            " • Weryfikuję…"
        } else {
            ""
        }

        tvStatusHeader.text = if (offer.source == "SCREEN") {
            "$statusText - ze screena$verifySuffix"
        } else {
            "$statusText$verifySuffix"
        }
        tvStatusHeader.setTextColor(frameColor)
        tvStatusHeader.textSize = 13f * scale

        val rateScale = scale.coerceAtMost(1.22f)

        tvRateCourseLeft.text = String.format(
            pl,
            "%.2f zł/km",
            rateCourse
        )
        tvRateCourseLeft.setTextColor(tripColor)
        tvRateCourseLeft.textSize = 29f * rateScale

        tvLabelCourseLeft.text = String.format(
            pl,
            "za sam kurs • %.1f km",
            offer.tripKm
        )
        tvLabelCourseLeft.setTextColor(Color.WHITE)
        tvLabelCourseLeft.textSize = 12f * scale

        tvRateWithPickupRight.text = if (rateWithPickup != null) {
            String.format(pl, "%.2f zł/km", rateWithPickup)
        } else {
            "—"
        }
        tvRateWithPickupRight.setTextColor(pickupColor)
        tvRateWithPickupRight.textSize = 25f * rateScale

        tvLabelWithPickupRight.text = if (pickupKnown) {
            String.format(pl, "z dolotem • %.1f km", offer.pickupKm + offer.tripKm)
        } else {
            "z dolotem"
        }
        tvLabelWithPickupRight.setTextColor(Color.WHITE)
        tvLabelWithPickupRight.textSize = 12f * scale

        rightRateColumn.visibility =
            if (dual) View.VISIBLE else View.GONE

        tvOfferLine.text = String.format(
            pl,
            "Oferta %.2f zł",
            offer.priceGross
        )
        tvOfferLine.textSize = 13.5f * scale

        if (RadarOptions.tripTimeEnabled(this)) {
            tvDistanceLine.visibility = View.VISIBLE
            tvDistanceLine.text = when {
                tripDurationMin > 0 && returnDurationMin > 0 ->
                    "Czas: ~${tripDurationMin} min + ${returnDurationMin} min powrót"
                tripDurationMin > 0 ->
                    "Czas: ~${tripDurationMin} min"
                tripTimeState == "error" ->
                    "Czas kursu: brak danych"
                else ->
                    "Czas kursu: liczę…"
            }
            tvDistanceLine.setTextColor(Color.parseColor("#65ECC5"))
            tvDistanceLine.textSize = 13.5f * scale
        } else {
            tvDistanceLine.visibility = View.GONE
        }

        val stopsSuffix = when {
            offer.stopCount == 1 -> " (1 przystanek)"
            offer.stopCount > 1 -> " (${offer.stopCount} przystanki)"
            else -> ""
        }
        tvDestLine.text = "Cel: " + offer.destination.take(26) + stopsSuffix
        tvDestLine.textSize = 13f * scale

        val padV = (16 * scale).toInt().coerceIn(12, 34)
        root.setPadding(22, padV, 22, (padV * 0.65f).toInt().coerceAtLeast(8))

        bgBox.setStroke(5, frameColor)

        ensureAttached()
        root.visibility = View.VISIBLE

        requestPickup(offer)
        requestTripAndReturnTime(offer)
    }

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        isConnected = false
        instance = null
        mainHandler.removeCallbacks(tick)
        stopLocation()
        clearNotification()
        resetAll()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        isConnected = false
        instance = null
        try {
            getSharedPreferences("KursRadarDebug", MODE_PRIVATE)
                .edit().putString("last_destroy", "onDestroy ${System.currentTimeMillis()}").apply()
        } catch (_: Exception) {
        }
        super.onDestroy()
        mainHandler.removeCallbacks(tick)
        stopLocation()
        clearNotification()
        releaseWakeLock()
        val root = overlayRoot
        if (isAttached && root != null) {
            try {
                windowManager?.removeView(root)
            } catch (_: Exception) {
            }
        }
        try {
            recognizer?.close()
        } catch (_: Exception) {
        }
        executor.shutdown()
        netExecutor.shutdown()
    }
}
