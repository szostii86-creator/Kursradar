package com.example.kalkulatorkursow

import android.Manifest
import android.accessibilityservice.AccessibilityService
import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale
import java.util.UUID
import java.util.concurrent.Executors

class RideScannerService : AccessibilityService() {

    private val testScreenow = true

    private val channelId = "kursradar_session"
    private var notifChannelCreated = false
    private var notifShown = false

    private var windowManager: WindowManager? = null
    private var overlayRoot: LinearLayout? = null
    private lateinit var tvStatusHeader: TextView
    private lateinit var tvRateCourseLeft: TextView
    private lateinit var tvLabelCourseLeft: TextView
    private lateinit var rightRateColumn: LinearLayout
    private lateinit var tvRateWithPickupRight: TextView
    private lateinit var tvLabelWithPickupRight: TextView
    private lateinit var tvOfferLine: TextView
    private lateinit var tvDistanceLine: TextView
    private lateinit var tvDestLine: TextView
    private lateinit var bgBox: GradientDrawable

    private val overlayParams = WindowManager.LayoutParams(
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
        PixelFormat.TRANSLUCENT
    ).apply {
        gravity = Gravity.TOP or Gravity.START
        x = 30
        y = 140
    }

    private var isAttached = false
    private var recognizer: TextRecognizer? = null
    private val executor = Executors.newSingleThreadExecutor()
    private val netExecutor = Executors.newSingleThreadExecutor()
    private val mainHandler = Handler(Looper.getMainLooper())

    private var isScanning = false
    private var lastScanMs = 0L
    private var currentOffer: RideEntry? = null
    private var currentScheduled = false
    private var currentPickupAddr: Pair<String, String>? = null
    private var parsedScheduled = false
    private var parsedPickupAddr: Pair<String, String>? = null
    private var candidateKey = ""
    private var missingScans = 0
    private var pendingOffer: RideEntry? = null
    private var decisionDeadline = 0L
    private var lastRecordedKey = ""
    private var lastRecordedMs = 0L

    private var locationManager: LocationManager? = null
    private var locationActive = false
    private var lastLoc: Location? = null
    private var countLast: Location? = null
    private val geoCache = HashMap<String, DoubleArray>()
    private var pickupKey = ""
    private var pickupState = ""
    private var pickupFromGps = false
    private var lastPickupTryMs = 0L

    private val locListener = object : LocationListener {
        override fun onLocationChanged(location: Location) {
            lastLoc = location
            if (!RadarStorage.isSessionRunning(this@RideScannerService)) return
            val prev = countLast
            if (prev != null) {
                val d = prev.distanceTo(location)
                if (d in 3.0f..500.0f) RadarStorage.addGpsDistanceMeters(this@RideScannerService, d)
            }
            countLast = location
        }
    }

    private val tick = object : Runnable {
        override fun run() {
            try {
                if (RadarStorage.isSessionRunning(this@RideScannerService)) {
                    startLocation()
                    updateNotification()
                    requestScan()
                } else {
                    stopLocation()
                    clearNotification()
                    resetAll()
                }
            } catch (_: Exception) {
            }
            mainHandler.postDelayed(this, 1000L)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        try {
            recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
            windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
            locationManager = getSystemService(LOCATION_SERVICE) as? LocationManager
            createOverlay()
            mainHandler.removeCallbacks(tick)
            mainHandler.post(tick)
        } catch (_: Exception) {
        }
    }

    private fun updateNotification() {
        try {
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            if (!notifChannelCreated) {
                nm.createNotificationChannel(NotificationChannel(channelId, "Praca kierowcy", NotificationManager.IMPORTANCE_LOW))
                notifChannelCreated = true
            }
            val start = RadarStorage.getSessionStartTime(this)
            val sec = ((System.currentTimeMillis() - start) / 1000L).coerceAtLeast(0L)
            val time = String.format(Locale.US, "%02d:%02d:%02d", sec / 3600, (sec % 3600) / 60, sec % 60)
            val km = RadarStorage.getGpsDistanceMeters(this) / 1000.0
            val count = RadarStorage.getSessionAcceptedCount(this)
            val text = String.format(Locale("pl", "PL"), "%s · %.2f km · %d ukoń.", time, km, count)
            val pi = PendingIntent.getActivity(
                this, 0, Intent(this, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val n = Notification.Builder(this, channelId)
                .setSmallIcon(android.R.drawable.ic_menu_compass)
                .setContentTitle("KursRadar · praca kierowcy")
                .setContentText(text)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setShowWhen(false)
                .setContentIntent(pi)
                .build()
            nm.notify(7001, n)
            notifShown = true
        } catch (_: Exception) {
        }
    }

    private fun clearNotification() {
        if (!notifShown) return
        try {
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).cancel(7001)
        } catch (_: Exception) {
        }
        notifShown = false
    }

    private fun hasLocationPermission(): Boolean {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
    }

    private fun startLocation() {
        if (locationActive || !hasLocationPermission()) return
        val lm = locationManager ?: return
        try {
            if (lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 2000L, 4f, locListener)
                locationActive = true
                countLast = null
            }
        } catch (_: Exception) {
        }
    }

    private fun stopLocation() {
        if (!locationActive) return
        try {
            locationManager?.removeUpdates(locListener)
        } catch (_: Exception) {
        }
        locationActive = false
        countLast = null
    }

    private fun currentLocation(): Location? {
        var best: Location? = lastLoc
        if (hasLocationPermission()) {
            val lm = locationManager
            if (lm != null) {
                for (prov in listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)) {
                    try {
                        val l = lm.getLastKnownLocation(prov)
                        if (l != null && (best == null || l.time > best.time)) best = l
                    } catch (_: Exception) {
                    }
                }
            }
        }
        return best
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun createOverlay() {
        val posPrefs = getSharedPreferences("KursRadarPos", Context.MODE_PRIVATE)
        overlayParams.x = posPrefs.getInt("x", 30)
        overlayParams.y = posPrefs.getInt("y", 140)

        bgBox = GradientDrawable().apply {
            setColor(Color.parseColor("#F50C1821"))
            cornerRadius = 42f
            setStroke(5, Color.parseColor("#3DDC84"))
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = bgBox
            setPadding(36, 26, 36, 26)
            visibility = View.GONE
        }
        tvStatusHeader = TextView(this).apply {
            text = "● DOBRY"
            setTextColor(Color.parseColor("#A3E635"))
            typeface = Typeface.DEFAULT_BOLD
        }
        root.addView(tvStatusHeader)

        val ratesRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 10, 0, 10)
        }
        val leftCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        tvRateCourseLeft = TextView(this).apply {
            text = "0,00 zł/km"
            setTextColor(Color.parseColor("#2CE574"))
            typeface = Typeface.DEFAULT_BOLD
        }
        tvLabelCourseLeft = TextView(this).apply {
            text = "za sam kurs"
            setTextColor(Color.parseColor("#8A99B5"))
        }
        leftCol.addView(tvRateCourseLeft)
        leftCol.addView(tvLabelCourseLeft)
        rightRateColumn = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 0, 0, 0)
        }
        tvRateWithPickupRight = TextView(this).apply {
            text = "0,00 zł/km"
            setTextColor(Color.parseColor("#38B6FF"))
            typeface = Typeface.DEFAULT_BOLD
        }
        tvLabelWithPickupRight = TextView(this).apply {
            text = "z dojazdem"
            setTextColor(Color.parseColor("#8A99B5"))
        }
        rightRateColumn.addView(tvRateWithPickupRight)
        rightRateColumn.addView(tvLabelWithPickupRight)
        ratesRow.addView(leftCol)
        ratesRow.addView(rightRateColumn)
        root.addView(ratesRow)

        tvOfferLine = TextView(this).apply {
            setTextColor(Color.parseColor("#D5E3F7"))
            typeface = Typeface.DEFAULT_BOLD
        }
        tvDistanceLine = TextView(this).apply {
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        }
        tvDestLine = TextView(this).apply {
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        }
        root.addView(tvOfferLine)
        root.addView(tvDistanceLine)
        root.addView(tvDestLine)

        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        root.setOnTouchListener { _, ev ->
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = overlayParams.x
                    startY = overlayParams.y
                    touchX = ev.rawX
                    touchY = ev.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    overlayParams.x = startX + (ev.rawX - touchX).toInt()
                    overlayParams.y = startY + (ev.rawY - touchY).toInt()
                    if (isAttached) {
                        try {
                            windowManager?.updateViewLayout(root, overlayParams)
                        } catch (_: Exception) {
                        }
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    posPrefs.edit().putInt("x", overlayParams.x).putInt("y", overlayParams.y).apply()
                    true
                }
                else -> false
            }
        }
        overlayRoot = root
    }

    private fun ensureAttached() {
        val root = overlayRoot ?: return
        if (isAttached) return
        if (!Settings.canDrawOverlays(this)) return
        try {
            windowManager?.addView(root, overlayParams)
            isAttached = true
        } catch (_: Exception) {
        }
    }

    private fun hideOverlay() {
        overlayRoot?.visibility = View.GONE
    }

    private fun resetAll() {
        hideOverlay()
        currentOffer = null
        pendingOffer = null
        missingScans = 0
        candidateKey = ""
        pickupState = ""
    }

    private fun isBoltPackage(p: String): Boolean {
        val l = p.lowercase(Locale.US)
        return l.contains("mtakso") || l.contains("bolt")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        if (!RadarStorage.isSessionRunning(this)) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg == packageName) return
        if (event.eventType == AccessibilityEvent.TYPE_VIEW_CLICKED && isBoltPackage(pkg)) {
            try {
                handleClick(event)
            } catch (_: Exception) {
            }
        }
        requestScan()
    }

    private fun handleClick(event: AccessibilityEvent) {
        val offer = currentOffer ?: return
        val sb = StringBuilder()
        for (t in event.text) sb.append(t).append(' ')
        val src = event.source
        if (src != null) {
            src.text?.let { sb.append(it).append(' ') }
            src.contentDescription?.let { sb.append(it).append(' ') }
            if (src.childCount in 1..3) collectNodeText(src, sb, 0)
        }
        val l = sb.toString().lowercase(Locale.getDefault())
        if (Regex("""akceptuj|przyjmij""").containsMatchIn(l)) {
            record(offer, "ACCEPTED")
        } else if (l.contains("odrzuć") || l.contains("odrzuc") || l.contains("odmów")) {
            record(offer, "REJECTED")
        }
    }

    private fun collectNodeText(node: AccessibilityNodeInfo?, sb: StringBuilder, depth: Int) {
        if (node == null || depth > 40 || sb.length > 8000) return
        val t = node.text?.toString()
        if (!t.isNullOrBlank()) {
            sb.append(t).append('\n')
        } else {
            val d = node.contentDescription?.toString()
            if (!d.isNullOrBlank()) sb.append(d).append('\n')
        }
        for (i in 0 until node.childCount) {
            collectNodeText(node.getChild(i), sb, depth + 1)
        }
    }

    private fun requestScan() {
        val rec = recognizer ?: return
        val now = System.currentTimeMillis()
        if (isScanning && now - lastScanMs > 5000L) isScanning = false
        if (isScanning || now - lastScanMs < 600L) return

        val root: AccessibilityNodeInfo? = try {
            rootInActiveWindow
        } catch (_: Exception) {
            null
        }
        val pkg = root?.packageName?.toString()
        if (!testScreenow && (pkg == null || !isBoltPackage(pkg))) {
            onNoOffer(null)
            return
        }

        try {
            val sb = StringBuilder()
            collectNodeText(root, sb, 0)
            val nodeText = sb.toString()
            if (
                !testScreenow &&
                nodeText.length > 20 &&
                parseBoltOffer(nodeText) != null
            ) {
                lastScanMs = now
                handleText(nodeText, "NODE")
                return
            }
        } catch (_: Exception) {
        }

        var blank: Rect? = null
        val r = overlayRoot
        if (isAttached && r != null && r.visibility == View.VISIBLE && r.width > 0) {
            val loc = IntArray(2)
            r.getLocationOnScreen(loc)
            blank = Rect(loc[0] - 12, loc[1] - 12, loc[0] + r.width + 12, loc[1] + r.height + 12)
        }
        val blankFinal: Rect? = blank

        isScanning = true
        lastScanMs = now
        try {
            takeScreenshot(
                Display.DEFAULT_DISPLAY,
                executor,
                object : TakeScreenshotCallback {
                    override fun onSuccess(screenshot: ScreenshotResult) {
                        try {
                            val hb = screenshot.hardwareBuffer
                            val hw = Bitmap.wrapHardwareBuffer(hb, screenshot.colorSpace)
                            if (hw == null) {
                                hb.close()
                                isScanning = false
                                return
                            }
                            val copy = hw.copy(Bitmap.Config.ARGB_8888, true)
                            hw.recycle()
                            hb.close()
                            if (copy == null) {
                                isScanning = false
                                return
                            }
                            if (blankFinal != null) {
                                val paint = Paint()
                                paint.color = Color.BLACK
                                Canvas(copy).drawRect(blankFinal, paint)
                            }
                            rec.process(InputImage.fromBitmap(copy, 0))
                                .addOnSuccessListener { vt ->
                                    copy.recycle()
                                    isScanning = false
                                    handleText(vt.text, "OCR")
                                }
                                .addOnFailureListener {
                                    copy.recycle()
                                    isScanning = false
                                }
                        } catch (_: Exception) {
                            isScanning = false
                        }
                    }

                    override fun onFailure(errorCode: Int) {
                        isScanning = false
                    }
                }
            )
        } catch (_: Exception) {
            isScanning = false
        }
    }

    private fun keyOf(o: RideEntry): String {
        return String.format(Locale.US, "%.2f|%.1f", o.priceGross, o.tripKm)
    }

    private fun handleText(raw: String, src: String) {
        if (raw.contains("zł") || raw.contains("km")) {
            val stamp = java.text.SimpleDateFormat("HH:mm:ss", Locale.US).format(java.util.Date())
            getSharedPreferences("KursRadarDebug", Context.MODE_PRIVATE)
                .edit().putString("last_text", "[" + stamp + " " + src + "]\n" + raw.take(2500)).apply()
        }
        val offer = parseBoltOffer(raw)
        if (offer == null) {
            onNoOffer(raw)
            return
        }
        missingScans = 0
        pendingOffer = null
        val key = keyOf(offer)
        val cur = currentOffer
        if (cur != null && keyOf(cur) == key) {
            candidateKey = ""
            showOffer(cur)
            val now = System.currentTimeMillis()
            if (pickupState == "nogps" || pickupState == "error") {
                if (now - lastPickupTryMs > 5000L) {
                    pickupKey = ""
                    requestPickup(cur)
                }
            } else if (pickupFromGps) {
                requestPickup(cur)
            }
            return
        }
        if (key != candidateKey) {
            candidateKey = key
            return
        }
        candidateKey = ""
        currentScheduled = parsedScheduled
        currentPickupAddr = parsedPickupAddr
        pickupFromGps = false
        pickupKey = ""
        pickupState = ""
        showOffer(offer)
    }

    private fun onNoOffer(raw: String?) {
        missingScans++
        candidateKey = ""
        val offer = currentOffer
        if (offer != null && missingScans >= 2) {
            hideOverlay()
            pendingOffer = if (currentScheduled) null else offer
            currentOffer = null
            decisionDeadline = System.currentTimeMillis() + 8000L
        }
        val p = pendingOffer
        if (p != null) {
            if (raw != null && looksLikeActiveTrip(raw)) {
                record(p, "ACCEPTED")
                pendingOffer = null
            } else if (System.currentTimeMillis() > decisionDeadline) {
                record(p, "REJECTED")
                pendingOffer = null
            }
        }
        if (currentOffer == null && missingScans >= 3) hideOverlay()
    }

    private fun looksLikeActiveTrip(raw: String): Boolean {
        val l = raw.lowercase(Locale.getDefault())
        val markers = listOf(
            "dojazd do", "jedziesz do", "jedź do", "odbierz pasażera", "odbiór pasażera",
            "jestem na miejscu", "na miejscu", "rozpocznij kurs", "rozpocznij przejazd",
            "nawiguj", "napisz do pasażera", "zadzwoń do pasażera", "anuluj przejazd", "anuluj kurs"
        )
        return markers.any { l.contains(it) }
    }

    private fun record(offer: RideEntry, status: String) {
        if (testScreenow) return

        val now = System.currentTimeMillis()
        val key = keyOf(offer)
        if (key == lastRecordedKey && now - lastRecordedMs < 120000L) return
        lastRecordedKey = key
        lastRecordedMs = now
        RadarStorage.recordDecision(this, offer.copy(status = status))
    }

    private fun parseBoltOffer(raw: String): RideEntry? {
        val acceptRegex = Regex(
            """\b(?:akceptuj(?:ę|e)?|przyjmij|przyjmuj(?:ę|e))\b""",
            RegexOption.IGNORE_CASE
        )

        if (!acceptRegex.containsMatchIn(raw)) {
            return null
        }

        val lower = raw.lowercase(Locale.getDefault())
        parsedScheduled = lower.contains("zarezerwowan") || lower.contains("zamów")

        val priceRegex = Regex("""(\d{1,4}(?:[.,]\d{1,2})?)\s*(?:zł|PLN|zl)(?!\s*/)""", RegexOption.IGNORE_CASE)
        val price = priceRegex.findAll(raw)
            .mapNotNull { it.groupValues[1].replace(",", ".").toDoubleOrNull() }
            .firstOrNull { it in 5.0..800.0 } ?: return null

        val pairRegex = Regex("""(\d+)\s*min\s*\(\s*(\d+(?:[.,]\d+)?)\s*km\s*\)""", RegexOption.IGNORE_CASE)
        val pairs = pairRegex.findAll(raw).map {
            Pair(it.groupValues[1].toIntOrNull() ?: 0, it.groupValues[2].replace(",", ".").toDoubleOrNull() ?: 0.0)
        }.toList()

        var pickupKm = 0.0
        var tripKm = 0.0
        var minutes = 0
        if (pairs.size >= 2) {
            pickupKm = pairs[0].second
            tripKm = pairs[1].second
            minutes = pairs[0].first + pairs[1].first
        } else {
            val kmRegex = Regex("""(\d+(?:[.,]\d+)?)\s*km""", RegexOption.IGNORE_CASE)
            val kms = kmRegex.findAll(raw)
                .mapNotNull { it.groupValues[1].replace(",", ".").toDoubleOrNull() }
                .filter { it in 0.1..400.0 }.toList()
            if (kms.isEmpty()) return null
            if (kms.size >= 2 && !parsedScheduled) {
                pickupKm = kms[0]
                tripKm = kms[1]
            } else {
                tripKm = kms[0]
            }
            val minRegex = Regex("""(\d+)\s*min\b""", RegexOption.IGNORE_CASE)
            minutes = minRegex.findAll(raw).mapNotNull { it.groupValues[1].toIntOrNull() }
                .filter { it in 1..240 }.take(2).sum()
        }
        if (tripKm <= 0.0) return null

        val addrRegex = Regex("""Niedaleko\s+([^,\n]+),\s*([^\n\d,]+)""")
        val addrs = addrRegex.findAll(raw).map {
            Pair(it.groupValues[1].trim(), it.groupValues[2].trim())
        }.toList()
        parsedPickupAddr = if (addrs.isNotEmpty()) addrs[0] else null
        val dest = if (addrs.size >= 2) addrs[1].first + ", " + addrs[1].second else "Kraków"

        return RideEntry(
            id = UUID.randomUUID().toString(),
            timestamp = System.currentTimeMillis(),
            priceGross = price,
            tripKm = tripKm,
            pickupKm = pickupKm,
            offerMin = minutes.coerceAtLeast(1),
            status = "ACCEPTED",
            destination = dest
        )
    }

    private fun httpGet(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 6000
        c.readTimeout = 6000
        c.setRequestProperty("User-Agent", "KursRadar/1.0 (personal app)")
        try {
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    private fun geocode(street: String, city: String): DoubleArray? {
        val ck = street + "|" + city
        val cached = geoCache[ck]
        if (cached != null) return cached
        val q = URLEncoder.encode(street + ", " + city + ", Polska", "UTF-8")
        val arr = JSONArray(httpGet("https://nominatim.openstreetmap.org/search?format=json&limit=1&q=" + q))
        if (arr.length() == 0) return null
        val o = arr.getJSONObject(0)
        val pt = doubleArrayOf(o.getString("lat").toDouble(), o.getString("lon").toDouble())
        geoCache[ck] = pt
        return pt
    }

    private fun routeKm(lat: Double, lon: Double, street: String, city: String): Double {
        val pt = geocode(street, city) ?: return -1.0
        val url = "https://router.project-osrm.org/route/v1/driving/" + lon + "," + lat + ";" + pt[1] + "," + pt[0] + "?overview=false"
        val js = JSONObject(httpGet(url))
        val routes = js.getJSONArray("routes")
        if (routes.length() == 0) return -1.0
        return routes.getJSONObject(0).getDouble("distance") / 1000.0
    }

    private fun requestPickup(offer: RideEntry) {
        if (offer.pickupKm > 0.0 && !pickupFromGps) {
            pickupState = "ok"
            return
        }
        val addr = currentPickupAddr
        if (addr == null) {
            pickupState = "noaddr"
            return
        }
        val loc = currentLocation()
        if (loc == null) {
            pickupState = "nogps"
            return
        }
        val key = addr.first + "|" + addr.second + "|" + Math.round(loc.latitude * 300.0) + "," + Math.round(loc.longitude * 300.0)
        if (key == pickupKey) return
        pickupKey = key
        lastPickupTryMs = System.currentTimeMillis()
        if (offer.pickupKm <= 0.0) pickupState = "calc"
        val lat = loc.latitude
        val lon = loc.longitude
        val offerKey = keyOf(offer)
        netExecutor.execute {
            var km = -1.0
            try {
                km = routeKm(lat, lon, addr.first, addr.second)
            } catch (_: Exception) {
            }
            mainHandler.post {
                val cur = currentOffer
                if (cur != null && keyOf(cur) == offerKey) {
                    if (km > 0.0) {
                        pickupState = "ok"
                        pickupFromGps = true
                        val upd = cur.copy(pickupKm = km)
                        currentOffer = upd
                        showOffer(upd)
                    } else if (cur.pickupKm <= 0.0) {
                        pickupState = "error"
                        showOffer(cur)
                    }
                }
            }
        }
    }

    private fun showOffer(offer: RideEntry) {
        val root = overlayRoot ?: return
        currentOffer = offer

        val scale = RadarStorage.getOverlayScale(this)
        val dual = RadarStorage.isDualRateEnabled(this)
        val pl = Locale("pl", "PL")

        if (
            !offer.priceGross.isFinite() ||
            !offer.tripKm.isFinite() ||
            offer.priceGross <= 0.0 ||
            offer.tripKm <= 0.0
        ) {
            root.visibility = View.GONE
            return
        }

        val pickupKnown =
            offer.pickupKm.isFinite() && offer.pickupKm > 0.0

        val rateCourse = offer.priceGross / offer.tripKm

        val rateWithPickup: Double? = if (pickupKnown) {
            offer.priceGross / (offer.tripKm + offer.pickupKm)
        } else {
            null
        }

        val greenColor = Color.parseColor("#2CE574")
        val yellowColor = Color.parseColor("#FFD54F")
        val redColor = Color.parseColor("#FF5252")
        val unknownColor = Color.parseColor("#8A99B5")

        fun rateColor(
            rate: Double,
            greenThreshold: Float,
            yellowThreshold: Float
        ): Int = when {
            rate >= greenThreshold -> greenColor
            rate >= yellowThreshold -> yellowColor
            else -> redColor
        }

        val tripColor = rateColor(
            rateCourse,
            RadarStorage.getGreenKmRate(this),
            RadarStorage.getYellowKmRate(this)
        )

        val pickupColor = if (rateWithPickup != null) {
            rateColor(
                rateWithPickup,
                RadarStorage.getPickupGreenKmRate(this),
                RadarStorage.getPickupYellowKmRate(this)
            )
        } else {
            unknownColor
        }

        val frameColor = if (dual) pickupColor else tripColor

        val statusText = when {
            dual && !pickupKnown -> "• BRAK DANYCH DOJAZDU"
            frameColor == greenColor -> "• DOBRY"
            frameColor == yellowColor -> "• ŚREDNI"
            else -> "• SŁABY"
        }

        tvStatusHeader.text = statusText
        tvStatusHeader.setTextColor(frameColor)
        tvStatusHeader.textSize = 13f * scale

        tvRateCourseLeft.text = String.format(
            pl,
            "%.2f zł/km",
            rateCourse
        )
        tvRateCourseLeft.setTextColor(tripColor)
        tvRateCourseLeft.textSize = 30f * scale

        tvLabelCourseLeft.text = "za sam kurs"
        tvLabelCourseLeft.textSize = 11f * scale

        tvRateWithPickupRight.text = if (rateWithPickup != null) {
            String.format(pl, "%.2f zł/km", rateWithPickup)
        } else {
            "—"
        }
        tvRateWithPickupRight.setTextColor(pickupColor)
        tvRateWithPickupRight.textSize = 26f * scale

        tvLabelWithPickupRight.text = "z dolotem"
        tvLabelWithPickupRight.textSize = 11f * scale

        rightRateColumn.visibility =
            if (dual) View.VISIBLE else View.GONE

        tvOfferLine.text = String.format(
            pl,
            "Oferta %.2f zł",
            offer.priceGross
        )
        tvOfferLine.textSize = 13f * scale

        val gpsTag = if (pickupFromGps) " (GPS)" else ""

        tvDistanceLine.text = when {
            pickupKnown -> String.format(
                pl,
                "Dojazd %.1f km%s + kurs %.1f km",
                offer.pickupKm,
                gpsTag,
                offer.tripKm
            )

            pickupState == "calc" -> String.format(
                pl,
                "Kurs %.1f km • liczę dojazd…",
                offer.tripKm
            )

            pickupState == "nogps" -> String.format(
                pl,
                "Kurs %.1f km • brak lokalizacji GPS",
                offer.tripKm
            )

            pickupState == "error" -> String.format(
                pl,
                "Kurs %.1f km • dojazd niedostępny",
                offer.tripKm
            )

            else -> String.format(
                pl,
                "Kurs %.1f km • brak danych dojazdu",
                offer.tripKm
            )
        }

        tvDistanceLine.textSize = 13f * scale

        tvDestLine.text = "Cel: " + offer.destination.take(28)
        tvDestLine.textSize = 13f * scale

        bgBox.setStroke(5, frameColor)

        ensureAttached()
        root.visibility = View.VISIBLE

        requestPickup(offer)
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        super.onDestroy()
        mainHandler.removeCallbacks(tick)
        stopLocation()
        clearNotification()
        val root = overlayRoot
        if (isAttached && root != null) {
            try {
                windowManager?.removeView(root)
            } catch (_: Exception) {
            }
        }
        try {
            recognizer?.close()
        } catch (_: Exception) {
        }
        executor.shutdown()
        netExecutor.shutdown()
    }
}
