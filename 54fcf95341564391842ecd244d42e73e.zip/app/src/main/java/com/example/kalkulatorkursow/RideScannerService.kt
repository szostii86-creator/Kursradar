package com.example.kalkulatorkursow

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Display
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.LinearLayout
import android.widget.TextView
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.Locale
import java.util.UUID
import java.util.concurrent.Executors

class RideScannerService : AccessibilityService() {

    private var windowManager: WindowManager? = null
    private var overlayRoot: LinearLayout? = null
    private lateinit var tvStatusHeader: TextView
    private lateinit var tvRateCourseLeft: TextView
    private lateinit var tvLabelCourseLeft: TextView
    private lateinit var rightRateColumn: LinearLayout
    private lateinit var tvRateWithPickupRight: TextView
    private lateinit var tvLabelWithPickupRight: TextView
    private lateinit var tvOfferLine: TextView
    private lateinit var tvDistanceLine: TextView
    private lateinit var tvDestLine: TextView
    private lateinit var bgBox: GradientDrawable

    private val overlayParams = WindowManager.LayoutParams(
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
        PixelFormat.TRANSLUCENT
    ).apply {
        gravity = Gravity.TOP or Gravity.START
        x = 30
        y = 140
    }

    private var isAttached = false
    private var recognizer: TextRecognizer? = null
    private val executor = Executors.newSingleThreadExecutor()
    private val mainHandler = Handler(Looper.getMainLooper())

    private var isScanning = false
    private var lastScanMs = 0L
    private var currentOffer: RideEntry? = null
    private var currentScheduled = false
    private var parsedScheduled = false
    private var missingScans = 0
    private var pendingOffer: RideEntry? = null
    private var decisionDeadline = 0L
    private var lastRecordedKey = ""
    private var lastRecordedMs = 0L

    private val tick = object : Runnable {
        override fun run() {
            try {
                if (RadarStorage.isSessionRunning(this@RideScannerService)) {
                    requestScan()
                } else {
                    resetAll()
                }
            } catch (_: Exception) {
            }
            mainHandler.postDelayed(this, 1000L)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        try {
            recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
            windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
            createOverlay()
            mainHandler.removeCallbacks(tick)
            mainHandler.post(tick)
        } catch (_: Exception) {
        }
    }

    private fun createOverlay() {
        bgBox = GradientDrawable().apply {
            setColor(Color.parseColor("#F50C1821"))
            cornerRadius = 42f
            setStroke(5, Color.parseColor("#3DDC84"))
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = bgBox
            setPadding(36, 26, 36, 26)
            visibility = View.GONE
        }
        tvStatusHeader = TextView(this).apply {
            text = "● DOBRY"
            setTextColor(Color.parseColor("#A3E635"))
            typeface = Typeface.DEFAULT_BOLD
        }
        root.addView(tvStatusHeader)

        val ratesRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 10, 0, 10)
        }
        val leftCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        tvRateCourseLeft = TextView(this).apply {
            text = "0,00 zł/km"
            setTextColor(Color.parseColor("#2CE574"))
            typeface = Typeface.DEFAULT_BOLD
        }
        tvLabelCourseLeft = TextView(this).apply {
            text = "za sam kurs"
            setTextColor(Color.parseColor("#8A99B5"))
        }
        leftCol.addView(tvRateCourseLeft)
        leftCol.addView(tvLabelCourseLeft)
        rightRateColumn = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 0, 0, 0)
        }
        tvRateWithPickupRight = TextView(this).apply {
            text = "0,00 zł/km"
            setTextColor(Color.parseColor("#38B6FF"))
            typeface = Typeface.DEFAULT_BOLD
        }
        tvLabelWithPickupRight = TextView(this).apply {
            text = "z dojazdem"
            setTextColor(Color.parseColor("#8A99B5"))
        }
        rightRateColumn.addView(tvRateWithPickupRight)
        rightRateColumn.addView(tvLabelWithPickupRight)
        ratesRow.addView(leftCol)
        ratesRow.addView(rightRateColumn)
        root.addView(ratesRow)

        tvOfferLine = TextView(this).apply {
            setTextColor(Color.parseColor("#D5E3F7"))
            typeface = Typeface.DEFAULT_BOLD
        }
        tvDistanceLine = TextView(this).apply {
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        }
        tvDestLine = TextView(this).apply {
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        }
        root.addView(tvOfferLine)
        root.addView(tvDistanceLine)
        root.addView(tvDestLine)
        overlayRoot = root
    }

    private fun ensureAttached() {
        val root = overlayRoot ?: return
        if (isAttached) return
        if (!Settings.canDrawOverlays(this)) return
        try {
            windowManager?.addView(root, overlayParams)
            isAttached = true
        } catch (_: Exception) {
        }
    }

    private fun hideOverlay() {
        overlayRoot?.visibility = View.GONE
    }

    private fun resetAll() {
        hideOverlay()
        currentOffer = null
        pendingOffer = null
        missingScans = 0
    }

    private fun isBoltPackage(p: String): Boolean {
        val l = p.lowercase(Locale.US)
        return l.contains("mtakso") || l.contains("bolt")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (!RadarStorage.isSessionRunning(this)) return
        val pkg = event?.packageName?.toString() ?: return
        if (pkg == packageName) return
        requestScan()
    }

    private fun requestScan() {
        val rec = recognizer ?: return
        val now = System.currentTimeMillis()
        if (isScanning && now - lastScanMs > 5000L) isScanning = false
        if (isScanning || now - lastScanMs < 600L) return

        val pkg = try {
            rootInActiveWindow?.packageName?.toString()
        } catch (_: Exception) {
            null
        }
        if (pkg == null || !isBoltPackage(pkg)) {
            onNoOffer(null)
            return
        }

        var blank: Rect? = null
        val r = overlayRoot
        if (isAttached && r != null && r.visibility == View.VISIBLE && r.width > 0) {
            val loc = IntArray(2)
            r.getLocationOnScreen(loc)
            blank = Rect(loc[0] - 12, loc[1] - 12, loc[0] + r.width + 12, loc[1] + r.height + 12)
        }

        val blankFinal: Rect? = blank
        isScanning = true
        lastScanMs = now
        try {
            takeScreenshot(
                Display.DEFAULT_DISPLAY,
                executor,
                object : TakeScreenshotCallback {
                    override fun onSuccess(screenshot: ScreenshotResult) {
                        try {
                            val hb = screenshot.hardwareBuffer
                            val hw = Bitmap.wrapHardwareBuffer(hb, screenshot.colorSpace)
                            if (hw == null) {
                                hb.close()
                                isScanning = false
                                return
                            }
                            val copy = hw.copy(Bitmap.Config.ARGB_8888, true)
                            hw.recycle()
                            hb.close()
                            if (copy == null) {
                                isScanning = false
                                return
                            }
                            if (blankFinal != null) {
                                val paint = Paint()
                                paint.color = Color.BLACK
                                Canvas(copy).drawRect(blankFinal, paint)
                            }
                            rec.process(InputImage.fromBitmap(copy, 0))
                                .addOnSuccessListener { vt ->
                                    copy.recycle()
                                    isScanning = false
                                    handleText(vt.text)
                                }
                                .addOnFailureListener {
                                    copy.recycle()
                                    isScanning = false
                                }
                        } catch (_: Exception) {
                            isScanning = false
                        }
                    }

                    override fun onFailure(errorCode: Int) {
                        isScanning = false
                    }
                }
            )
        } catch (_: Exception) {
            isScanning = false
        }
    }

    private fun handleText(raw: String) {
        if (raw.contains("zł") || raw.contains("km")) {
            val stamp = java.text.SimpleDateFormat("HH:mm:ss", Locale.US).format(java.util.Date())
            getSharedPreferences("KursRadarDebug", Context.MODE_PRIVATE)
                .edit().putString("last_text", "[" + stamp + "]\n" + raw.take(2500)).apply()
        }
        val offer = parseBoltOffer(raw)
        if (offer != null) {
            missingScans = 0
            pendingOffer = null
            currentScheduled = parsedScheduled
            showOffer(offer)
        } else {
            onNoOffer(raw)
        }
    }

    private fun onNoOffer(raw: String?) {
        missingScans++
        val offer = currentOffer
        if (offer != null && missingScans >= 2) {
            hideOverlay()
            pendingOffer = if (currentScheduled) null else offer
            currentOffer = null
            decisionDeadline = System.currentTimeMillis() + 8000L
        }
        val p = pendingOffer
        if (p != null) {
            if (raw != null && looksLikeActiveTrip(raw)) {
                record(p, "ACCEPTED")
                pendingOffer = null
            } else if (System.currentTimeMillis() > decisionDeadline) {
                record(p, "REJECTED")
                pendingOffer = null
            }
        }
        if (currentOffer == null && missingScans >= 3) hideOverlay()
    }

    private fun looksLikeActiveTrip(raw: String): Boolean {
        val l = raw.lowercase(Locale.getDefault())
        val markers = listOf(
            "dojazd do", "jedziesz do", "jedź do", "odbierz pasażera", "odbiór pasażera",
            "jestem na miejscu", "na miejscu", "rozpocznij kurs", "rozpocznij przejazd",
            "nawiguj", "napisz do pasażera", "zadzwoń do pasażera", "anuluj przejazd", "anuluj kurs"
        )
        return markers.any { l.contains(it) }
    }

    private fun record(offer: RideEntry, status: String) {
        val now = System.currentTimeMillis()
        val key = String.format(Locale.US, "%.2f|%.1f|%.1f", offer.priceGross, offer.tripKm, offer.pickupKm)
        if (key == lastRecordedKey && now - lastRecordedMs < 120000L) return
        lastRecordedKey = key
        lastRecordedMs = now
        RadarStorage.recordDecision(this, offer.copy(status = status))
    }

    private fun parseBoltOffer(raw: String): RideEntry? {
        val acceptRegex = Regex("""\b(akceptuj|przyjmij)\b""", RegexOption.IGNORE_CASE)
        if (!acceptRegex.containsMatchIn(raw)) return null

        val lower = raw.lowercase(Locale.getDefault())
        parsedScheduled = lower.contains("zarezerwowan") || lower.contains("zamów")

        val priceRegex = Regex("""(\d{1,4}(?:[.,]\d{1,2})?)\s*(?:zł|PLN|zl)(?!\s*/)""", RegexOption.IGNORE_CASE)
        val price = priceRegex.findAll(raw)
            .mapNotNull { it.groupValues[1].replace(",", ".").toDoubleOrNull() }
            .firstOrNull { it in 5.0..800.0 } ?: return null

        val pairRegex = Regex("""(\d+)\s*min\s*\(\s*(\d+(?:[.,]\d+)?)\s*km\s*\)""", RegexOption.IGNORE_CASE)
        val pairs = pairRegex.findAll(raw).map {
            Pair(it.groupValues[1].toIntOrNull() ?: 0, it.groupValues[2].replace(",", ".").toDoubleOrNull() ?: 0.0)
        }.toList()

        var pickupKm = 0.0
        var tripKm = 0.0
        var minutes = 0
        if (pairs.size >= 2) {
            pickupKm = pairs[0].second
            tripKm = pairs[1].second
            minutes = pairs[0].first + pairs[1].first
        } else {
            val kmRegex = Regex("""(\d+(?:[.,]\d+)?)\s*km""", RegexOption.IGNORE_CASE)
            val kms = kmRegex.findAll(raw)
                .mapNotNull { it.groupValues[1].replace(",", ".").toDoubleOrNull() }
                .filter { it in 0.1..400.0 }.toList()
            if (kms.isEmpty()) return null
            if (kms.size >= 2) {
                pickupKm = kms[0]
                tripKm = kms[1]
            } else {
                tripKm = kms[0]
            }
            val minRegex = Regex("""(\d+)\s*min\b""", RegexOption.IGNORE_CASE)
            minutes = minRegex.findAll(raw).mapNotNull { it.groupValues[1].toIntOrNull() }
                .filter { it in 1..240 }.take(2).sum()
        }
        if (tripKm <= 0.0) return null

        val addr = raw.lines().map { it.trim() }.filter {
            it.contains("Kraków", ignoreCase = true) || Regex("""\d{2}-\d{3}""").containsMatchIn(it)
        }
        val dest = addr.lastOrNull()?.replace(", Polska", "") ?: "Kraków"

        return RideEntry(
            id = UUID.randomUUID().toString(),
            timestamp = System.currentTimeMillis(),
            priceGross = price,
            tripKm = tripKm,
            pickupKm = pickupKm,
            offerMin = minutes.coerceAtLeast(1),
            status = "ACCEPTED",
            destination = dest
        )
    }

    private fun showOffer(offer: RideEntry) {
        val root = overlayRoot ?: return
        currentOffer = offer
        val s = RadarStorage.getOverlayScale(this)
        val dual = RadarStorage.isDualRateEnabled(this)
        val rateCourse = offer.priceGross / offer.tripKm
        val rateTotal = if (offer.totalKm > 0.0) offer.priceGross / offer.totalKm else rateCourse
        val evaluated = if (dual) rateTotal else rateCourse
        val green = RadarStorage.getGreenKmRate(this)
        val yellow = RadarStorage.getYellowKmRate(this)
        val pl = Locale("pl", "PL")

        val statusText: String
        val color: Int
        if (evaluated >= green) {
            statusText = "• DOBRY"
            color = Color.parseColor("#2CE574")
        } else if (evaluated >= yellow) {
            statusText = "• ŚREDNI"
            color = Color.parseColor("#FFD54F")
        } else {
            statusText = "• SŁABY"
            color = Color.parseColor("#FF5252")
        }

        tvStatusHeader.text = statusText
        tvStatusHeader.setTextColor(color)
        tvStatusHeader.textSize = 13f * s
        tvRateCourseLeft.text = String.format(pl, "%.2f zł/km", rateCourse)
        tvRateCourseLeft.setTextColor(color)
        tvRateCourseLeft.textSize = 30f * s
        tvLabelCourseLeft.textSize = 11f * s
        tvRateWithPickupRight.text = String.format(pl, "%.2f zł/km", rateTotal)
        tvRateWithPickupRight.textSize = 26f * s
        tvLabelWithPickupRight.textSize = 11f * s
        rightRateColumn.visibility = if (dual) View.VISIBLE else View.GONE
        tvOfferLine.text = String.format(pl, "Oferta %.2f zł", offer.priceGross)
        tvOfferLine.textSize = 13f * s
        tvDistanceLine.text = if (offer.pickupKm > 0.0) {
            String.format(pl, "Dojazd %.1f km + kurs %.1f km", offer.pickupKm, offer.tripKm)
        } else {
            String.format(pl, "Kurs %.1f km", offer.tripKm)
        }
        tvDistanceLine.textSize = 13f * s
        tvDestLine.text = "Cel: " + offer.destination.take(28)
        tvDestLine.textSize = 13f * s
        bgBox.setStroke(5, color)

        ensureAttached()
        root.visibility = View.VISIBLE
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        super.onDestroy()
        mainHandler.removeCallbacks(tick)
        val root = overlayRoot
        if (isAttached && root != null) {
            try {
                windowManager?.removeView(root)
            } catch (_: Exception) {
            }
        }
        try {
            recognizer?.close()
        } catch (_: Exception) {
        }
        executor.shutdown()
    }
}
