package com.example.kalkulatorkursow

import android.accessibilityservice.AccessibilityService
import android.annotation.SuppressLint
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.os.*
import android.provider.Settings
import android.view.*
import android.view.accessibility.AccessibilityEvent
import android.widget.*
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.*
import java.util.concurrent.Executors
import kotlin.math.abs

class RideScannerService : AccessibilityService() {

    private lateinit var windowManager: WindowManager
    private lateinit var overlayRoot: LinearLayout
    private lateinit var tvStatusHeader: TextView
    private lateinit var btnDismissX: TextView

    private lateinit var tvRateCourseLeft: TextView
    private lateinit var tvLabelCourseLeft: TextView
    private lateinit var rightRateColumn: LinearLayout
    private lateinit var tvRateWithPickupRight: TextView
    private lateinit var tvLabelWithPickupRight: TextView

    private lateinit var tvOfferLine: TextView
    private lateinit var tvDistanceLine: TextView
    private lateinit var tvDestLine: TextView
    private lateinit var tvFooterBrand: TextView
    private lateinit var decisionRow: LinearLayout
    private lateinit var bgBox: GradientDrawable

    private var recognizer: TextRecognizer? = null
    private val executor = Executors.newSingleThreadExecutor()
    private val mainHandler = Handler(Looper.getMainLooper())

    private var isScanning = false
    private var lastScanMs = 0L
    private var currentOffer: RideEntry? = null
    private var isWindowAttached = false
    private var offerDismissedUntilNext = false

    private val monitorRunnable = object : Runnable {
        override fun run() {
            syncWindowState()
            mainHandler.postDelayed(this, 800L)
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onServiceConnected() {
        super.onServiceConnected()
        try {
            recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
            windowManager = getSystemService(WINDOW_SERVICE) as WindowManager

            bgBox = GradientDrawable().apply {
                setColor(Color.parseColor("#F50C1821"))
                cornerRadius = 42f
                setStroke(5, Color.parseColor("#3DDC84"))
            }

            overlayRoot = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                background = bgBox
                setPadding(36, 26, 36, 26)
            }

            val topHeader = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            tvStatusHeader = TextView(this).apply {
                text = "● DOBRY"
                setTextColor(Color.parseColor("#2CE574"))
                typeface = Typeface.DEFAULT_BOLD
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            }
            btnDismissX = TextView(this).apply {
                text = "✕"
                setTextColor(Color.WHITE)
                typeface = Typeface.DEFAULT_BOLD
                setPadding(24, 4, 8, 4)
                setOnClickListener {
                    currentOffer?.let { offer ->
                        RadarStorage.recordDecision(this@RideScannerService, offer.copy(status = "REJECTED"))
                    }
                    hideOfferPopup()
                }
            }
            topHeader.addView(tvStatusHeader)
            topHeader.addView(btnDismissX)
            overlayRoot.addView(topHeader)

            val ratesRow = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, 10, 0, 10)
            }

            val leftCol = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            }
            tvRateCourseLeft = TextView(this).apply {
                text = "3,04 zł/km"
                setTextColor(Color.parseColor("#2CE574"))
                typeface = Typeface.DEFAULT_BOLD
            }
            tvLabelCourseLeft = TextView(this).apply {
                text = "za sam kurs"
                setTextColor(Color.parseColor("#8A99B5"))
            }
            leftCol.addView(tvRateCourseLeft)
            leftCol.addView(tvLabelCourseLeft)

            rightRateColumn = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(36, 0, 0, 0)
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            }
            tvRateWithPickupRight = TextView(this).apply {
                text = "2,55 zł/km"
                setTextColor(Color.parseColor("#2CE574"))
                typeface = Typeface.DEFAULT_BOLD
            }
            tvLabelWithPickupRight = TextView(this).apply {
                text = "z dojazdem"
                setTextColor(Color.parseColor("#8A99B5"))
            }
            rightRateColumn.addView(tvRateWithPickupRight)
            rightRateColumn.addView(tvLabelWithPickupRight)

            ratesRow.addView(leftCol)
            ratesRow.addView(rightRateColumn)
            overlayRoot.addView(ratesRow)

            tvOfferLine = TextView(this).apply {
                text = "Oferta 28,27 zł • pewność 95%"
                setTextColor(Color.parseColor("#D5E3F7"))
                typeface = Typeface.DEFAULT_BOLD
            }
            tvDistanceLine = TextView(this).apply {
                text = "Dystans łączny 9,3 km"
                setTextColor(Color.WHITE)
                typeface = Typeface.DEFAULT_BOLD
            }
            tvDestLine = TextView(this).apply {
                text = "Cel: Kraków"
                setTextColor(Color.WHITE)
                typeface = Typeface.DEFAULT_BOLD
            }
            tvFooterBrand = TextView(this).apply {
                text = "Bolt • Taxi • FREE"
                setTextColor(Color.parseColor("#7E91AB"))
                setPadding(0, 8, 0, 12)
            }

            overlayRoot.addView(tvOfferLine)
            overlayRoot.addView(tvDistanceLine)
            overlayRoot.addView(tvDestLine)
            overlayRoot.addView(tvFooterBrand)

            decisionRow = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                visibility = View.GONE
            }
            val btnAccept = Button(this).apply {
                text = "✓ Przyjmij"
                setTextColor(Color.parseColor("#041E14"))
                typeface = Typeface.DEFAULT_BOLD
                setBackgroundColor(Color.parseColor("#2CE574"))
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { rightMargin = 10 }
                setOnClickListener {
                    currentOffer?.let { offer ->
                        RadarStorage.recordDecision(this@RideScannerService, offer.copy(status = "ACCEPTED"))
                    }
                    hideOfferPopup()
                }
            }
            val btnReject = Button(this).apply {
                text = "✕ Odrzuć"
                setTextColor(Color.WHITE)
                typeface = Typeface.DEFAULT_BOLD
                setBackgroundColor(Color.parseColor("#C62828"))
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = 10 }
                setOnClickListener {
                    currentOffer?.let { offer ->
                        RadarStorage.recordDecision(this@RideScannerService, offer.copy(status = "REJECTED"))
                    }
                    hideOfferPopup()
                }
            }
            decisionRow.addView(btnAccept)
            decisionRow.addView(btnReject)
            overlayRoot.addView(decisionRow)

            val layoutType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            } else {
                @Suppress("DEPRECATION")
                WindowManager.LayoutParams.TYPE_PHONE
            }

            val params = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                layoutType,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.START
                x = 30
                y = 140
            }

            var startX = 0
            var startY = 0
            var touchX = 0f
            var touchY = 0f

            overlayRoot.setOnTouchListener { _, ev ->
                when (ev.action) {
                    MotionEvent.ACTION_DOWN -> {
                        startX = params.x
                        startY = params.y
                        touchX = ev.rawX
                        touchY = ev.rawY
                        true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        params.x = startX + (ev.rawX - touchX).toInt()
                        params.y = startY + (ev.rawY - touchY).toInt()
                        if (isWindowAttached) windowManager.updateViewLayout(overlayRoot, params)
                        true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (abs(ev.rawX - touchX) < 15 && abs(ev.rawY - touchY) < 15) {
                            offerDismissedUntilNext = false
                            scanOfferScreen()
                        }
                        true
                    }
                    else -> false
                }
            }

            if (Settings.canDrawOverlays(this)) {
                windowManager.addView(overlayRoot, params)
                isWindowAttached = true
            }

            mainHandler.post(monitorRunnable)
        } catch (_: Exception) {}
    }

    private fun hideOfferPopup() {
        offerDismissedUntilNext = true
        currentOffer = null
        if (::overlayRoot.isInitialized) overlayRoot.visibility = View.GONE
    }

    private fun syncWindowState() {
        if (!::overlayRoot.isInitialized) return
        val running = RadarStorage.isSessionRunning(this)
        if (!running) {
            overlayRoot.visibility = View.GONE
            offerDismissedUntilNext = false
            return
        }

        if (currentOffer != null && !offerDismissedUntilNext) {
            overlayRoot.visibility = View.VISIBLE
        } else {
            overlayRoot.visibility = View.GONE
        }

        val s = RadarStorage.getOverlayScale(this)
        tvStatusHeader.textSize = 13f * s
        btnDismissX.textSize = 18f * s
        tvRateCourseLeft.textSize = 30f * s
        tvLabelCourseLeft.textSize = 11f * s
        tvRateWithPickupRight.textSize = 26f * s
        tvLabelWithPickupRight.textSize = 11f * s
        tvOfferLine.textSize = 13f * s
        tvDistanceLine.textSize = 13f * s
        tvDestLine.textSize = 13f * s
        tvFooterBrand.textSize = 11f * s

        rightRateColumn.visibility = if (RadarStorage.isDualRateEnabled(this)) View.VISIBLE else View.GONE
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (!RadarStorage.isSessionRunning(this)) return
        val now = System.currentTimeMillis()
        if (!isScanning && now - lastScanMs > 900L) {
            lastScanMs = now
            scanOfferScreen()
        }
    }

    private fun scanOfferScreen() {
        val rec = recognizer ?: return
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R || isScanning || !RadarStorage.isSessionRunning(this)) return
        isScanning = true

        try {
            takeScreenshot(
                Display.DEFAULT_DISPLAY,
                executor,
                object : TakeScreenshotCallback {
                    override fun onSuccess(screenshot: ScreenshotResult) {
                        val hb = screenshot.hardwareBuffer
                        val bmp = Bitmap.wrapHardwareBuffer(hb, screenshot.colorSpace)
                        if (bmp != null) {
                            val copy = bmp.copy(Bitmap.Config.ARGB_8888, false)
                            hb.close()
                            bmp.recycle()
                            val img = InputImage.fromBitmap(copy, 0)
                            rec.process(img)
                                .addOnSuccessListener { visionText ->
                                    parseBoltOffer(visionText.text)
                                    copy.recycle()
                                    isScanning = false
                                }
                                .addOnFailureListener {
                                    copy.recycle()
                                    isScanning = false
                                }
                        } else {
                            hb.close()
                            isScanning = false
                        }
                    }

                    override fun onFailure(errorCode: Int) {
                        isScanning = false
                    }
                }
            )
        } catch (_: Exception) {
            isScanning = false
        }
    }

    private fun getColorForRate(rate: Double, greenThreshold: Float, yellowThreshold: Float): Int {
        return when {
            rate >= greenThreshold -> Color.parseColor("#2CE574")  // Zielony
            rate >= yellowThreshold -> Color.parseColor("#FFD54F") // Żółty
            else -> Color.parseColor("#FF5252")                    // Czerwony
        }
    }

    private fun parseBoltOffer(rawText: String) {
        val hasAcceptWord = rawText.contains("Akceptuj", ignoreCase = true) || rawText.contains("Odbiór", ignoreCase = true)

        val priceRegex = Regex("""(?:(\d+[.,]\d{1,2}|\d+)\s*(?:zł|PLN|zl))|(?:(?:zł|PLN|zl)\s*(\d+[.,]\d{1,2}|\d+))""", RegexOption.IGNORE_CASE)
        val prices = priceRegex.findAll(rawText).mapNotNull { m ->
            (m.groups[1]?.value ?: m.groups[2]?.value)?.replace(",", ".")?.toDoubleOrNull()
        }.filter { it in 7.0..800.0 }.toList()

        val kmRegex = Regex("""(\d+[.,]?\d*)\s*km\b""", RegexOption.IGNORE_CASE)
        val kms = kmRegex.findAll(rawText).mapNotNull {
            it.groupValues[1].replace(",", ".").toDoubleOrNull()
        }.filter { it in 0.1..400.0 }.toList()

        val minRegex = Regex("""(\d+)\s*min\b""", RegexOption.IGNORE_CASE)
        val mins = minRegex.findAll(rawText).mapNotNull {
            it.groupValues[1].toIntOrNull()
        }.filter { it in 1..240 }.toList()

        if (prices.isEmpty() || kms.isEmpty()) {
            if (!hasAcceptWord) {
                offerDismissedUntilNext = false
            }
            return
        }

        val priceGross = prices.first()
        val pickupKm = if (kms.size >= 2) kms[0] else 0.0
        val tripKm = if (kms.size >= 2) kms[1] else kms[0]
        val totalKm = tripKm + pickupKm
        val totalMin = mins.take(2).sum().coerceAtLeast(1)

        if (tripKm <= 0.0) return

        val prev = currentOffer
        if (prev != null && (abs(prev.priceGross - priceGross) > 0.05 || abs(prev.totalKm - totalKm) > 0.05)) {
            offerDismissedUntilNext = false
        }
        if (offerDismissedUntilNext) return

        val rateCourseOnly = priceGross / tripKm
        val rateWithPickup = priceGross / totalKm

        val addressLines = rawText.lines().map { it.trim() }.filter {
            it.contains("Polska", ignoreCase = true) || it.contains("Kraków", ignoreCase = true) || Regex("""\d{2}-\d{3}""").containsMatchIn(it)
        }
        val destText = addressLines.lastOrNull()?.replace(", Polska", "") ?: "Kraków"

        val entry = RideEntry(
            id = UUID.randomUUID().toString(),
            timestamp = System.currentTimeMillis(),
            priceGross = priceGross,
            tripKm = tripKm,
            pickupKm = pickupKm,
            offerMin = totalMin,
            status = "ACCEPTED",
            destination = destText
        )

        // Osobne progi dla samego kursu i dla kursu z dojazdem
        val greenCourse = RadarStorage.getGreenKmRate(this)
        val yellowCourse = RadarStorage.getYellowKmRate(this)
        val colorCourse = getColorForRate(rateCourseOnly, greenCourse, yellowCourse)

        val greenPickup = RadarStorage.getGreenPickupKmRate(this)
        val yellowPickup = RadarStorage.getYellowPickupKmRate(this)
        val colorPickup = getColorForRate(rateWithPickup, greenPickup, yellowPickup)

        val dualEnabled = RadarStorage.isDualRateEnabled(this)
        val mainColor = if (dualEnabled) colorPickup else colorCourse
        val mainRate = if (dualEnabled) rateWithPickup else rateCourseOnly
        val mainGreen = if (dualEnabled) greenPickup else greenCourse
        val mainYellow = if (dualEnabled) yellowPickup else yellowCourse

        val statusLabel = when {
            mainRate >= mainGreen -> "● DOBRY"
            mainRate >= mainYellow -> "● ŚREDNI"
            else -> "● SŁABY"
        }

        mainHandler.post {
            currentOffer = entry
            tvRateCourseLeft.text = String.format(Locale("pl", "PL"), "%.2f zł/km", rateCourseOnly)
            tvRateCourseLeft.setTextColor(colorCourse)

            tvRateWithPickupRight.text = String.format(Locale("pl", "PL"), "%.2f zł/km", rateWithPickup)
            tvRateWithPickupRight.setTextColor(colorPickup)
            rightRateColumn.visibility = if (dualEnabled) View.VISIBLE else View.GONE

            tvOfferLine.text = String.format(Locale("pl", "PL"), "Oferta %.2f zł • pewność 95%%", priceGross)
            tvDistanceLine.text = if (pickupKm > 0.05) {
                String.format(Locale("pl", "PL"), "Dojazd %.1f km + kurs %.1f km", pickupKm, tripKm)
            } else {
                String.format(Locale("pl", "PL"), "Dystans łączny %.1f km", totalKm)
            }
            tvDestLine.text = "Cel: ${destText.take(28)}"
            decisionRow.visibility = View.VISIBLE
            overlayRoot.visibility = View.VISIBLE

            tvStatusHeader.text = statusLabel
            tvStatusHeader.setTextColor(mainColor)
            bgBox.setStroke(5, mainColor)
        }
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        super.onDestroy()
        mainHandler.removeCallbacks(monitorRunnable)
        if (isWindowAttached && ::overlayRoot.isInitialized) {
            try {
                windowManager.removeView(overlayRoot)
            } catch (_: Exception) {}
        }
        try {
            recognizer?.close()
        } catch (_: Exception) {}
        executor.shutdown()
    }
}
