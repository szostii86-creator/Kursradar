package com.example.kalkulatorkursow

import android.Manifest
import android.accessibilityservice.AccessibilityService
import android.annotation.SuppressLint
import android.app.AlertDialog
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.text.InputType
import android.util.TypedValue
import android.view.*
import android.view.accessibility.AccessibilityEvent
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.max

data class RideEntry(
    val id: String,
    val timestamp: Long,
    val priceGross: Double,
    val tripKm: Double,
    val pickupKm: Double,
    val offerMin: Int,
    val status: String,
    val destination: String,
    val source: String = "RADAR",
    val pickupAddress: String = "",
    val offerType: String = "LIVE"
) {
    val totalKm: Double get() = tripKm + pickupKm
}


object RadarStorage {
    private const val PREFS = "KursRadarPrefsV3"
    private fun p(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun isSessionRunning(ctx: Context): Boolean = p(ctx).getBoolean("session_running", false)
    fun setSessionRunning(ctx: Context, running: Boolean) = p(ctx).edit().putBoolean("session_running", running).apply()

    fun getSessionStartTime(ctx: Context): Long = p(ctx).getLong("session_start_ms", 0L)
    fun setSessionStartTime(ctx: Context, ms: Long) = p(ctx).edit().putLong("session_start_ms", ms).apply()

    fun getSessionStopTime(ctx: Context): Long = p(ctx).getLong("session_stop_ms", 0L)
    fun setSessionStopTime(ctx: Context, ms: Long) = p(ctx).edit().putLong("session_stop_ms", ms).apply()

    fun getGpsDistanceMeters(ctx: Context): Float = p(ctx).getFloat("gps_distance_m", 0f)
    fun setGpsDistanceMeters(ctx: Context, meters: Float) = p(ctx).edit().putFloat("gps_distance_m", meters).apply()
    fun addGpsDistanceMeters(ctx: Context, deltaMeters: Float) {
        setGpsDistanceMeters(ctx, getGpsDistanceMeters(ctx) + deltaMeters)
    }

    fun getSessionAcceptedCount(ctx: Context): Int = p(ctx).getInt("session_acc_count", 0)
    fun setSessionAcceptedCount(ctx: Context, count: Int) = p(ctx).edit().putInt("session_acc_count", count).apply()

    fun getSessionGrossTotal(ctx: Context): Float = p(ctx).getFloat("session_gross_total", 0f)
    fun setSessionGrossTotal(ctx: Context, total: Float) = p(ctx).edit().putFloat("session_gross_total", total).apply()

    fun isDualRateEnabled(ctx: Context): Boolean = p(ctx).getBoolean("dual_rate_enabled", true)
    fun setDualRateEnabled(ctx: Context, enabled: Boolean) = p(ctx).edit().putBoolean("dual_rate_enabled", enabled).apply()

    fun getOverlayScale(ctx: Context): Float = p(ctx).getFloat("overlay_scale", 1.0f)
    fun setOverlayScale(ctx: Context, scale: Float) = p(ctx).edit().putFloat("overlay_scale", scale).apply()

    fun getGreenKmRate(ctx: Context): Float = p(ctx).getFloat("green_km_rate", 3.00f)
    fun setGreenKmRate(ctx: Context, v: Float) = p(ctx).edit().putFloat("green_km_rate", v).apply()

    fun getYellowKmRate(ctx: Context): Float = p(ctx).getFloat("yellow_km_rate", 2.40f)
    fun setYellowKmRate(ctx: Context, v: Float) = p(ctx).edit().putFloat("yellow_km_rate", v).apply()

    fun getPickupGreenKmRate(ctx: Context): Float =
        p(ctx).getFloat("pickup_green_km_rate", 2.50f)

    fun getPickupYellowKmRate(ctx: Context): Float =
        p(ctx).getFloat("pickup_yellow_km_rate", 2.00f)

    fun saveRateThresholds(
        ctx: Context,
        tripGreen: Float,
        tripYellow: Float,
        pickupGreen: Float,
        pickupYellow: Float
    ) {
        p(ctx).edit()
            .putFloat("green_km_rate", tripGreen)
            .putFloat("yellow_km_rate", tripYellow)
            .putFloat("pickup_green_km_rate", pickupGreen)
            .putFloat("pickup_yellow_km_rate", pickupYellow)
            .apply()
    }

    fun getFuelConsumption(ctx: Context): Float = p(ctx).getFloat("fuel_consumption", 7.26f)
    fun setFuelConsumption(ctx: Context, fuel: Float) = p(ctx).edit().putFloat("fuel_consumption", fuel).apply()

    fun getHistory(ctx: Context): MutableList<RideEntry> {
        val raw = p(ctx).getString("history_json", "[]") ?: "[]"
        val list = mutableListOf<RideEntry>()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                list.add(
                    RideEntry(
                        id = o.optString("id"),
                        timestamp = o.optLong("t"),
                        priceGross = o.optDouble("price"),
                        tripKm = o.optDouble("tkm"),
                        pickupKm = o.optDouble("pkm"),
                        offerMin = o.optInt("min"),
                        status = o.optString("status", "ACCEPTED"),
                        destination = o.optString("dest", "Kraków"),
                        source = o.optString("src", "RADAR"),
                        pickupAddress = o.optString("paddr", ""),
                        offerType = o.optString("otype", "LIVE")
                    )
                )
            }
        } catch (_: Exception) {}
        list.sortByDescending { it.timestamp }
        return list
    }

    fun saveHistory(ctx: Context, list: List<RideEntry>) {
        val arr = JSONArray()
        list.forEach { r ->
            val o = JSONObject()
            o.put("id", r.id)
            o.put("t", r.timestamp)
            o.put("price", r.priceGross)
            o.put("tkm", r.tripKm)
            o.put("pkm", r.pickupKm)
            o.put("min", r.offerMin)
            o.put("status", r.status)
            o.put("dest", r.destination)
            o.put("src", r.source)
            o.put("paddr", r.pickupAddress)
            o.put("otype", r.offerType)
            arr.put(o)
        }
        p(ctx).edit().putString("history_json", arr.toString()).apply()
    }

    fun recordDecision(ctx: Context, entry: RideEntry) {
        val list = getHistory(ctx)
        list.add(0, entry)
        saveHistory(ctx, list)

        if (entry.status == "ACCEPTED" && isSessionRunning(ctx)) {
            setSessionAcceptedCount(ctx, getSessionAcceptedCount(ctx) + 1)
            setSessionGrossTotal(ctx, getSessionGrossTotal(ctx) + entry.priceGross.toFloat())
        }
    }

    fun deleteHistoryItem(ctx: Context, id: String) {
        val list = getHistory(ctx).filterNot { it.id == id }
        saveHistory(ctx, list)
    }

    fun isInRange(ts: Long, fromMs: Long?, toMs: Long?): Boolean {
        if (fromMs != null && ts < fromMs) return false
        if (toMs != null && ts > toMs) return false
        return true
    }

    fun deleteHistoryRange(ctx: Context, fromMs: Long?, toMs: Long?): Int {
        val list = getHistory(ctx)
        val keep = list.filterNot { isInRange(it.timestamp, fromMs, toMs) }
        saveHistory(ctx, keep)
        return list.size - keep.size
    }
}


class MainActivity : AppCompatActivity(), LocationListener {

    private lateinit var contentFrame: FrameLayout
    private lateinit var bottomNav: LinearLayout
    private var currentTab = "start"

    private var locationManager: LocationManager? = null
    private var lastLocation: Location? = null
    private val uiHandler = Handler(Looper.getMainLooper())
    private var recognizer: TextRecognizer? = null

    private fun getOrCreateRecognizer(): TextRecognizer? {
        if (recognizer == null) {
            recognizer = try {
                TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
            } catch (_: Exception) {
                null
            }
        }
        return recognizer
    }

    private val tickerRunnable = object : Runnable {
        override fun run() {
            if (RadarStorage.isSessionRunning(this@MainActivity) && currentTab == "start") {
                refreshCurrentTab()
            }
            uiHandler.postDelayed(this, 1000L)
        }
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val crashFile = java.io.File(filesDir, "crash.txt")
        if (crashFile.exists()) {
            val tv = TextView(this).apply {
                text = crashFile.readText()
                setTextIsSelectable(true)
                setPadding(24, 24, 24, 24)
            }
            setContentView(ScrollView(this).apply { addView(tv) })
            crashFile.delete()
            return
        }
        try {
            locationManager = getSystemService(Context.LOCATION_SERVICE) as? LocationManager

            val root = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setBackgroundColor(Color.parseColor("#080E1A"))
                layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            }

            contentFrame = FrameLayout(this).apply {
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
            }

            bottomNav = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                background = roundedBox("#0D1526", 28f, "#1E2D4A")
                setPadding(dp(8), dp(10), dp(8), dp(10))
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                    setMargins(dp(12), dp(4), dp(12), dp(12))
                }
            }

            root.addView(contentFrame)
            root.addView(bottomNav)
            setContentView(root)

            switchTab("start")
            if (RadarStorage.isSessionRunning(this)) startGps()
        } catch (e: Exception) {
            Toast.makeText(this, "Błąd startu: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    override fun onResume() {
        super.onResume()
        try {
            uiHandler.removeCallbacks(tickerRunnable)
            uiHandler.post(tickerRunnable)
            if (::contentFrame.isInitialized) refreshCurrentTab()
        } catch (_: Exception) {}
    }

    override fun onPause() {
        super.onPause()
        uiHandler.removeCallbacks(tickerRunnable)
    }

    override fun onDestroy() {
        super.onDestroy()
        uiHandler.removeCallbacks(tickerRunnable)
        stopGps()
        try {
            recognizer?.close()
        } catch (_: Exception) {}
    }

    private fun startGps() {
        try {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), 101)
                return
            }
            lastLocation = null
            if (locationManager?.isProviderEnabled(LocationManager.GPS_PROVIDER) == true) {
                locationManager?.requestLocationUpdates(LocationManager.GPS_PROVIDER, 2000L, 4f, this)
            }
            if (locationManager?.isProviderEnabled(LocationManager.NETWORK_PROVIDER) == true) {
                locationManager?.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 3000L, 8f, this)
            }
        } catch (_: Exception) {}
    }

    private fun stopGps() {
        try {
            locationManager?.removeUpdates(this)
            lastLocation = null
        } catch (_: Exception) {}
    }

    override fun onLocationChanged(location: Location) {
        if (!RadarStorage.isSessionRunning(this)) return
        val prev = lastLocation
        if (prev != null) {
            val delta = prev.distanceTo(location)
            if (delta in 3.0f..500.0f) {
                // licznik km działa w usłudze (RideScannerService)
            }
        }
        lastLocation = location
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 101 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            if (RadarStorage.isSessionRunning(this)) startGps()
        }
    }

    private fun switchTab(tab: String) {
        currentTab = tab
        val tabs = listOf(
            "start" to "⚡\nStart",
            "historia" to "🕒\nHistoria",
            "progi" to "☰\nProgi PRO",
            "ustawienia" to "⚙️\nUstawienia"
        )
        bottomNav.removeAllViews()
        tabs.forEach { (key, label) ->
            val active = currentTab == key
            bottomNav.addView(TextView(this).apply {
                text = label
                gravity = Gravity.CENTER
                textSize = 11f
                setTextColor(if (active) Color.parseColor("#38B6FF") else Color.parseColor("#8A99B5"))
                typeface = if (active) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                setOnClickListener { switchTab(key) }
            })
        }
        refreshCurrentTab()
    }

    private fun refreshCurrentTab() {
        if (!::contentFrame.isInitialized) return
        contentFrame.removeAllViews()
        val view = when (currentTab) {
            "start" -> buildStartAndStatsView()
            "historia" -> buildHistoryView()
            "progi" -> buildThresholdsView()
            else -> buildSettingsView()
        }
        contentFrame.addView(view)
    }

    private fun buildStartAndStatsView(): View {
        val scroll = ScrollView(this)
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(20), dp(16), dp(28))
        }

        val running = RadarStorage.isSessionRunning(this)
        val startMs = RadarStorage.getSessionStartTime(this)
        val stopMs = if (running) System.currentTimeMillis() else RadarStorage.getSessionStopTime(this)

        val sdfDate = SimpleDateFormat("dd.MM HH:mm", Locale.getDefault())
        val sdfHour = SimpleDateFormat("HH:mm", Locale.getDefault())

        val topRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val titleCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        titleCol.addView(TextView(this).apply {
            text = if (running) "Odczyt ekranu aktywny" else "Sesja zakończona"
            textSize = 25f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        })
        titleCol.addView(TextView(this).apply {
            text = if (startMs > 0) "Taxi • ${sdfDate.format(Date(startMs))} do ${sdfHour.format(Date(stopMs))}" else "Taxi • Kliknij START, aby rozpocząć zmianę"
            textSize = 13f
            setTextColor(Color.parseColor("#8A99B5"))
        })

        val badge = TextView(this).apply {
            text = if (running) "● AKTYWNA" else "✓ ZAKOŃCZONA"
            textSize = 12f
            setTextColor(if (running) Color.parseColor("#3DDC84") else Color.parseColor("#4CE0B3"))
            background = roundedBox("#0C261E", 22f, "#2E7D32")
            setPadding(dp(14), dp(10), dp(14), dp(10))
        }
        topRow.addView(titleCol)
        topRow.addView(badge)
        container.addView(topRow)

        val btnStartStop = Button(this).apply {
            text = if (running) "⏹ STOP (Wyłącz nakładkę i zatrzymaj GPS)" else "▶ START (Włącz odczyt ekranu i licznik km GPS)"
            textSize = 15f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(if (running) Color.WHITE else Color.parseColor("#041E14"))
            background = roundedBox(if (running) "#D32F2F" else "#2CE574", 20f, if (running) "#FF6659" else "#65ECC5")
            setPadding(dp(16), dp(18), dp(16), dp(18))
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                topMargin = dp(18)
                bottomMargin = dp(16)
            }
            setOnClickListener {
                if (!running) {
                    if (!Settings.canDrawOverlays(this@MainActivity)) {
                        Toast.makeText(this@MainActivity, "Włącz uprawnienie Nakładki ekranowej!", Toast.LENGTH_LONG).show()
                        try {
                            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                        } catch (_: Exception) {}
                        return@setOnClickListener
                    }
                    val now = System.currentTimeMillis()
                    RadarStorage.setSessionStartTime(this@MainActivity, now)
                    RadarStorage.setSessionStopTime(this@MainActivity, now)
                    RadarStorage.setGpsDistanceMeters(this@MainActivity, 0f)
                    RadarStorage.setSessionAcceptedCount(this@MainActivity, 0)
                    RadarStorage.setSessionGrossTotal(this@MainActivity, 0f)
                    RadarStorage.setSessionRunning(this@MainActivity, true)
                    startGps()
                    if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this@MainActivity, "android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
                        ActivityCompat.requestPermissions(this@MainActivity, arrayOf("android.permission.POST_NOTIFICATIONS"), 102)
                    }
                    Toast.makeText(this@MainActivity, "START! Nakładka i licznik GPS włączone.", Toast.LENGTH_SHORT).show()
                } else {
                    RadarStorage.setSessionStopTime(this@MainActivity, System.currentTimeMillis())
                    RadarStorage.setSessionRunning(this@MainActivity, false)
                    stopGps()
                    Toast.makeText(this@MainActivity, "STOP! Odczyt wyłączony. Podsumowanie poniżej.", Toast.LENGTH_SHORT).show()
                }
                refreshCurrentTab()
            }
        }
        container.addView(btnStartStop)

        val gross = RadarStorage.getSessionGrossTotal(this).toDouble()
        val acceptedCount = RadarStorage.getSessionAcceptedCount(this)
        val gpsKm = RadarStorage.getGpsDistanceMeters(this) / 1000.0
        val avgKm = if (gpsKm > 0.05) gross / gpsKm else 0.0
        val fuelRate = RadarStorage.getFuelConsumption(this)

        val sec = if (startMs > 0 && stopMs >= startMs) ((stopMs - startMs) / 1000L) else 0L
        val timeStr = String.format(Locale.US, "%02d:%02d:%02d", sec / 3600, (sec % 3600) / 60, sec % 60)

        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = roundedBox("#0A2229", 28f, "#26A69A")
            setPadding(dp(20), dp(26), dp(20), dp(26))
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = dp(16)
            }
        }
        hero.addView(TextView(this).apply {
            text = "PRZYCHÓD BRUTTO • ZAAKCEPTOWANE KURSY"
            textSize = 12f
            setTextColor(Color.parseColor("#A5B8D1"))
            gravity = Gravity.CENTER
        })
        hero.addView(TextView(this).apply {
            text = String.format(Locale("pl", "PL"), "%.2f zł", gross)
            textSize = 42f
            setTextColor(Color.parseColor("#2CE574"))
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(0, dp(6), 0, dp(6))
        })
        hero.addView(TextView(this).apply {
            text = if (running) "Liczenie km GPS i oczekiwanie na oferty..." else "Statystyki zakończonej sesji"
            textSize = 13f
            setTextColor(Color.parseColor("#C2D1E5"))
            gravity = Gravity.CENTER
        })
        container.addView(hero)

        container.addView(twoCols(statTile("Czas pracy", timeStr, "#FFFFFF"), statTile("Dystans GPS", String.format(Locale("pl", "PL"), "%.2f km", gpsKm), "#38B6FF")))
        container.addView(twoCols(statTile("Przyjęte kursy", "$acceptedCount ukoń.", "#3DDC84"), statTile("Średnie spalanie:", String.format(Locale("pl", "PL"), "%.2f l/100 km", fuelRate), "#FFD54F")))
        container.addView(twoCols(statTile("Średnio za km (GPS)", String.format(Locale("pl", "PL"), "%.2f zł/km", avgKm), "#3DDC84"), statTile("Status radaru", if (running) "Aktywny" else "Zatrzymany", "#FFFFFF")))

        val bottomBtns = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                topMargin = dp(10)
            }
        }
        bottomBtns.addView(Button(this).apply {
            text = "Historia"
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            background = roundedBox("#0099FF", 24f)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { rightMargin = dp(8) }
            setOnClickListener { switchTab("historia") }
        })
        bottomBtns.addView(Button(this).apply {
            text = "Udostępnij"
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            background = roundedBox("#0C1626", 24f, "#3DD5B0")
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = dp(8) }
            setOnClickListener {
                val txt = String.format(Locale("pl", "PL"), "Podsumowanie sesji:\nPrzyjęte kursy: %d\nZarobek: %.2f zł\nPrzejechane km (GPS): %.2f km\nCzas: %s", acceptedCount, gross, gpsKm, timeStr)
                startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, txt) }, "Udostępnij"))
            }
        })
        container.addView(bottomBtns)

        scroll.addView(container)
        return scroll
    }

    private var histFromMs: Long? = null
    private var histToMs: Long? = null

    private fun pickDateTime(initial: Long?, isEnd: Boolean, onPicked: (Long) -> Unit) {
        val cal = Calendar.getInstance()
        if (initial != null) cal.timeInMillis = initial
        val h0 = if (initial != null) cal.get(Calendar.HOUR_OF_DAY) else if (isEnd) 23 else 0
        val min0 = if (initial != null) cal.get(Calendar.MINUTE) else if (isEnd) 59 else 0
        DatePickerDialog(
            this,
            { _, y, mo, d ->
                TimePickerDialog(
                    this,
                    { _, hh, mm ->
                        val c = Calendar.getInstance()
                        c.set(y, mo, d, hh, mm, if (isEnd) 59 else 0)
                        c.set(Calendar.MILLISECOND, if (isEnd) 999 else 0)
                        onPicked(c.timeInMillis)
                    },
                    h0,
                    min0,
                    true
                ).show()
            },
            cal.get(Calendar.YEAR),
            cal.get(Calendar.MONTH),
            cal.get(Calendar.DAY_OF_MONTH)
        ).show()
    }

    private fun confirmDeleteOne(item: RideEntry) {
        val sdf = SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault())
        AlertDialog.Builder(this)
            .setTitle("Usunąć ten kurs?")
            .setMessage(
                String.format(
                    Locale("pl", "PL"),
                    "%s, %.2f zł\nTej operacji nie można cofnąć.",
                    sdf.format(Date(item.timestamp)),
                    item.priceGross
                )
            )
            .setNegativeButton("Anuluj", null)
            .setPositiveButton("Usuń") { _, _ ->
                RadarStorage.deleteHistoryItem(this, item.id)
                refreshCurrentTab()
            }
            .show()
    }

    private fun buildHistoryView(): View {
        val scroll = ScrollView(this)
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(16), dp(14), dp(28))
        }

        val pl = Locale("pl", "PL")
        val sdf = SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault())
        val fromMs = histFromMs
        val toMs = histToMs
        val all = RadarStorage.getHistory(this)
        val list = all.filter { RadarStorage.isInRange(it.timestamp, fromMs, toMs) }

        val rangeLabel = when {
            fromMs == null && toMs == null -> "Cała historia"
            else -> (if (fromMs != null) sdf.format(Date(fromMs)) else "początek") +
                " – " + (if (toMs != null) sdf.format(Date(toMs)) else "teraz")
        }

        container.addView(TextView(this).apply {
            text = "Historia kursów"
            textSize = 20f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 0, 0, dp(12))
        })

        val filterCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = roundedBox("#101827", 24f, "#24344E")
            setPadding(dp(16), dp(14), dp(16), dp(14))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = dp(12) }
        }
        filterCard.addView(TextView(this).apply {
            text = "Zakres historii"
            textSize = 14f
            setTextColor(Color.parseColor("#8A99B5"))
        })

        val btnFrom = Button(this).apply {
            text = "Od: " + (if (fromMs != null) sdf.format(Date(fromMs)) else "początek (wybierz)")
            setTextColor(Color.WHITE)
            background = roundedBox("#1B2942", 16f, "#38B6FF")
            setOnClickListener {
                pickDateTime(histFromMs, false) { ms ->
                    val t = histToMs
                    if (t != null && ms > t) {
                        Toast.makeText(this@MainActivity, "Data początkowa nie może być późniejsza od końcowej.", Toast.LENGTH_LONG).show()
                    } else {
                        histFromMs = ms
                        refreshCurrentTab()
                    }
                }
            }
        }
        val btnTo = Button(this).apply {
            text = "Do: " + (if (toMs != null) sdf.format(Date(toMs)) else "teraz (wybierz)")
            setTextColor(Color.WHITE)
            background = roundedBox("#1B2942", 16f, "#38B6FF")
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(8) }
            setOnClickListener {
                pickDateTime(histToMs, true) { ms ->
                    val f = histFromMs
                    if (f != null && ms < f) {
                        Toast.makeText(this@MainActivity, "Data końcowa nie może być wcześniejsza od początkowej.", Toast.LENGTH_LONG).show()
                    } else {
                        histToMs = ms
                        refreshCurrentTab()
                    }
                }
            }
        }
        filterCard.addView(btnFrom)
        filterCard.addView(btnTo)

        val quickRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(8) }
        }
        quickRow.addView(Button(this).apply {
            text = "Dzisiaj"
            setTextColor(Color.WHITE)
            background = roundedBox("#0099FF", 16f)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { rightMargin = dp(6) }
            setOnClickListener {
                val c = Calendar.getInstance()
                c.set(Calendar.HOUR_OF_DAY, 0)
                c.set(Calendar.MINUTE, 0)
                c.set(Calendar.SECOND, 0)
                c.set(Calendar.MILLISECOND, 0)
                histFromMs = c.timeInMillis
                c.set(Calendar.HOUR_OF_DAY, 23)
                c.set(Calendar.MINUTE, 59)
                c.set(Calendar.SECOND, 59)
                c.set(Calendar.MILLISECOND, 999)
                histToMs = c.timeInMillis
                refreshCurrentTab()
            }
        })
        quickRow.addView(Button(this).apply {
            text = "Wszystko"
            setTextColor(Color.parseColor("#041E14"))
            background = roundedBox("#2CE574", 16f)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = dp(6) }
            setOnClickListener {
                histFromMs = null
                histToMs = null
                refreshCurrentTab()
            }
        })
        filterCard.addView(quickRow)
        container.addView(filterCard)

        val accepted = list.filter { it.status == "ACCEPTED" }
        val sumAccepted = accepted.sumOf { if (it.priceGross.isFinite()) it.priceGross else 0.0 }
        val rejectedCount = list.count { it.status == "REJECTED" }

        val summary = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = roundedBox("#0A2229", 24f, "#26A69A")
            setPadding(dp(16), dp(14), dp(16), dp(14))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = dp(12) }
        }
        summary.addView(TextView(this).apply {
            text = "Okres: $rangeLabel"
            textSize = 12f
            setTextColor(Color.parseColor("#A5B8D1"))
        })
        summary.addView(TextView(this).apply {
            text = "Przyjęte kursy: ${accepted.size}"
            textSize = 20f
            setTextColor(Color.parseColor("#3DDC84"))
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(6), 0, 0)
        })
        summary.addView(TextView(this).apply {
            text = String.format(pl, "Zarobione (kwoty przyjętych ofert): %.2f zł", sumAccepted)
            textSize = 18f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        })
        summary.addView(TextView(this).apply {
            text = "Wszystkich wpisów w okresie: ${list.size} • odrzuconych: $rejectedCount"
            textSize = 12f
            setTextColor(Color.parseColor("#8A99B5"))
            setPadding(0, dp(4), 0, 0)
        })
        container.addView(summary)

        container.addView(Button(this).apply {
            text = if (fromMs == null && toMs == null) "Usuń całą historię" else "Usuń kursy z wybranego okresu"
            setTextColor(Color.parseColor("#FF8A8A"))
            background = roundedBox("#28151E", 16f, "#5C2B38")
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = dp(12) }
            setOnClickListener {
                if (list.isEmpty()) {
                    Toast.makeText(this@MainActivity, "Brak wpisów w wybranym okresie.", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                AlertDialog.Builder(this@MainActivity)
                    .setTitle("Usunąć wpisy z historii?")
                    .setMessage("Zostanie usuniętych wpisów: ${list.size}\nOkres: $rangeLabel\nTej operacji nie można cofnąć.")
                    .setNegativeButton("Anuluj", null)
                    .setPositiveButton("Usuń") { _, _ ->
                        val n = RadarStorage.deleteHistoryRange(this@MainActivity, histFromMs, histToMs)
                        Toast.makeText(this@MainActivity, "Usunięto wpisów: $n", Toast.LENGTH_SHORT).show()
                        refreshCurrentTab()
                    }
                    .show()
            }
        })

        if (list.isEmpty()) {
            container.addView(TextView(this).apply {
                text = "Brak kursów w wybranym okresie."
                textSize = 14f
                setTextColor(Color.parseColor("#8A99B5"))
                setPadding(dp(8), dp(20), dp(8), dp(20))
            })
        }

        list.take(1000).forEach { item ->
            val rateTrip = if (item.tripKm > 0) item.priceGross / item.tripKm else 0.0
            val rateTotal = if (item.totalKm > 0) item.priceGross / item.totalKm else rateTrip
            val isRejected = item.status == "REJECTED"
            val isReview = item.status == "REVIEW"
            val isUndecided = item.status == "UNDECIDED"
            val isCsv = item.source == "CSV"
            val isScreen = item.source == "SCREEN"
            val isReservation = item.offerType == "RESERVATION"

            val statusLabel = when {
                isRejected -> "✕ Odrzucony"
                isReview -> "Ze screena – do oceny"
                isUndecided -> "? Bez decyzji"
                isCsv -> "✓ Zrealizowana (CSV)"
                else -> "✓ Zaakceptowany"
            }
            val statusColor = when {
                isRejected -> "#FF8A8A"
                isReview -> "#6AB7FF"
                isUndecided -> "#FFD54F"
                else -> "#4CE0B3"
            }
            val statusBg = when {
                isRejected -> "#2B141C"
                isReview -> "#10202E"
                isUndecided -> "#2A2410"
                else -> "#0E2923"
            }
            val statusStroke = when {
                isRejected -> "#8E3B4E"
                isReview -> "#2F6C9A"
                isUndecided -> "#8A7A2A"
                else -> "#2E7D32"
            }

            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                background = roundedBox("#101827", 24f, if (isRejected) "#5C2B38" else "#24344E")
                setPadding(dp(16), dp(14), dp(16), dp(16))
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { bottomMargin = dp(12) }
            }

            val row1 = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            row1.addView(TextView(this).apply {
                val srcTag = when {
                    isCsv -> "CSV"
                    isScreen -> "Screen"
                    else -> "Bolt"
                }
                val typeTag = if (isReservation) " • Rezerwacja" else ""
                text = "Taxi • $srcTag$typeTag • ${sdf.format(Date(item.timestamp))}"
                textSize = 12f
                setTextColor(Color.parseColor("#9BA9C2"))
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            })
            row1.addView(TextView(this).apply {
                text = statusLabel
                textSize = 11f
                setTextColor(Color.parseColor(statusColor))
                background = roundedBox(statusBg, 18f, statusStroke)
                setPadding(dp(12), dp(4), dp(12), dp(4))
            })
            row1.addView(TextView(this).apply {
                text = "✕"
                textSize = 20f
                setTextColor(Color.parseColor("#FF8A8A"))
                setPadding(dp(14), dp(2), dp(2), dp(2))
                setOnClickListener { confirmDeleteOne(item) }
            })
            card.addView(row1)

            val row2 = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, dp(8), 0, dp(6))
            }
            row2.addView(TextView(this).apply {
                text = String.format(pl, "%.2f zł", item.priceGross)
                textSize = 27f
                setTextColor(Color.WHITE)
                typeface = Typeface.DEFAULT_BOLD
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            })
            row2.addView(TextView(this).apply {
                text = String.format(pl, "%.2f zł/km", rateTrip)
                textSize = 21f
                setTextColor(if (isRejected) Color.parseColor("#FF8A8A") else Color.parseColor("#3DDC84"))
                typeface = Typeface.DEFAULT_BOLD
            })
            card.addView(row2)

            val kmText = if (item.pickupKm > 0.05) {
                String.format(
                    pl,
                    "Dojazd %.1f km • Kurs %.1f km • Razem %.1f km\nStawka: %.2f zł/km za sam kurs • %.2f zł/km z dojazdem",
                    item.pickupKm, item.tripKm, item.totalKm, rateTrip, rateTotal
                )
            } else {
                String.format(pl, "Kurs %.1f km • brak danych dojazdu", item.tripKm)
            }
            card.addView(TextView(this).apply {
                text = kmText
                textSize = 12f
                setTextColor(Color.parseColor("#6AB7FF"))
            })

            if (item.pickupAddress.isNotBlank()) {
                card.addView(TextView(this).apply {
                    text = (if (isReservation) "Odbiór (orientacyjnie): " else "Odbiór: ") + item.pickupAddress
                    textSize = 13f
                    setTextColor(Color.parseColor("#C2D1E5"))
                    setPadding(0, dp(8), 0, 0)
                })
            }
            card.addView(TextView(this).apply {
                text = "Cel: ${item.destination}"
                textSize = 13f
                setTextColor(Color.parseColor("#C2D1E5"))
                setPadding(0, dp(4), 0, 0)
            })

            container.addView(card)
        }

        if (list.size > 1000) {
            container.addView(TextView(this).apply {
                text = "Pokazano 1000 najnowszych wpisów z ${list.size}. Zawęź zakres dat, aby zobaczyć pozostałe."
                textSize = 12f
                setTextColor(Color.parseColor("#8A99B5"))
            })
        }

        scroll.addView(container)
        return scroll
    }


    private fun buildThresholdsView(): View {
        val scroll = ScrollView(this)

        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(20), dp(16), dp(28))
        }

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = roundedBox("#101827", 24f, "#24344E")
            setPadding(dp(18), dp(18), dp(18), dp(18))
        }

        fun addHeading(label: String) {
            card.addView(TextView(this@MainActivity).apply {
                text = label
                textSize = 18f
                setTextColor(Color.WHITE)
                typeface = Typeface.DEFAULT_BOLD
                setPadding(0, dp(14), 0, dp(8))
            })
        }

        addHeading("Sam kurs — lewa stawka")

        val tripGreen = addInputField(
            card,
            "Zielony od (zł/km):",
            RadarStorage.getGreenKmRate(this).toString()
        )

        val tripYellow = addInputField(
            card,
            "Żółty od (zł/km):",
            RadarStorage.getYellowKmRate(this).toString()
        )

        addHeading("Z dolotem — prawa stawka")

        val pickupGreen = addInputField(
            card,
            "Zielony od (zł/km):",
            RadarStorage.getPickupGreenKmRate(this).toString()
        )

        val pickupYellow = addInputField(
            card,
            "Żółty od (zł/km):",
            RadarStorage.getPickupYellowKmRate(this).toString()
        )

        card.addView(TextView(this).apply {
            text = "Poniżej progu żółtego stawka będzie czerwona."
            textSize = 13f
            setTextColor(Color.parseColor("#8A99B5"))
            setPadding(0, dp(14), 0, dp(8))
        })

        card.addView(Button(this).apply {
            text = "Zapisz progi obu stawek"
            setTextColor(Color.parseColor("#041E14"))
            typeface = Typeface.DEFAULT_BOLD
            background = roundedBox("#2CE574", 18f)

            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                topMargin = dp(16)
            }

            setOnClickListener {
                fun readValue(field: EditText): Float? =
                    field.text.toString()
                        .trim()
                        .replace(",", ".")
                        .toFloatOrNull()

                val tg = readValue(tripGreen)
                val ty = readValue(tripYellow)
                val pg = readValue(pickupGreen)
                val py = readValue(pickupYellow)

                if (
                    tg == null || ty == null ||
                    pg == null || py == null
                ) {
                    Toast.makeText(
                        this@MainActivity,
                        "Wpisz poprawne liczby we wszystkich polach.",
                        Toast.LENGTH_LONG
                    ).show()
                    return@setOnClickListener
                }

                if (
                    !tg.isFinite() || !ty.isFinite() ||
                    !pg.isFinite() || !py.isFinite() ||
                    tg <= 0f || ty <= 0f ||
                    pg <= 0f || py <= 0f ||
                    tg <= ty || pg <= py
                ) {
                    Toast.makeText(
                        this@MainActivity,
                        "Progi muszą być dodatnie. Zielony musi być wyższy od żółtego.",
                        Toast.LENGTH_LONG
                    ).show()
                    return@setOnClickListener
                }

                RadarStorage.saveRateThresholds(
                    this@MainActivity,
                    tg,
                    ty,
                    pg,
                    py
                )

                Toast.makeText(
                    this@MainActivity,
                    "Zapisano osobne progi obu stawek.",
                    Toast.LENGTH_SHORT
                ).show()
            }
        })

        container.addView(card)
        scroll.addView(container)
        return scroll
    }


    private fun buildSettingsView(): View {
        val scroll = ScrollView(this)
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(20), dp(16), dp(28))
        }

        val modeCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = roundedBox("#101827", 24f, "#24344E")
            setPadding(dp(18), dp(18), dp(18), dp(18))
        }
        modeCard.addView(TextView(this).apply {
            text = "Wygląd wyskakującego okienka"
            textSize = 18f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        })

        val chkDual = CheckBox(this).apply {
            text = "Pokazuj dwie kwoty obok siebie:\nLewa: zł/km za sam kurs | Prawa: zł/km z dojazdem"
            setTextColor(Color.WHITE)
            textSize = 14f
            isChecked = RadarStorage.isDualRateEnabled(this@MainActivity)
            setPadding(0, dp(10), 0, dp(12))
            setOnCheckedChangeListener { _, checked ->
                RadarStorage.setDualRateEnabled(this@MainActivity, checked)
                Toast.makeText(this@MainActivity, if (checked) "Włączono widok dwóch stawek obok siebie" else "Włączono widok jednej stawki", Toast.LENGTH_SHORT).show()
            }
        }
        modeCard.addView(chkDual)

        val currentScale = RadarStorage.getOverlayScale(this)
        modeCard.addView(TextView(this).apply {
            text = "Skalowanie wielkości okienka (aktualnie: ${(currentScale * 100).toInt()}%):"
            textSize = 14f
            setTextColor(Color.parseColor("#3DDC84"))
            setPadding(0, dp(4), 0, dp(10))
        })

        val scales = listOf(
            0.80f to "Małe (80%)",
            1.00f to "Standardowe (100%)",
            1.20f to "Powiększone (120%)",
            1.40f to "Duże (140%)"
        )
        scales.forEach { (sc, label) ->
            val sel = abs(currentScale - sc) < 0.05f
            modeCard.addView(Button(this).apply {
                text = if (sel) "✓ $label" else label
                setTextColor(if (sel) Color.parseColor("#041E14") else Color.WHITE)
                background = roundedBox(if (sel) "#2CE574" else "#1B2942", 16f, if (sel) "#2CE574" else "#32486E")
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(8) }
                setOnClickListener {
                    RadarStorage.setOverlayScale(this@MainActivity, sc)
                    refreshCurrentTab()
                }
            })
        }
        container.addView(modeCard)

        val permCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = roundedBox("#101827", 24f, "#24344E")
            setPadding(dp(18), dp(18), dp(18), dp(18))
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(16) }
        }
        permCard.addView(TextView(this).apply {
            text = "Uprawnienia (Nakładka, Odczyt ekranu, GPS)"
            textSize = 17f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 0, 0, dp(10))
        })
        permCard.addView(Button(this).apply {
            text = "1. Zezwól na wyświetlanie nad innymi aplikacjami"
            setTextColor(Color.WHITE)
            background = roundedBox("#1B2942", 16f, "#38B6FF")
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(8) }
            setOnClickListener {
                try {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                } catch (_: Exception) {}
            }
        })
        permCard.addView(Button(this).apply {
            text = "2. Włącz Usługę Odczytu Ekranu (Ułatwienia dostępu)"
            setTextColor(Color.WHITE)
            background = roundedBox("#1B2942", 16f, "#38B6FF")
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(8) }
            setOnClickListener {
                try {
                    startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                } catch (_: Exception) {}
            }
        })
        permCard.addView(Button(this).apply {
            text = "3. Zezwól na dostęp do GPS (Licznik km)"
            setTextColor(Color.WHITE)
            background = roundedBox("#1B2942", 16f, "#38B6FF")
            setOnClickListener {
                ActivityCompat.requestPermissions(this@MainActivity, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), 101)
            }
        })
        val btnBg = Button(this).apply {
            text = "Lokalizacja: ustaw Zawsze zezwalaj (potrzebne w tle)"
            setTextColor(Color.WHITE)
            background = roundedBox("#1B2942", 16f, "#38B6FF")
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(16) }
            setOnClickListener {
                try {
                    startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
                } catch (_: Exception) {}
            }
        }
        container.addView(permCard)
        container.addView(btnBg)
        val dbgCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = roundedBox("#101827", 24f, "#24344E")
            setPadding(dp(18), dp(18), dp(18), dp(18))
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(16) }
        }
        dbgCard.addView(TextView(this).apply {
            text = "Diagnostyka: ostatni tekst odczytany z ekranu"
            textSize = 15f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        })
        dbgCard.addView(TextView(this).apply {
            text = this@MainActivity.getSharedPreferences("KursRadarDebug", Context.MODE_PRIVATE).getString("last_text", "(jeszcze nic nie odczytano)") ?: ""
            textSize = 11f
            setTextColor(Color.parseColor("#8A99B5"))
            setTextIsSelectable(true)
        })
        container.addView(dbgCard)

        scroll.addView(container)
        return scroll
    }


    private fun twoCols(left: View, right: View): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(12) }
            left.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { rightMargin = dp(6) }
            right.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = dp(6) }
            addView(left)
            addView(right)
        }
    }

    private fun statTile(label: String, value: String, colorHex: String): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = roundedBox("#101929", 22f, "#22324C")
            setPadding(dp(16), dp(16), dp(16), dp(16))
            addView(TextView(this@MainActivity).apply { text = label; textSize = 13f; setTextColor(Color.parseColor("#99AABB")) })
            addView(TextView(this@MainActivity).apply {
                text = value; textSize = 21f; setTextColor(Color.parseColor(colorHex)); typeface = Typeface.DEFAULT_BOLD; setPadding(0, dp(6), 0, 0)
            })
        }
    }

    private fun addInputField(parent: LinearLayout, label: String, initVal: String): EditText {
        parent.addView(TextView(this).apply { text = label; textSize = 13f; setTextColor(Color.parseColor("#99AABB")); setPadding(0, dp(10), 0, dp(4)) })
        val et = EditText(this).apply {
            setText(initVal); setTextColor(Color.WHITE); inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            background = roundedBox("#162338", 14f, "#32486E"); setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        parent.addView(et)
        return et
    }

    private fun roundedBox(fillHex: String, radiusDp: Float, strokeHex: String? = null): GradientDrawable {
        return GradientDrawable().apply {
            setColor(Color.parseColor(fillHex))
            cornerRadius = dp(radiusDp.toInt()).toFloat()
            if (strokeHex != null) setStroke(dp(1), Color.parseColor(strokeHex))
        }
    }

    private fun dp(v: Int): Int = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics).toInt()
}
